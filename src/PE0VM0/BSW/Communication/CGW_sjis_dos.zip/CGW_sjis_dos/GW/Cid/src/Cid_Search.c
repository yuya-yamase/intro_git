/****************************************************************************/
/*	Copyright DENSO Corporation. All rights reserved.                       */
/****************************************************************************/
/*************************************************************************//**
 * @file	Cid_Search.c
 * @brief	CANID�T��
 * @details	
 * @note	�Ȃ�
 * @date	v1.00	2022/09/22	T.Matsushita(FSI)		�V�K�쐬
 ****************************************************************************/

/*--------------------------------------------------------------------------*/
/*		�t�@�C���C���N���[�h												*/
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"

#include "Cid_Data.h"
#include "Cid_Notify_Cfg.h"
#include "Cid_Search.h"


/*--------------------------------------------------------------------------*/
/*		�}�N����`															*/
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/*		�^�C�v�錾															*/
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/*		�O�����J�ϐ�														*/
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/*		�t�@�C�����ϐ�														*/
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/*		�v���g�^�C�v�錾													*/
/*--------------------------------------------------------------------------*/
#define GW_CID_START_SEC_CODE
#include "GW_Cid_Memmap.h"

/*************************************************************************//**
 * @fn			void Cid_Search_ReceiveCanData(uint8 rxCh, const CanMsgType* ptMsg)
 * @brief		CAN��M�����ʒm����
 * @details		CAN��M�������b�Z�[�W��ʒm���܂�
 * @param[in]	uint8 rxCh			��MCH
 * @param[in]	const CanMsgType* ptMsg		��M�f�[�^�|�C���^
 * @return		�Ȃ�
 * @attention 	�Ȃ�
 * @note		�Ȃ�
 ****************************************************************************/
void Cid_Search_ReceiveCanData(uint8 rxCh, const CanMsgType* ptMsg)
{
	uint32 canId = (ptMsg->u4Id & CID_TCOV_MSK_CANCOM); /* CANFD,�g���r�b�g�𗎂Ƃ� */
	uint16	search_min = 0x0U;
	uint16	search_max;
	uint16	searchId;
	uint16	retIndex = CID_NO_SEARCH;
	CanidDataArraySet *pCidDataArrayNow;
	
	/* �g��ID���� */
	if (canId > CID_NOMALCANID_MAX) {
		/* �g��ID�T���p�ɐݒ� */
		pCidDataArrayNow = Cid_Data_CanId_Ex_UserTable;
		search_max = CID_SEARCHEX_MAX -1U;
	}else {
		/* �W��ID�T���p�ɐݒ� */
		pCidDataArrayNow = Cid_Data_CanId_UserTable;
		search_max = CID_SEARCH_MAX -1U;
	}
	
	/* CANID��T�� */
	while (search_min <= search_max) {
		searchId = ((search_max + search_min) >> 1U);
		if (canId == pCidDataArrayNow[searchId].canid_s) {
			retIndex = searchId;
			break;
		} else if (canId < pCidDataArrayNow[searchId].canid_s) {
			if ((uint32)searchId == (uint32)0) {
				break;
			}
			search_max = searchId - 1U;
		} else {
			search_min = searchId + 1U;
		}
	}

	
	Cid_Notify_SearchResult(rxCh, ptMsg->u4Id, ptMsg->u1Length, ptMsg->ptData, retIndex, pCidDataArrayNow);
	
	return;
}

/*************************************************************************/ /**
 * @fn			uint16 Cid_Search_GetIndexNo(uint32 canId, const uint32 *pCanIdTableNow, uint16 canIdSearchMax)
 * @brief		CANID�T������
 * @details		�e�[�u�����CANID��T����Index�ԍ���Ԃ�
 * @param[in]	uint32 canId								�T��CANID
 * @param[in]	uint32 *pCanIdTableNow						�T������e�[�u��
 * @param[in]	uint16 canIdSearchMax						�T���e�[�u����
 * @return		retIndex									Indexb�ԍ�
 * @attention 	�Ȃ�
 * @note		�Ȃ�
 ****************************************************************************/
uint16 Cid_Search_GetIndexNo(uint32 canId, const uint32 *pCanIdTableNow, uint16 canIdSearchMax)
{
	uint32 recCanId;
	uint16 searchMin = 0x0U;
	uint16 searchMax = canIdSearchMax;
	uint16 searchId;
	uint16 retIndex = CID_NO_SEARCH;

	recCanId = (canId & CID_TCOV_MSK_CANCOM); /* CANFD,�g���r�b�g�𗎂Ƃ� */
	
	/* MAX�l�̒��� */
	if (searchMax != 0U){
		searchMax = searchMax - 1U;
	
		/* CANID��T�� */
		while (searchMin <= searchMax) {
			searchId = ((searchMax + searchMin) >> 1U);
			if (recCanId == pCanIdTableNow[searchId]) {
				retIndex = searchId;
				break;
			} else if (recCanId < pCanIdTableNow[searchId]) {
				if ((uint32)searchId == (uint32)0) {
					break;
				}
				searchMax = searchId - 1U;
			} else {
				searchMin = searchId + 1U;
			}
		}
	}
	return (retIndex);
}

#define GW_CID_STOP_SEC_CODE
#include "GW_Cid_Memmap.h"
