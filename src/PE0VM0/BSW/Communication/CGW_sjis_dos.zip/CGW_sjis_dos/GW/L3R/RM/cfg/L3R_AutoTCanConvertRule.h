/****************************************************************************/
/*	Copyright DENSO Corporation. All rights reserved.                       */
/****************************************************************************/
/*************************************************************************//**
 * @file	    L3R_AutoTCanConvertRule.h
 * @brief	    �ϊ����[��
 * @details	    �@�\�T������
 ****************************************************************************/
/*****************************************************************************
 * @note	�c�[����������
 * @note		����t���[�����[�e�B���O�}�b�v�F
 * @note            Ctrl_RTM.xlsx
 * @note		�_�C�A�O/���v���O�t���[�����[�e�B���O�}�b�v�F
 * @note            Diag_RTM.xlsx
 * @note		�`�����l����`�t�@�C���F
 * @note            channelDef.yml
 * @note		�`�����l����`�t�@�C��(L3R)�F
 * @note            channelDef_L3R.yml
 * @note		��O�t���[����`�t�@�C���F
 * @note            exceptionalMessages.yml
 * @note		�e���v���[�g�t�@�C���F
 * @note            templates_SZK/L3R_AutoTCanConvertRuleH.tmpl
 * @note	�c�[���o�[�W����
 * @note		SMC_4.0.1
 ****************************************************************************/

/*--------------------------------------------------------------------------*/
/*		�Q�d�C���N���[�h�h�~												*/
/*--------------------------------------------------------------------------*/
#ifndef	L3R_AUTOTCANCONVERTRULE_H
#define	L3R_AUTOTCANCONVERTRULE_H


/*--------------------------------------------------------------------------*/
/*		�t�@�C���C���N���[�h												*/
/*--------------------------------------------------------------------------*/
#include "L3R_canmbq_auto_drvcfg_0.h"
#include "L3R_canmbq_auto_drvcfg_1.h"
#include "L3R_canmbq_auto_drvcfg_2.h"
#include "L3R_canmbq_auto_drvcfg_3.h"


/*--------------------------------------------------------------------------*/
/*		�}�N����`															*/
/*--------------------------------------------------------------------------*/
/* CAN�v���g�R����` */
#define L3R_TCAN_IDSTART		(1U)
#define L3R_TCAN_IDNUM			(487U)

#define L3R_TDIAG_IDSTART		(488U)
#define L3R_TDIAG_IDNUM			(0U)

/* ���M�t���[���� */
#define L3R_TCAN_CH0_PRIORITY_0_TXNUM		(0U)
#if (CANMBQ_QUE0_TXQUESIZE_0 < L3R_TCAN_CH0_PRIORITY_0_TXNUM)
#error [QUE0_TXQUESIZE_0 Configuration Error!!]
#endif
#define L3R_TCAN_CH0_PRIORITY_1_TXNUM		(0U)
#if (CANMBQ_QUE1_TXQUESIZE_0 < L3R_TCAN_CH0_PRIORITY_1_TXNUM)
#error [QUE1_TXQUESIZE_0 Configuration Error!!]
#endif
#define L3R_TCAN_CH0_PRIORITY_2_TXNUM		(0U)
#if (CANMBQ_QUE2_TXQUESIZE_0 < L3R_TCAN_CH0_PRIORITY_2_TXNUM)
#error [QUE2_TXQUESIZE_0 Configuration Error!!]
#endif
#define L3R_TCAN_CH0_PRIORITY_3_TXNUM		(0U)
#if (CANMBQ_QUE3_TXQUESIZE_0 < L3R_TCAN_CH0_PRIORITY_3_TXNUM)
#error [QUE3_TXQUESIZE_0 Configuration Error!!]
#endif
#define L3R_TCAN_CH1_PRIORITY_0_TXNUM		(0U)
#if (CANMBQ_QUE0_TXQUESIZE_1 < L3R_TCAN_CH1_PRIORITY_0_TXNUM)
#error [QUE0_TXQUESIZE_1 Configuration Error!!]
#endif
#define L3R_TCAN_CH1_PRIORITY_1_TXNUM		(0U)
#if (CANMBQ_QUE1_TXQUESIZE_1 < L3R_TCAN_CH1_PRIORITY_1_TXNUM)
#error [QUE1_TXQUESIZE_1 Configuration Error!!]
#endif
#define L3R_TCAN_CH1_PRIORITY_2_TXNUM		(79U)
#if (CANMBQ_QUE2_TXQUESIZE_1 < L3R_TCAN_CH1_PRIORITY_2_TXNUM)
#error [QUE2_TXQUESIZE_1 Configuration Error!!]
#endif
#define L3R_TCAN_CH1_PRIORITY_3_TXNUM		(0U)
#if (CANMBQ_QUE3_TXQUESIZE_1 < L3R_TCAN_CH1_PRIORITY_3_TXNUM)
#error [QUE3_TXQUESIZE_1 Configuration Error!!]
#endif
#define L3R_TCAN_CH2_PRIORITY_0_TXNUM		(0U)
#if (CANMBQ_QUE0_TXQUESIZE_2 < L3R_TCAN_CH2_PRIORITY_0_TXNUM)
#error [QUE0_TXQUESIZE_2 Configuration Error!!]
#endif
#define L3R_TCAN_CH2_PRIORITY_1_TXNUM		(0U)
#if (CANMBQ_QUE1_TXQUESIZE_2 < L3R_TCAN_CH2_PRIORITY_1_TXNUM)
#error [QUE1_TXQUESIZE_2 Configuration Error!!]
#endif
#define L3R_TCAN_CH2_PRIORITY_2_TXNUM		(53U)
#if (CANMBQ_QUE2_TXQUESIZE_2 < L3R_TCAN_CH2_PRIORITY_2_TXNUM)
#error [QUE2_TXQUESIZE_2 Configuration Error!!]
#endif
#define L3R_TCAN_CH2_PRIORITY_3_TXNUM		(0U)
#if (CANMBQ_QUE3_TXQUESIZE_2 < L3R_TCAN_CH2_PRIORITY_3_TXNUM)
#error [QUE3_TXQUESIZE_2 Configuration Error!!]
#endif
#define L3R_TCAN_CH3_PRIORITY_0_TXNUM		(7U)
#if (CANMBQ_QUE0_TXQUESIZE_3 < L3R_TCAN_CH3_PRIORITY_0_TXNUM)
#error [QUE0_TXQUESIZE_3 Configuration Error!!]
#endif
#define L3R_TCAN_CH3_PRIORITY_1_TXNUM		(17U)
#if (CANMBQ_QUE1_TXQUESIZE_3 < L3R_TCAN_CH3_PRIORITY_1_TXNUM)
#error [QUE1_TXQUESIZE_3 Configuration Error!!]
#endif
#define L3R_TCAN_CH3_PRIORITY_2_TXNUM		(331U)
#if (CANMBQ_QUE2_TXQUESIZE_3 < L3R_TCAN_CH3_PRIORITY_2_TXNUM)
#error [QUE2_TXQUESIZE_3 Configuration Error!!]
#endif
#define L3R_TCAN_CH3_PRIORITY_3_TXNUM		(0U)
#if (CANMBQ_QUE3_TXQUESIZE_3 < L3R_TCAN_CH3_PRIORITY_3_TXNUM)
#error [QUE3_TXQUESIZE_3 Configuration Error!!]
#endif

/*--------------------------------------------------------------------------*/
/*		�O�����J�ϐ�														*/
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/*		�֐��}�N��															*/
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/*		�v���g�^�C�v�錾													*/
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/*		�Q�d�C���N���[�h�h�~												*/
/*--------------------------------------------------------------------------*/
#endif	/* L3R_AUTOTCANCONVERTRULE_H */
