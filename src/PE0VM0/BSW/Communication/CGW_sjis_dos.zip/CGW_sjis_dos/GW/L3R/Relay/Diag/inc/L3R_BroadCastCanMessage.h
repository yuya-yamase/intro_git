/****************************************************************************/
/*	Copyright DENSO Corporation. All rights reserved.                       */
/****************************************************************************/
/*************************************************************************//**
 * @file	L3R_BroadCastCanMessage.h
 * @brief	
 * @details	
 * @note	�Ȃ�
 * @date	v1.00	2018/01/20	T.Totsuka(FSI)		�V�K�쐬
 * 			v2.00	2018/05/16	T.Yamamura(FSI)		�ω��Ή�
 * 													�E�^�C�v�錾��`��GW_RTR_config.h�ֈړ�
 * 			v2.01	2018/05/23	T.Yamamura(FSI)		�ω��Ή�
 * 													�E�^�C�v�錾��`��GW_RTR_config.h����ړ�
 *													�ECH���؂蕪���ǉ�
 * 			v2.02   2018/05/25  T.Totsuka(FSI) 		�ω��Ή�
 *													�ECH���؂蕪����`�C��
 * 			v2.00	2018/08/24	K.Ito(FSI)			�N���X�^����
 *			v3.00	2018/11/21	Y.Katayama(FSI)		���p���P(�I�u�W�F�N�g�s�ρj
 *			v3.01	2019/03/24	K.Ito(FSI)			[IntegNo.1099809]
 *													[570B-Phase9] �ۑ� ����f�[�^���p���[�h�Ή��ɂ��TMC�Ή�
 *			v4.00	2020/12/07	T.Yamamura(FSI)		[Post19CY] 29Bit�Ή� 
 ****************************************************************************/

/*--------------------------------------------------------------------------*/
/*		�Q�d�C���N���[�h�h�~												*/
/*--------------------------------------------------------------------------*/
#ifndef	L3R_BROADCASTCANMESSAGE_H
#define	L3R_BROADCASTCANMESSAGE_H


/*--------------------------------------------------------------------------*/
/*		�t�@�C���C���N���[�h												*/
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"

#include "L3R_DiagCanMessage.h"

#include "L3R_Section.h"


/*--------------------------------------------------------------------------*/
/*		�}�N����`															*/
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/*		�^�C�v�錾															*/
/*--------------------------------------------------------------------------*/
#define GW_L3R_START_SEC_CONST
#include "GW_L3R_Memmap.h"
extern CanMessageFuncList BroadCastCanMessage_funcList[];
#define GW_L3R_STOP_SEC_CONST
#include "GW_L3R_Memmap.h"
#define	Create_BroadCastCanMessage(name, canid, ch0, ch1, ch2, ch3, ch4, ch5, ch6, ch7, ch8, ch9, ch10, ch11, ch12, ch13, ch14, ch15) \
	Create_DiagCanMessageElements(name, (ch0), (ch1), (ch2), (ch3), (ch4), (ch5), (ch6), (ch7), (ch8), (ch9), (ch10), (ch11), (ch12), (ch13), (ch14), (ch15));	\
	L3R_PRAGMA_SECTION_CONST_START																		\
	static CanMessage (name) = {New_DiagCanMessage(name, (canid), &BroadCastCanMessage_funcList[0])}	\
	L3R_PRAGMA_SECTION_CONST_STOP

/*--------------------------------------------------------------------------*/
/*		�O�����J�ϐ�														*/
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/*		�֐��}�N��															*/
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/*		�v���g�^�C�v�錾													*/
/*--------------------------------------------------------------------------*/
#define GW_L3R_START_SEC_CODE
#include "GW_L3R_Memmap.h"
extern uint16 BroadCastCanMessage_GetGwId(CanMessage *self, uint8 rxCh, uint8 dlc, const uint8* Data, uint16 searchId);
extern void BroadCastCanMessage_RelayData(CanMessage *self, uint8 fd,  uint8 dlc, const uint8* Data, uint16 gwId, uint8 rxCh, uint16 searchId, uint32 canId);
#define GW_L3R_STOP_SEC_CODE
#include "GW_L3R_Memmap.h"


/*--------------------------------------------------------------------------*/
/*		�Q�d�C���N���[�h�h�~												*/
/*--------------------------------------------------------------------------*/
#endif	/* L3R_BROADCASTCANMESSAGE_H */
