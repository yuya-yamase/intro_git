/****************************************************************************/
/*	Copyright DENSO Corporation. All rights reserved.                       */
/****************************************************************************/
/*************************************************************************//**
 * @file	L3R_NullDiagCanMessage.c
 * @brief	
 * @details	
 * @note	�Ȃ�
 * @date	v1.00	2018/01/20	T.Totsuka(FSI)		�V�K�쐬
 * @date	v1.10	2018/02/16	T.Yamamura(FSI)		CANID�t�B���^�Ή�
 *													�֐�CanMessage_ABusErrorHandler�����ǉ�
 * 			v2.00	2018/05/16	T.Yamamura(FSI)		�ω��Ή�
 * 													�EGW_RTR_config.h��CHM_LogicCh.h�ύX
 * 													�ERTR_A_CH��CHM_LOG_CH_A�ύX
 * 			v2.01	2018/07/20	K.Ito(FSI)			A-Bus�t�B���^�폜�Ή�
 * 			v2.00	2018/08/24	K.Ito(FSI)			�N���X�^����
 *			v3.00	2018/11/21	Y.Katayama(FSI)		���p���P(�I�u�W�F�N�g�s�ρj
 ****************************************************************************/

/*--------------------------------------------------------------------------*/
/*		�t�@�C���C���N���[�h												*/
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"

#include "L3R_NullDiagCanMessage.h"


/*--------------------------------------------------------------------------*/
/*		�}�N����`															*/
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/*		�O�����J�ϐ�														*/
/*--------------------------------------------------------------------------*/
#define GW_L3R_START_SEC_CONST
#include "GW_L3R_Memmap.h"
CanMessageFuncList NullDiagCanMessage_funcList[] = { { NullDiagCanMessage_GetGwId, NullCanMessage_RelayData } };
#define GW_L3R_STOP_SEC_CONST
#include "GW_L3R_Memmap.h"


/*--------------------------------------------------------------------------*/
/*		�t�@�C�����ϐ�														*/
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/*		�v���g�^�C�v�錾													*/
/*--------------------------------------------------------------------------*/


#define GW_L3R_START_SEC_CODE
#include "GW_L3R_Memmap.h"
/*************************************************************************//**
 * @fn			uint16 NullDiagCanMessage_GetGwId(CanMessage *self, uint8 rxCh, uint8 dlc, const uint8* Data, uint16 searchId)
 * @brief		GwId�̎擾
 * @details		GwId�̎擾���s��
 * @param[in]	self	���g�ւ̃|�C���^
 * @param[in]	rxCh	��MCH
 * @param[in]	dlc		��M�f�[�^��
 * @param[in]	Data	��M�f�[�^�ւ̃|�C���^
 * @param[in]	searchId	�T���ʒu
 * @return		GwID
 * @attention 	�Ȃ�
 * @note		�Ȃ�
 ****************************************************************************/
uint16 NullDiagCanMessage_GetGwId(CanMessage *self, uint8 rxCh, uint8 dlc, const uint8* Data, uint16 searchId)
{
	return (NULL_GWID);
}

#define GW_L3R_STOP_SEC_CODE
#include "GW_L3R_Memmap.h"
