/****************************************************************************/
/*	Copyright DENSO Corporation. All rights reserved.                       */
/****************************************************************************/
/*************************************************************************//**
 * @file	L3R_QueRouter.h
 * @brief	��MFIFO����
 * @details	
 * @note	�Ȃ�
 * @date	v1.00	2018/01/20	T.Totsuka(FSI)		�V�K�쐬
 * 			v1.01	2018/05/30	A.Yasui(FSI)		�R�[�f�B���O�K��Ή�(inline�֐����Ή�)
 * 			v1.02	2018.05.30	K.Ito(FSI)			�ш搧���폜�Ή�
 * 			v2.00	2018/08/24	K.Ito(FSI)			�N���X�^����
 *			v3.00	2018/11/21	Y.Katayama(FSI)		���p���P(�I�u�W�F�N�g�s�ρj
 *			v4.00	2020/12/07	T.Yamamura(FSI)		[Post19CY] 29Bit�Ή� 
 ****************************************************************************/

/*--------------------------------------------------------------------------*/
/*		�Q�d�C���N���[�h�h�~												*/
/*--------------------------------------------------------------------------*/
#ifndef	L3R_QUEROUTER_H
#define	L3R_QUEROUTER_H


/*--------------------------------------------------------------------------*/
/*		�t�@�C���C���N���[�h												*/
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"

#include "CHM_LogicCh.h"

#include "L3R_CommonBuffer.h"
#include "L3R_config.h"

#include "L3R_Router.h"

#include "L3R_Section.h"


/*--------------------------------------------------------------------------*/
/*		�}�N����`															*/
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/*		�^�C�v�錾															*/
/*--------------------------------------------------------------------------*/
#define	Create_QueRouterElements(name)											\
	/* Create_RouterElements(name); */											\
	L3R_PRAGMA_SECTION_NO_INIT_START											\
	static RouterFields name##Fields;											\
	L3R_PRAGMA_SECTION_NO_INIT_STOP
#define	New_QueRouter(name, className, size, pFields)							\
	New_Router(name, className, (size), (pFields))
#define	Create_QueRouter(name, className, size)									\
	Create_QueRouterElements(name)												\
	L3R_PRAGMA_SECTION_CONST_START												\
	Router (name) = {New_QueRouter(name, className, (size), &(name##Fields))}	\
	L3R_PRAGMA_SECTION_CONST_STOP

/*--------------------------------------------------------------------------*/
/*		�O�����J�ϐ�														*/
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/*		�֐��}�N��															*/
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/*		�v���g�^�C�v�錾													*/
/*--------------------------------------------------------------------------*/
#define GW_L3R_START_SEC_CODE
#include "GW_L3R_Memmap.h"
extern void QueRouter_Init(Router *self);
extern CommonBuffer *QueRouter_RelayData(Router *self, uint32 canId, uint8 dlc, const uint8* Data, uint16 gwId, uint16 searchId, uint8 fd);
extern CommonBuffer *QueRouter_SendData(Router *self, CommonBuffer *pCommonBuffer);
extern CommonBuffer *QueRouter_RelayDataByBuffer(Router *self, CommonBuffer *pCommonBuffer, uint32 canId, uint8 dlc, const uint8* Data, uint16 gwId, uint16 searchId);
extern void QueRouter_SendReq(CommonBuffer *pCommonBuffer);
extern void QueRouter_DriverTask(Router *self);
extern void QueRouter_MainTask(Router *self);
extern void QueRouter_ClearCh(Router *self, uint8 ch);
#define GW_L3R_STOP_SEC_CODE
#include "GW_L3R_Memmap.h"

#define GW_L3R_START_SEC_CONST
#include "GW_L3R_Memmap.h"
extern void ( *const L3R_SendReqQueFuncTbl[CHM_LOG_ALL_CH_NUM])(uint8 ch, CommonBuffer *const pCommonBuffer);
#define GW_L3R_STOP_SEC_CONST
#include "GW_L3R_Memmap.h"

/*--------------------------------------------------------------------------*/
/*		�Q�d�C���N���[�h�h�~												*/
/*--------------------------------------------------------------------------*/
#endif	/* L3R_QUEROUTER_H */
