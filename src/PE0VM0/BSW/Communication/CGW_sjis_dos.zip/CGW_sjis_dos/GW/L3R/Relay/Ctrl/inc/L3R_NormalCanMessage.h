/****************************************************************************/
/*	Copyright DENSO Corporation. All rights reserved.                       */
/****************************************************************************/
/*************************************************************************//**
 * @file	L3R_NormalCanMessage.h
 * @brief	
 * @details	
 * @note	�Ȃ�
 * @date	v1.00	2018/01/20	T.Totsuka(FSI)		�V�K�쐬
 * 			v2.00	2018/05/16	T.Yamamura(FSI)		�ω��Ή�
 * 													�E�^�C�v�錾��`��GW_RTR_config.h�ֈړ�
 * 													�EL3R_DynamicCanMessage.h�̃C���N���[�h�폜
 * 			v2.01	2018/05/23	T.Yamamura(FSI)		�ω��Ή�
 * 													�E�^�C�v�錾��`��GW_RTR_config.h����ړ�
 *													�ECH���؂蕪���ǉ�
 * 			v2.02   2018/05/25  T.Totsuka(FSI) 		�ω��Ή�
 *													�ECH���؂蕪����`�C��
 * 			v3.00	2018/08/24	K.Ito(FSI)			�N���X�^����
 *			v4.00	2018/11/21	Y.Katayama(FSI)		���p���P(�I�u�W�F�N�g�s�ρj
 * 			v5.00	2018/12/25	T.Yamamura(FSI)		�V�A�[�L�e�N�`��SBR�d�l�K���Ή�
 * 													����f�[�^���p���[�h�Ή�
 *			v6.00	2020/12/07	T.Yamamura(FSI)		[Post19CY] 29Bit�Ή� 
 ****************************************************************************/

/*--------------------------------------------------------------------------*/
/*		�Q�d�C���N���[�h�h�~												*/
/*--------------------------------------------------------------------------*/
#ifndef	L3R_NORMALCANMESSAGE_H
#define	L3R_NORMALCANMESSAGE_H


/*--------------------------------------------------------------------------*/
/*		�t�@�C���C���N���[�h												*/
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"

#include "CHM_LogicCh.h"

#include "L3R_config.h"
#include "L3R_DynamicCanMessage.h"

#include "L3R_Section.h"


/*--------------------------------------------------------------------------*/
/*		�}�N����`															*/
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/*		�^�C�v�錾															*/
/*--------------------------------------------------------------------------*/
#define GW_L3R_START_SEC_CONST
#include "GW_L3R_Memmap.h"
extern CanMessageFuncList NormalCanMessage_funcList[];
#define GW_L3R_STOP_SEC_CONST
#include "GW_L3R_Memmap.h"
#define	Create_NormalCanMessageElements(name, ch0, ch1, ch2, ch3, ch4, ch5, ch6, ch7, ch8, ch9, ch10, ch11, ch12, ch13, ch14, ch15)	\
	Create_DynamicCanMessageElements(name);									\
	L3R_PRAGMA_SECTION_CONST_START											\
	static const uint16 name##_aGwId[CHM_LOG_ALL_CH_NUM] = CH_ARRY((ch0), (ch1), (ch2), (ch3), (ch4), (ch5), (ch6), (ch7), (ch8), (ch9), (ch10), (ch11), (ch12), (ch13), (ch14), (ch15))	\
	L3R_PRAGMA_SECTION_CONST_STOP
#define	New_NormalCanMessage(name, canid, canMessageFuncList)				\
	New_DynamicCanMessage(name, (canid), (canMessageFuncList), name##_aGwId)

#define	Create_NormalCanMessage(name, canid, ch0, ch1, ch2, ch3, ch4, ch5, ch6, ch7, ch8, ch9, ch10, ch11, ch12, ch13, ch14, ch15) \
	Create_NormalCanMessageElements(name, (ch0), (ch1), (ch2), (ch3), (ch4), (ch5), (ch6), (ch7), (ch8), (ch9), (ch10), (ch11), (ch12), (ch13), (ch14), (ch15));	\
	L3R_PRAGMA_SECTION_CONST_START											\
	static CanMessage (name) = {New_NormalCanMessage(name, (canid), &NormalCanMessage_funcList[0])}	\
	L3R_PRAGMA_SECTION_CONST_STOP

/*--------------------------------------------------------------------------*/
/*		�O�����J�ϐ�														*/
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/*		�֐��}�N��															*/
/*--------------------------------------------------------------------------*/
/**
 * @fn			NormalCanMessage_Init()
 * @brief		����������
 * @details		�������������s��
 * @param		�Ȃ�
 * @return		�Ȃ�
 * @attention	�Ȃ�
 * @note		�Ȃ�
 */
#define NormalCanMessage_Init() CanMessage_Init()


/*--------------------------------------------------------------------------*/
/*		�v���g�^�C�v�錾													*/
/*--------------------------------------------------------------------------*/
#define GW_L3R_START_SEC_CODE
#include "GW_L3R_Memmap.h"
extern uint16 NormalCanMessage_GetGwId(CanMessage *self, uint8 rxCh, uint8 dlc, const uint8* Data, uint16 searchId);
extern void NormalCanMessage_RelayData(CanMessage *self, uint8 fd, uint8 dlc, const uint8* Data, uint16 gwId, uint8 rxCh, uint16 searchId);
#define GW_L3R_STOP_SEC_CODE
#include "GW_L3R_Memmap.h"


/*--------------------------------------------------------------------------*/
/*		�Q�d�C���N���[�h�h�~												*/
/*--------------------------------------------------------------------------*/
#endif	/* L3R_NORMALCANMESSAGE_H */
