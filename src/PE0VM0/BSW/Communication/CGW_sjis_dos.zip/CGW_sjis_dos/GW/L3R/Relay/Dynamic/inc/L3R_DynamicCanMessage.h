/****************************************************************************/
/*	Copyright DENSO Corporation. All rights reserved.                       */
/****************************************************************************/
/*************************************************************************//**
 * @file	L3R_DynamicCanMessage.h
 * @brief	
 * @details	
 * @note	�Ȃ�
 * @date	v1.00	2018/01/20	T.Totsuka(FSI)		�V�K�쐬
 * 			v2.00	2018/08/24	K.Ito(FSI)			�N���X�^����
 *			v3.00	2018/11/21	Y.Katayama(FSI)		���p���P(�I�u�W�F�N�g�s�ρj
 * 			v3.01	2019/03/24	K.Ito(FSI)			[IntegNo.1099809]
 *													[570B-Phase9] �ۑ� ����f�[�^���p���[�h�Ή��ɂ��TMC�Ή�
 ****************************************************************************/

/*--------------------------------------------------------------------------*/
/*		�Q�d�C���N���[�h�h�~												*/
/*--------------------------------------------------------------------------*/
#ifndef	L3R_DYNAMICCANMESSAGE_H
#define	L3R_DYNAMICCANMESSAGE_H


/*--------------------------------------------------------------------------*/
/*		�t�@�C���C���N���[�h												*/
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"
#include "L3R_CommonBuffer.h"

#include "L3R_CanMessage.h"

#include "L3R_Section.h"


/*--------------------------------------------------------------------------*/
/*		�}�N����`															*/
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/*		�^�C�v�錾															*/
/*--------------------------------------------------------------------------*/
#define GW_L3R_START_SEC_CONST
#include "GW_L3R_Memmap.h"
extern CanMessageFuncList DynamicCanMessage_funcList[];
#define GW_L3R_STOP_SEC_CONST
#include "GW_L3R_Memmap.h"

#define	Create_DynamicCanMessageElements(name)								\
	Create_CanMessageBackUpElements(name);									\
	L3R_PRAGMA_SECTION_DATA_START											\
	static CommonBuffer *(name##CommonBuffer) = NULL_PTR					\
	L3R_PRAGMA_SECTION_DATA_STOP
#define	New_DynamicCanMessage(name, canid, canMessageFuncList, GwId)		\
	New_CanMessage(name, (canid), (canMessageFuncList), name##CommonBuffer, (GwId))
	
#define	Create_DynamicCanMessage(name, canid)								\
	Create_DynamicCanMessageElements(name);									\
	L3R_PRAGMA_SECTION_CONST_START											\
	static CanMessage (name) = {New_DynamicCanMessage(name, (canid), &DynamicCanMessage_funcList[0], &CanMessage_aGwId[0])}	\
	L3R_PRAGMA_SECTION_CONST_STOP

/*--------------------------------------------------------------------------*/
/*		�O�����J�ϐ�														*/
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/*		�֐��}�N��															*/
/*--------------------------------------------------------------------------*/
/**
 * @fn			DynamicCanMessage_Init()
 * @brief		����������
 * @details		�������������s��
 * @param		�Ȃ�
 * @return		�Ȃ�
 * @attention	�Ȃ�
 * @note		�Ȃ�
 */
#define DynamicCanMessage_Init() CanMessage_Init()


/*--------------------------------------------------------------------------*/
/*		�v���g�^�C�v�錾													*/
/*--------------------------------------------------------------------------*/
#define GW_L3R_START_SEC_CODE
#include "GW_L3R_Memmap.h"
extern uint16 DynamicCanMessage_GetGwId(CanMessage *self, uint8 rxCh, uint8 dlc, const uint8* Data, uint16 searchId);
extern void DynamicCanMessage_RelayData(CanMessage *self, uint8 fd, uint8 dlc, const uint8* Data, uint16 gwId, uint8 rxCh, uint16 searchId);
#define GW_L3R_STOP_SEC_CODE
#include "GW_L3R_Memmap.h"


/*--------------------------------------------------------------------------*/
/*		�Q�d�C���N���[�h�h�~												*/
/*--------------------------------------------------------------------------*/
#endif	/* L3R_DYNAMICCANMESSAGE_H */
