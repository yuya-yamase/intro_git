/****************************************************************************/
/* Copyright DENSO Corporation. All rights reserved                         */
/*************************************************************************//**
 * @file L3R_Section.h
 ****************************************************************************/
#ifndef L3R_SECTION_H
#define L3R_SECTION_H

#include "Section_Util.h"

#define L3R_PRAGMA_SECTION_CODE_START PRAGMA_SECTION(text, ".gw_l3r_code")
#define L3R_PRAGMA_SECTION_CODE_STOP  PRAGMA_SECTION_DEFAULT(text)

#define L3R_PRAGMA_SECTION_CONST_START PRAGMA_SECTION(rodata, ".gw_l3r_const")
#define L3R_PRAGMA_SECTION_CONST_STOP  PRAGMA_SECTION_DEFAULT(rodata)

#define L3R_PRAGMA_SECTION_DATA_START PRAGMA_SECTION(data, ".gw_l3r_data")
#define L3R_PRAGMA_SECTION_DATA_STOP  PRAGMA_SECTION_DEFAULT(data)

#define L3R_PRAGMA_SECTION_NO_INIT_START PRAGMA_SECTION(bss, ".gw_l3r_no_init")
#define L3R_PRAGMA_SECTION_NO_INIT_STOP  PRAGMA_SECTION_DEFAULT(bss)

#define L3R_PRAGMA_SECTION_DATA_BKUP_START PRAGMA_SECTION(data, ".gw_l3r_data_bkup")
#define L3R_PRAGMA_SECTION_DATA_BKUP_STOP  PRAGMA_SECTION_DEFAULT(data)

#define L3R_PRAGMA_SECTION_NO_INIT_BKUP_START PRAGMA_SECTION(bss, ".gw_l3r_no_init_bkup")
#define L3R_PRAGMA_SECTION_NO_INIT_BKUP_STOP  PRAGMA_SECTION_DEFAULT(bss)


#endif /* L3R_SECTION_H */

