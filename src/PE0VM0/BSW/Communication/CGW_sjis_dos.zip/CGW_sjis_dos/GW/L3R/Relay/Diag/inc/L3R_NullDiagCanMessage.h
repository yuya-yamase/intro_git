/****************************************************************************/
/*	Copyright DENSO Corporation. All rights reserved.                       */
/****************************************************************************/
/*************************************************************************//**
 * @file	L3R_NullDiagCanMessage.h
 * @brief	
 * @details	
 * @note	�Ȃ�
 * @date	v1.00	2018/01/20	T.Totsuka(FSI)		�V�K�쐬
 * 			v2.00	2018/08/24	K.Ito(FSI)			�N���X�^����
 *			v3.00	2018/11/21	Y.Katayama(FSI)		���p���P(�I�u�W�F�N�g�s�ρj
 ****************************************************************************/

/*--------------------------------------------------------------------------*/
/*		�Q�d�C���N���[�h�h�~												*/
/*--------------------------------------------------------------------------*/
#ifndef	L3R_NULLDIAGCANMESSAGE_H
#define	L3R_NULLDIAGCANMESSAGE_H

/*--------------------------------------------------------------------------*/
/*		�t�@�C���C���N���[�h												*/
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"

#include "L3R_NullCanMessage.h"

#include "L3R_Section.h"


/*--------------------------------------------------------------------------*/
/*		�}�N����`															*/
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/*		�^�C�v�錾															*/
/*--------------------------------------------------------------------------*/
#define GW_L3R_START_SEC_CONST
#include "GW_L3R_Memmap.h"
extern CanMessageFuncList NullDiagCanMessage_funcList[];
#define GW_L3R_STOP_SEC_CONST
#include "GW_L3R_Memmap.h"
#define	Create_NullDiagCanMessage(name, canid)								\
	/* Create_CanMessageElements(name); */									\
	L3R_PRAGMA_SECTION_CONST_START											\
	static CanMessage (name) = {New_CanMessageNull(name, (canid), &NullDiagCanMessage_funcList[0])}	\
	L3R_PRAGMA_SECTION_CONST_STOP

/*--------------------------------------------------------------------------*/
/*		�O�����J�ϐ�														*/
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
/*		�֐��}�N��															*/
/*--------------------------------------------------------------------------*/
/**
 * @fn			NullDiagCanMessage_Init()
 * @brief		����������
 * @details		�������������s��
 * @param		�Ȃ�
 * @return		�Ȃ�
 * @attention	�Ȃ�
 * @note		�Ȃ�
 */
#define NullDiagCanMessage_Init() CanMessage_Init()


/*--------------------------------------------------------------------------*/
/*		�v���g�^�C�v�錾													*/
/*--------------------------------------------------------------------------*/
#define GW_L3R_START_SEC_CODE
#include "GW_L3R_Memmap.h"
extern uint16 NullDiagCanMessage_GetGwId(CanMessage *self, uint8 rxCh, uint8 dlc, const uint8* Data, uint16 searchId);
#define GW_L3R_STOP_SEC_CODE
#include "GW_L3R_Memmap.h"


/*--------------------------------------------------------------------------*/
/*		�Q�d�C���N���[�h�h�~												*/
/*--------------------------------------------------------------------------*/
#endif	/* L3R_NULLDIAGCANMESSAGE_H */
