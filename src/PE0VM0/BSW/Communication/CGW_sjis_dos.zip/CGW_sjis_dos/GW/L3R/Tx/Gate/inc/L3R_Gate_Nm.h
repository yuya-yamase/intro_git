/****************************************************************************/
/*	Copyright DENSO Corporation. All rights reserved.                       */
/****************************************************************************/
/*************************************************************************//**
 * @file		L3R_Gate_Nm.h
 * @brief		
 * @details		
 * @note	
 * @date		v1.00   2016/04/01  H.Tanaka    �V�K�쐬 
 * @date		v1.01   2017/03/03  Y.Katayama  19PF�����^��`�Ή� 
 * @date		v2.00	2018/11/21	Y.Katayama	���p���P(�I�u�W�F�N�g�s��)
 ****************************************************************************/

#ifndef	L3R_GATE_NM_H
#define	L3R_GATE_NM_H


/*----�O���ϐ��錾�E�ϐ����u���}�N��-----------------------------------------*/


/*----�v���g�^�C�v�錾------------------------------------------------------*/

#define GW_L3R_START_SEC_CODE
#include "GW_L3R_Memmap.h"
extern uint8 L3R_NGate_Nm_Init(void);
extern uint8 L3R_NGate_Nm_Start(uint8 NetSts);
extern uint8 L3R_NGate_Nm_Stop(uint8 NetSts);
extern uint8 L3R_NGate_Nm_Standby(uint8 NetSts);
extern uint8 L3R_NGate_Nm_Defect(void);
#define GW_L3R_STOP_SEC_CODE
#include "GW_L3R_Memmap.h"

#endif	/* L3R_GATE_NM_H */
