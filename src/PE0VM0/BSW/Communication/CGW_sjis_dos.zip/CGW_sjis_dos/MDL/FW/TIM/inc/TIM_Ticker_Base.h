 /****************************************************************************
 *  Copyright (c) 2010-11 Denso Corporation
 *  �@�\            �x�[�X�`�b�J
 *
 *  ���l            �A�v���X�P�W���[���Ƃ�IF
 ****************************************************************************/
#ifndef TIM_TICKER_BASE_H
#define TIM_TICKER_BASE_H

#include "Std_Types.h"
#include "TIM_Cfg.h"

#define GW_FW_START_SEC_CODE
#include "GW_FW_Memmap.h"

void TIM_Ticker_Base_TickBaseTime(void);
boolean TIM_Ticker_Base_CanTickScTimer(void);
boolean TIM_Ticker_Base_CanTickMnTimer(void);
#ifdef _DEBUG
void TIM_Ticker_Base_DebugInit(void);
#endif

#define GW_FW_STOP_SEC_CODE
#include "GW_FW_Memmap.h"

#define TIM_Ticker_Base_ChkEnableSleep()		\
	do {										\
		Util_Ticker_checkSleepNGAll();			\
		TIM_Ticker_Base_TickBaseTime();			\
	} while(0)

#define TIM_Ticker_Base_TickID()				\
	do {										\
		Util_Ticker_ID_MS_tick();				\
		Util_Ticker_ID_SMS_tick();				\
		if( TIM_Ticker_Base_CanTickScTimer() ){ \
			Util_Ticker_ID_SC_tick();			\
			Util_Ticker_ID_SSC_tick();			\
		}										\
		if( TIM_Ticker_Base_CanTickMnTimer() ){	\
			Util_Ticker_ID_MN_tick();			\
			Util_Ticker_ID_DMN_tick();			\
			Util_Ticker_ID_SMN_tick();			\
		}										\
	} while(0)

#define TIM_Ticker_Base_TickIM()				\
	do {										\
		Util_Ticker_IM_MS_tick();				\
		Util_Ticker_IM_SMS_tick();				\
		if( TIM_Ticker_Base_CanTickScTimer() ){	\
			Util_Ticker_IM_SC_tick();			\
			Util_Ticker_IM_SSC_tick();			\
		}										\
		if( TIM_Ticker_Base_CanTickMnTimer() ){	\
			Util_Ticker_IM_MN_tick();			\
			Util_Ticker_IM_DMN_tick();			\
			Util_Ticker_IM_SMN_tick();			\
		}										\
	} while(0)

#define TIM_Ticker_Base_TickAP()				\
	do {										\
		Util_Ticker_AP_MS_tick();				\
		Util_Ticker_AP_SMS_tick();				\
	    if( TIM_Ticker_Base_CanTickScTimer() ){	\
	    	Util_Ticker_AP_SC_tick();			\
	    	Util_Ticker_AP_SSC_tick();			\
	    }										\
	    if( TIM_Ticker_Base_CanTickMnTimer() ){	\
	    	Util_Ticker_AP_MN_tick();			\
	    	Util_Ticker_AP_DMN_tick();			\
	    	Util_Ticker_AP_SMN_tick();			\
	    }										\
	} while(0)

#define TIM_Ticker_Base_TickOM() 				\
	do {										\
		Util_Ticker_OM_MS_tick();				\
		Util_Ticker_OM_SMS_tick();				\
		if( TIM_Ticker_Base_CanTickScTimer() ){	\
			Util_Ticker_OM_SC_tick();			\
			Util_Ticker_OM_SSC_tick();			\
		}										\
		if( TIM_Ticker_Base_CanTickMnTimer() ){	\
			Util_Ticker_OM_MN_tick();			\
			Util_Ticker_OM_DMN_tick();			\
			Util_Ticker_OM_SMN_tick();			\
		}										\
	} while(0)

#define TIM_Ticker_Base_TickOD()				\
	do {										\
		Util_Ticker_OD_MS_tick();				\
		Util_Ticker_OD_SMS_tick();				\
		if( TIM_Ticker_Base_CanTickScTimer() ){	\
			Util_Ticker_OD_SC_tick();			\
			Util_Ticker_OD_SSC_tick();			\
		}										\
		if( TIM_Ticker_Base_CanTickMnTimer() ){	\
			Util_Ticker_OD_MN_tick();			\
			Util_Ticker_OD_DMN_tick();			\
			Util_Ticker_OD_SMN_tick();			\
		}										\
	} while(0)

#define TIM_Ticker_Base_InitSlpInTimer()		\
	do {										\
		Util_Ticker_initSlpInTimerAll();		\
	} while(0)



#endif /* TIM_TICKER_BASE_H */
