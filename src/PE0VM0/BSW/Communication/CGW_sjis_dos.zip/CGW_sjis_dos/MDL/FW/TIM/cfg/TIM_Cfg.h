 /****************************************************************************
 *  Copyright (c) 2010-11 Denso Corporation
 *  �@�\            �^�C�}���g�p����ID���`����
 *
 *  ���l            CodeGenFW���玩������
 ****************************************************************************/

#ifndef TIM_CFG_H
#define TIM_CFG_H



#define NO_USE ( -1 )

/*********************
 * ID��`
 *********************/


/*********************
 * startID�AstopID��`
 *********************/
/* �e�`�b�J�P�� */
/*** Normal�`�b�J ***/
#define UTIL_TIMER_ID_MS_START_ID  (NO_USE)
#define UTIL_TIMER_ID_MS_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_ID_SC_START_ID  (NO_USE)
#define UTIL_TIMER_ID_SC_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_ID_MN_START_ID  (NO_USE)
#define UTIL_TIMER_ID_MN_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_IM_MS_START_ID  (NO_USE)
#define UTIL_TIMER_IM_MS_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_IM_SC_START_ID  (NO_USE)
#define UTIL_TIMER_IM_SC_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_IM_MN_START_ID  (NO_USE)
#define UTIL_TIMER_IM_MN_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_AP_MS_START_ID  (NO_USE)
#define UTIL_TIMER_AP_MS_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_AP_SC_START_ID  (NO_USE)
#define UTIL_TIMER_AP_SC_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_AP_MN_START_ID  (NO_USE)
#define UTIL_TIMER_AP_MN_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_OM_MS_START_ID  (NO_USE)
#define UTIL_TIMER_OM_MS_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_OM_SC_START_ID  (NO_USE)
#define UTIL_TIMER_OM_SC_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_OM_MN_START_ID  (NO_USE)
#define UTIL_TIMER_OM_MN_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_OD_MS_START_ID  (NO_USE)
#define UTIL_TIMER_OD_MS_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_OD_SC_START_ID  (NO_USE)
#define UTIL_TIMER_OD_SC_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_OD_MN_START_ID  (NO_USE)
#define UTIL_TIMER_OD_MN_STOP_ID  (NO_USE)
        
/*** Dozy�`�b�J ***/
#define UTIL_TIMER_ID_DMN_START_ID  (NO_USE)
#define UTIL_TIMER_ID_DMN_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_IM_DMN_START_ID  (NO_USE)
#define UTIL_TIMER_IM_DMN_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_AP_DMN_START_ID  (NO_USE)
#define UTIL_TIMER_AP_DMN_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_OM_DMN_START_ID  (NO_USE)
#define UTIL_TIMER_OM_DMN_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_OD_DMN_START_ID  (NO_USE)
#define UTIL_TIMER_OD_DMN_STOP_ID  (NO_USE)
        
/*** SlpIn�`�b�J ***/
#define UTIL_TIMER_ID_SMS_START_ID  (NO_USE)
#define UTIL_TIMER_ID_SMS_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_ID_SSC_START_ID  (NO_USE)
#define UTIL_TIMER_ID_SSC_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_ID_SMN_START_ID  (NO_USE)
#define UTIL_TIMER_ID_SMN_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_IM_SMS_START_ID  (NO_USE)
#define UTIL_TIMER_IM_SMS_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_IM_SSC_START_ID  (NO_USE)
#define UTIL_TIMER_IM_SSC_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_IM_SMN_START_ID  (NO_USE)
#define UTIL_TIMER_IM_SMN_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_AP_SMS_START_ID  (NO_USE)
#define UTIL_TIMER_AP_SMS_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_AP_SSC_START_ID  (NO_USE)
#define UTIL_TIMER_AP_SSC_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_AP_SMN_START_ID  (NO_USE)
#define UTIL_TIMER_AP_SMN_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_OM_SMS_START_ID  (NO_USE)
#define UTIL_TIMER_OM_SMS_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_OM_SSC_START_ID  (NO_USE)
#define UTIL_TIMER_OM_SSC_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_OM_SMN_START_ID  (NO_USE)
#define UTIL_TIMER_OM_SMN_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_OD_SMS_START_ID  (NO_USE)
#define UTIL_TIMER_OD_SMS_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_OD_SSC_START_ID  (NO_USE)
#define UTIL_TIMER_OD_SSC_STOP_ID  (NO_USE)
        
#define UTIL_TIMER_OD_SMN_START_ID  (NO_USE)
#define UTIL_TIMER_OD_SMN_STOP_ID  (NO_USE)
        
/* ��ޒP�� */
/*** Normal�`�b�J ***/
#define UTIL_TIMER_NORMAL_START_ID  (NO_USE)
#define UTIL_TIMER_NORMAL_STOP_ID  (NO_USE)

/*** Dozy�`�b�J ***/
#define UTIL_TIMER_DOZY_START_ID  (NO_USE)
#define UTIL_TIMER_DOZY_STOP_ID  (NO_USE)

/*** SlpIn�`�b�J ***/
#define UTIL_TIMER_SLPIN_START_ID  (NO_USE)
#define UTIL_TIMER_SLPIN_STOP_ID  (NO_USE)

/*** �S�`�b�J ***/
#define UTIL_TIMER_ALL_START_ID		(NO_USE)
#define UTIL_TIMER_ALL_STOP_ID		(NO_USE)


#endif /* TIM_CFG_H */
