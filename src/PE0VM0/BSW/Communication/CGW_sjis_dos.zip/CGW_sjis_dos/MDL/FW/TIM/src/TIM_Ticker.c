/****************************************************************************
 *  Copyright (c) 2010-11 Denso Corporation
 *  �@�\            �{�f�[�A�v�������p����^�C�}�@�\��񋟂���
 *
 *  ���l            �Ȃ�
 ****************************************************************************/
#include "Std_Types.h"
#include "GSS.h"
#include "UTIL_SLIB.h"
#include "TIM.h"
#include "TIM_Ticker.h"

#define TICK_FORWARDTIME	(1U)	/* tick���ɐi�߂鎞�� */

#define GW_FW_START_SEC_CODE
#include "GW_FW_Memmap.h"

static void TIM_Ticking( const uint16 startID, const uint16 timerNum, const uint16 counter );

void TIM_Ticker_Tick( const uint16 startID, const uint16 timerNum )
{
	TIM_Ticking( startID, timerNum, TICK_FORWARDTIME );
	return;
}

void TIM_Ticker_ChkEnableSleep( const uint16 timerNum )
{
	uint32 index;
	uint16 *const timer = Util_Timer_Time;

	GSS_clearRunRequest( GSS_RUNREQ_TIMER );
	for ( index = (uint32)0U; index < (uint32)timerNum; index++ ) {
		if ( (uint32)timer[index] > (uint32)0U ) {
			GSS_setRunRequest( GSS_RUNREQ_TIMER );
			break;
		}
	}
	return;
}

/*
 * SlpIn�`�b�J�̏�����
 * @attention Sleepy�ڍs�t�b�N�ŃR�[������邽�߁A���荞�݋֎~��݂���
 */
void TIM_Ticker_InitSlpInTimer( const uint16 startID, const uint16 timerNum ){
	uint32 index;
	uint16 * timer;
	if( (uint32)startID < UTIL_TIMER_ALL_NUM ){
		timer = &(Util_Timer_Time[startID]);

		for( index = (uint32)0U; index < (uint32)timerNum; index++ ){
			timer[index] = 0U;
		}
	}

	return;
}

static void TIM_Ticking( const uint16 startID, const uint16 timerNum, const uint16 counter ) {
	uint32 index;
	uint16 * timer;
	ST_TMR_FUNC * list;
	if( (uint32)startID < UTIL_TIMER_ALL_NUM ){
		timer = &(Util_Timer_Time[startID]);
		list = &(Util_Timer_Function[startID]);

		for ( index = (uint32)0U; index < (uint32)timerNum; index++ ) {
			if ( (uint32)timer[index] > (uint32)0U ) {
				timer[index] = UTIL_SubU2( timer[index], counter );
				if ( (uint32)timer[index] == (uint32)0U ) {
					if ( (list[index]._function ) != NULL_PTR) {
						( list[index]._function )( list[index]._quote );
					}
				}
			}
		}
	}
	return;
}

#ifdef _DEBUG
/**
 *�@�������֐��i�e�X�g�p�j
 * @param �Ȃ�
 * @return �Ȃ�
 * @attention �e�X�g�P�[�X���ɏ���������K�v������ꍇ�ɌĂяo��
 */
void TIM_Ticker_DebugInit(void)
{
	uint32 i;
	
	for (i = 0U; i < UTIL_TIMER_ALL_NUM; i++) {
		Util_Timer_Time[i] = 0U;
	}
	return;
}
#endif

#define GW_FW_STOP_SEC_CODE
#include "GW_FW_Memmap.h"

