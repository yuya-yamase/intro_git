/****************************************************************************/
/*            Copyright DENSO Corporation. All rights reserved.             */
/****************************************************************************/
/*************************************************************************//**
 * @file        SCH.h
 * @brief       �t���[�����[�N �X�P�W���[�� �O�����J�w�b�_
 * @details     �X�P�W���[���O�����J�w�b�_
 * @date        
 * @attention   �Ȃ�
 * @note        CodeGenFW�ɂ�萶��
 ****************************************************************************/
#ifndef SCH_H
#define SCH_H

/*--------------------------------------------------------------------------*/
/* �t�@�C���C���N���[�h                                                     */
/*--------------------------------------------------------------------------*/
#include "CS_Can.h"
#include "TIM.h"
#include "L3R.h"
#include "EVT.h"
#include "INFR_SysTimer.h"
#include "L3R_canmbq_main.h"
//#include "Cgw_oem.h"

/*--------------------------------------------------------------------------*/
/* inline�֐�                                                               */
/*--------------------------------------------------------------------------*/

/*----- ���̓h���C�o (InDrv) Hook ------------------------------------------*/
static inline void SCH_startupInDrvHook_0(void) __attribute__((always_inline));
static inline void SCH_startupInDrvHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    TIM_Ticker_Base_TickID();
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    BswM_CS_MainFunctionMiddle();
    L3R_System_MainInDrvTask();
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_runInDrvHook_0(void) __attribute__((always_inline));
static inline void SCH_runInDrvHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    TIM_Ticker_Base_TickID();
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    BswM_CS_MainFunctionMiddle();
    L3R_System_MainInDrvTask();
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_postRunInDrvHook_0(void) __attribute__((always_inline));
static inline void SCH_postRunInDrvHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    BswM_CS_MainFunctionMiddle();
    L3R_System_MainInDrvTask();
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_wakeupInDrvHook_DeepS_0(void) __attribute__((always_inline));
static inline void SCH_wakeupInDrvHook_DeepS_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    BswM_CS_MainFunctionMiddle();
    L3R_System_MainInDrvTask();
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

/*----- ���͒��� (InMed) Hook ----------------------------------------------*/
static inline void SCH_startupInMedHook_0(void) __attribute__((always_inline));
static inline void SCH_startupInMedHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    TIM_Ticker_Base_TickIM();
    EVT_DispatchInMed();
    INFR_SysTimer_Update();
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    L3R_System_MainInMedTask();
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_runInMedHook_0(void) __attribute__((always_inline));
static inline void SCH_runInMedHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    TIM_Ticker_Base_TickIM();
    EVT_DispatchInMed();
    INFR_SysTimer_Update();
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    L3R_System_MainInMedTask();
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_postRunInMedHook_0(void) __attribute__((always_inline));
static inline void SCH_postRunInMedHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    EVT_DispatchInMed();
    INFR_SysTimer_Update();
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    L3R_System_MainInMedTask();
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_wakeupInMedHook_DeepS_0(void) __attribute__((always_inline));
static inline void SCH_wakeupInMedHook_DeepS_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    EVT_DispatchInMed();
    INFR_SysTimer_Update();
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    L3R_System_MainInMedTask();
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

/*----- �A�v���P�[�V���� (App) Hook ----------------------------------------*/
static inline void SCH_startupAppHook_0(void) __attribute__((always_inline));
static inline void SCH_startupAppHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    TIM_Ticker_Base_TickAP();
    EVT_DispatchApp();
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    CANMBQ_Omed_Er();
    L3R_System_MainAppTask();
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_runAppHook_0(void) __attribute__((always_inline));
static inline void SCH_runAppHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    TIM_Ticker_Base_TickAP();
    EVT_DispatchApp();
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    CANMBQ_Omed_Er();
    L3R_System_MainAppTask();
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_postRunAppHook_0(void) __attribute__((always_inline));
static inline void SCH_postRunAppHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    EVT_DispatchApp();
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    CANMBQ_Omed_Er();
    L3R_System_MainAppTask();
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_wakeupAppHook_DeepS_0(void) __attribute__((always_inline));
static inline void SCH_wakeupAppHook_DeepS_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    EVT_DispatchApp();
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    CANMBQ_Omed_Er();
    L3R_System_MainAppTask();
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

/*----- �o�͒��� (OutMed) Hook ---------------------------------------------*/
static inline void SCH_startupOutMedHook_0(void) __attribute__((always_inline));
static inline void SCH_startupOutMedHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    TIM_Ticker_Base_TickOM();
    EVT_DispatchOutMed();
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    L3R_System_MainOutMedTask();
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_runOutMedHook_0(void) __attribute__((always_inline));
static inline void SCH_runOutMedHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    TIM_Ticker_Base_TickOM();
    EVT_DispatchOutMed();
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    L3R_System_MainOutMedTask();
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_postRunOutMedHook_0(void) __attribute__((always_inline));
static inline void SCH_postRunOutMedHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    EVT_DispatchOutMed();
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    L3R_System_MainOutMedTask();
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_wakeupOutMedHook_DeepS_0(void) __attribute__((always_inline));
static inline void SCH_wakeupOutMedHook_DeepS_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    EVT_DispatchOutMed();
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    L3R_System_MainOutMedTask();
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

/*----- �o�̓h���C�o (OutDrv) Hook -----------------------------------------*/
static inline void SCH_startupOutDrvHook_0(void) __attribute__((always_inline));
static inline void SCH_startupOutDrvHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    TIM_Ticker_Base_TickOD();
    EVT_SetSendEnable();
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    /* ��FFW_TAIL_start */
    TIM_Ticker_Base_ChkEnableSleep();
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_runOutDrvHook_0(void) __attribute__((always_inline));
static inline void SCH_runOutDrvHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    TIM_Ticker_Base_TickOD();
    EVT_SetSendEnable();
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    /* ��FFW_TAIL_start */
    TIM_Ticker_Base_ChkEnableSleep();
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_postRunOutDrvHook_0(void) __attribute__((always_inline));
static inline void SCH_postRunOutDrvHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    EVT_SetSendEnable();
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_wakeupOutDrvHook_DeepS_0(void) __attribute__((always_inline));
static inline void SCH_wakeupOutDrvHook_DeepS_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    EVT_SetSendEnable();
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

/*----- ������Hook ---------------------------------------------------------*/
static inline void SCH_powerOnInitHook_0(void) __attribute__((always_inline));
static inline void SCH_powerOnInitHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_resetInitHook_0(void) __attribute__((always_inline));
static inline void SCH_resetInitHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_entryPreRunHook_0(void) __attribute__((always_inline));
static inline void SCH_entryPreRunHook_0(void)
{
    /* ��FHEAD */
    BswM_CS_Init();
    /* ��FFW_HEAD_start */
    EVT_SetSendEnable();
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    INFR_SysTimer_Init();
    CANMBQ_ClrSendLockFlg();
    L3R_System_ResetInitialze();
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_preWakeupHook_0(void) __attribute__((always_inline));
static inline void SCH_preWakeupHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_wakeupHook_0(void) __attribute__((always_inline));
static inline void SCH_wakeupHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_reEntryPreRunHook_DeepS_0(void) __attribute__((always_inline));
static inline void SCH_reEntryPreRunHook_DeepS_0(void)
{
    /* ��FHEAD */
    BswM_CS_Wakeup();
    /* ��FFW_HEAD_start */
    EVT_SetSendEnable();
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    INFR_SysTimer_Init();
    CANMBQ_ClrSendLockFlg();
    L3R_System_WakeUpInitialze();
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_sleepHook_0(void) __attribute__((always_inline));
static inline void SCH_sleepHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    TIM_Ticker_Base_InitSlpInTimer();
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    BswM_CS_Sleep();
    L3R_System_EntryPostRunHook();
    L3R_System_SleepInitialze();
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

/*----- ��ԈڍsHook -------------------------------------------------------*/
static inline void SCH_entryRunHook_Reset_0(void) __attribute__((always_inline));
static inline void SCH_entryRunHook_Reset_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_entryPostRunHook_0(void) __attribute__((always_inline));
static inline void SCH_entryPostRunHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_entryRunHook_Wkup_0(void) __attribute__((always_inline));
static inline void SCH_entryRunHook_Wkup_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_sleepCheckHook_0(void) __attribute__((always_inline));
static inline void SCH_sleepCheckHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

static inline void SCH_wupCheckHook_0(void) __attribute__((always_inline));
static inline void SCH_wupCheckHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

/*----- �h���C�o�^�X�NHook -------------------------------------------------*/
static inline void SCH_driverTaskUserHook_0(void) __attribute__((always_inline));
static inline void SCH_driverTaskUserHook_0(void)
{
    /* ��FHEAD */
    BswM_CS_MainFunctionHigh();
    L3R_System_DriverTask();
    CANMBQ_DriverTask();
    INFR_SysTimer_Update_1ms();
    /* ��FFW_HEAD_start */
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

/*----- �A�C�h���^�X�NHook -------------------------------------------------*/
static inline void SCH_idleTaskUserHook_0(void) __attribute__((always_inline));
static inline void SCH_idleTaskUserHook_0(void)
{
    /* ��FHEAD */
    /* ��FFW_HEAD_start */
    /* ��FFW_HEAD_end */
    /* ��FBSW_CS_start */
    /* ��FBSW_CS_end */
    /* ��FBSW_MS_start */
    /* ��FBSW_MS_end */
    /* ��FAPP_start */
    /* ��FUNSPECIFIED */
    /* ��FFW_TAIL_start */
    /* ��FFW_TAIL_end */
    /* ��FTAIL */
}

/*----- ���̓h���C�o (InDrv) Hook ------------------------------------------*/
static inline void SCH_startupInDrvHook_1(void) __attribute__((always_inline));
static inline void SCH_startupInDrvHook_1(void)
{
}

static inline void SCH_runInDrvHook_1(void) __attribute__((always_inline));
static inline void SCH_runInDrvHook_1(void)
{
}

static inline void SCH_postRunInDrvHook_1(void) __attribute__((always_inline));
static inline void SCH_postRunInDrvHook_1(void)
{
}

static inline void SCH_wakeupInDrvHook_DeepS_1(void) __attribute__((always_inline));
static inline void SCH_wakeupInDrvHook_DeepS_1(void)
{
}

/*----- ���͒��� (InMed) Hook ----------------------------------------------*/
static inline void SCH_startupInMedHook_1(void) __attribute__((always_inline));
static inline void SCH_startupInMedHook_1(void)
{
}

static inline void SCH_runInMedHook_1(void) __attribute__((always_inline));
static inline void SCH_runInMedHook_1(void)
{
}

static inline void SCH_postRunInMedHook_1(void) __attribute__((always_inline));
static inline void SCH_postRunInMedHook_1(void)
{
}

static inline void SCH_wakeupInMedHook_DeepS_1(void) __attribute__((always_inline));
static inline void SCH_wakeupInMedHook_DeepS_1(void)
{
}

/*----- �A�v���P�[�V���� (App) Hook ----------------------------------------*/
static inline void SCH_startupAppHook_1(void) __attribute__((always_inline));
static inline void SCH_startupAppHook_1(void)
{
}

static inline void SCH_runAppHook_1(void) __attribute__((always_inline));
static inline void SCH_runAppHook_1(void)
{
}

static inline void SCH_postRunAppHook_1(void) __attribute__((always_inline));
static inline void SCH_postRunAppHook_1(void)
{
}

static inline void SCH_wakeupAppHook_DeepS_1(void) __attribute__((always_inline));
static inline void SCH_wakeupAppHook_DeepS_1(void)
{
}

/*----- �o�͒��� (OutMed) Hook ---------------------------------------------*/
static inline void SCH_startupOutMedHook_1(void) __attribute__((always_inline));
static inline void SCH_startupOutMedHook_1(void)
{
}

static inline void SCH_runOutMedHook_1(void) __attribute__((always_inline));
static inline void SCH_runOutMedHook_1(void)
{
}

static inline void SCH_postRunOutMedHook_1(void) __attribute__((always_inline));
static inline void SCH_postRunOutMedHook_1(void)
{
}

static inline void SCH_wakeupOutMedHook_DeepS_1(void) __attribute__((always_inline));
static inline void SCH_wakeupOutMedHook_DeepS_1(void)
{
}

/*----- �o�̓h���C�o (OutDrv) Hook -----------------------------------------*/
static inline void SCH_startupOutDrvHook_1(void) __attribute__((always_inline));
static inline void SCH_startupOutDrvHook_1(void)
{
}

static inline void SCH_runOutDrvHook_1(void) __attribute__((always_inline));
static inline void SCH_runOutDrvHook_1(void)
{
}

static inline void SCH_postRunOutDrvHook_1(void) __attribute__((always_inline));
static inline void SCH_postRunOutDrvHook_1(void)
{
}

static inline void SCH_wakeupOutDrvHook_DeepS_1(void) __attribute__((always_inline));
static inline void SCH_wakeupOutDrvHook_DeepS_1(void)
{
}

/*----- ������Hook ---------------------------------------------------------*/
static inline void SCH_powerOnInitHook_1(void) __attribute__((always_inline));
static inline void SCH_powerOnInitHook_1(void)
{
}

static inline void SCH_resetInitHook_1(void) __attribute__((always_inline));
static inline void SCH_resetInitHook_1(void)
{
}

static inline void SCH_entryPreRunHook_1(void) __attribute__((always_inline));
static inline void SCH_entryPreRunHook_1(void)
{
}

static inline void SCH_preWakeupHook_1(void) __attribute__((always_inline));
static inline void SCH_preWakeupHook_1(void)
{
}

static inline void SCH_wakeupHook_1(void) __attribute__((always_inline));
static inline void SCH_wakeupHook_1(void)
{
}

static inline void SCH_reEntryPreRunHook_DeepS_1(void) __attribute__((always_inline));
static inline void SCH_reEntryPreRunHook_DeepS_1(void)
{
}

static inline void SCH_sleepHook_1(void) __attribute__((always_inline));
static inline void SCH_sleepHook_1(void)
{
}

/*----- ��ԈڍsHook -------------------------------------------------------*/
static inline void SCH_entryRunHook_Reset_1(void) __attribute__((always_inline));
static inline void SCH_entryRunHook_Reset_1(void)
{
}

static inline void SCH_entryPostRunHook_1(void) __attribute__((always_inline));
static inline void SCH_entryPostRunHook_1(void)
{
}

static inline void SCH_entryRunHook_Wkup_1(void) __attribute__((always_inline));
static inline void SCH_entryRunHook_Wkup_1(void)
{
}

static inline void SCH_sleepCheckHook_1(void) __attribute__((always_inline));
static inline void SCH_sleepCheckHook_1(void)
{
}

static inline void SCH_wupCheckHook_1(void) __attribute__((always_inline));
static inline void SCH_wupCheckHook_1(void)
{
}

/*----- �h���C�o�^�X�NHook -------------------------------------------------*/
static inline void SCH_driverTaskUserHook_1(void) __attribute__((always_inline));
static inline void SCH_driverTaskUserHook_1(void)
{
}

/*----- �A�C�h���^�X�NHook -------------------------------------------------*/
static inline void SCH_idleTaskUserHook_1(void) __attribute__((always_inline));
static inline void SCH_idleTaskUserHook_1(void)
{
}

#endif /* SCH_H */
/*----End of File-----------------------------------------------------------*/
