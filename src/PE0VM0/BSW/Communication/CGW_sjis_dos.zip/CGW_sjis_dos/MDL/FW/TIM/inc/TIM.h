 /****************************************************************************
 *  Copyright (c) 2010-11 Denso Corporation
 *  �@�\            �{�f�[�A�v�������p����^�C�}�@�\��񋟂���
 *
 *  ���l            �Ȃ�
 ****************************************************************************/
#ifndef TIM_H
#define TIM_H

#include "Std_Types.h"
#include "TIM_Ticker.h"
#include "TIM_Ticker_Cfg.h"
#include "TIM_Ticker_Base.h"
#include "TIM_Cfg.h"
#include "TIM_NullFunc.h"

typedef void (TimerFunction)(void *quote);


typedef const struct Util_Timer_function {
    TimerFunction* _function;
    void * _quote;
}ST_TMR_FUNC;


#define GW_FW_START_SEC_VAR_NO_INIT
#include "GW_FW_Memmap.h"

/* �^�C�}��extern */
extern uint16 Util_Timer_Time[UTIL_TIMER_ALL_NUM];
extern ST_TMR_FUNC Util_Timer_Function[UTIL_TIMER_ALL_NUM];

#define GW_FW_STOP_SEC_VAR_NO_INIT
#include "GW_FW_Memmap.h"

/* ���Ԍv�Z�p�Ɍ��J */
#define TIM_MILLISEC_TIME_LSB 	( UTIL_TICKER_MS_TIME_LSB )
#define TIM_SECOND_TIME_LSB    	( UTIL_TICKER_SC_TIME_LSB )
#define TIM_MINUTES_TIME_LSB   	( UTIL_TICKER_MN_TIME_LSB )

/* API��` */
static inline void TIM_TimerStart(const uint16 index, const uint16 timeval) __attribute__((always_inline, unused));
static inline void TIM_TimerStart(const uint16 index, const uint16 timeval)
{
	Util_Timer_Time[index] = timeval;
	return;
}

static inline uint32 TIM_TimerIsTicking(const uint16 index) __attribute__((always_inline, unused));
static inline uint32 TIM_TimerIsTicking(const uint16 index)
{
	return (uint32)( (uint32)Util_Timer_Time[index] > (uint32)0U );
}

static inline void TIM_TimerStop(const uint16 index) __attribute__((always_inline, unused));
static inline void TIM_TimerStop(const uint16 index)
{
	Util_Timer_Time[index] = (uint16)0U;
	return;
}

static inline uint16 TIM_TimerGetTime(const uint16 index) __attribute__((always_inline, unused));
static inline uint16 TIM_TimerGetTime(const uint16 index)
{
	return ( Util_Timer_Time[index] );
}

/* Null�֐���` */ /* ���Ί֐��i������void�j����֐��ɂ������ꍇ�Ɏg�p���� */
#define TIM_nullFunc		TIM_NullFunc_void

#endif /* TIM_H */
