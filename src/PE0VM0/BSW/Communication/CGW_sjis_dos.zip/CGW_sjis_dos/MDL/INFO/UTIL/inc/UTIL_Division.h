/*****************************************************************************
 *	Copyright DENSO Corporation. All rights reserved.
 ****************************************************************************/
/*****************************************************************************
 * @file		UTIL_Division.h
 * @brief		Division Operations
 * @attention	None
 * @note		None
 ****************************************************************************/
#ifndef	UTIL_DIVISION_H
#define	UTIL_DIVISION_H

#endif	/* UTIL_DIVISION_H */
