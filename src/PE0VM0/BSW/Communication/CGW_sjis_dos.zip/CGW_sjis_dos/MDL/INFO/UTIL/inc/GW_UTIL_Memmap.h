/****************************************************************************/
/* Copyright DENSO Corporation. All rights reserved                         */
/*************************************************************************//**
 * @file GW_UTIL_Memmap.h
 ****************************************************************************/

#include "Section_Util.h"

/*--------------------------------------------------------------------------*/
/* Check Error                                                              */
/*--------------------------------------------------------------------------*/
#if (defined MEMMAP_ERROR)  /* Memmap���Ԉ�������@�Ŏg�p����Ă��Ȃ����m�F */
    #error MEMMAP_ERROR defined, wrong Memmap.h usage
#endif /* if (defined MEMMAP_ERROR) */

#define MEMMAP_ERROR

/*--------------------------------------------------------------------------*/
/* Start Memory Mapping                                                     */
/*--------------------------------------------------------------------------*/
/* GW_UTIL_CODE */
#if defined GW_UTIL_START_SEC_CODE
    #undef MEMMAP_ERROR
    PRAGMA_SECTION(text, ".gw_util_code")
    #undef GW_UTIL_START_SEC_CODE
#elif defined GW_UTIL_STOP_SEC_CODE
    #undef MEMMAP_ERROR
    PRAGMA_SECTION_DEFAULT(text)
    #undef GW_UTIL_STOP_SEC_CODE

#endif

#if defined MEMMAP_ERROR
    #error "GW_UTIL_Memmap.h, wrong Memmap.h usage"
#endif /* MEMMAP_ERROR */
