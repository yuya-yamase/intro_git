/*****************************************************************************
 *	Copyright DENSO Corporation. All rights reserved.
 ****************************************************************************/
/*****************************************************************************
 * @file		UTIL_Shift.h
 * @brief		Shift Operations
 * @attention	None
 * @note		None
 ****************************************************************************/
#ifndef	UTIL_SHIFT_H
#define	UTIL_SHIFT_H

/*----------------------------------------------------------------------------
 *		Macros
 *--------------------------------------------------------------------------*/
/**---------------------------------------------------------------------------
 * @breif	Logical Left Shift (uint8)
 * @param	uint8	u1_Data		:	Shift Value
 * @param	uint8	u1_Shift	:	Bits for shift
 * @return	Result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
static inline uint8 UTIL_ShiftLeft_U1(const uint8 u1_Data, const uint8 u1_Shift) __attribute__((always_inline, unused));
static inline uint8 UTIL_ShiftLeft_U1(const uint8 u1_Data, const uint8 u1_Shift)
{
	return (uint8)((uint32)u1_Data << (uint32)u1_Shift);
}

/**---------------------------------------------------------------------------
 * @breif	Logical Left Shift (uint16)
 * @param	uint16	u2_Data		:	Shift Value
 * @param	uint8	u1_Shift	:	Bits for shift
 * @return	Result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
static inline uint16 UTIL_ShiftLeft_U2(const uint16 u2_Data, const uint8 u1_Shift) __attribute__((always_inline, unused));
static inline uint16 UTIL_ShiftLeft_U2(const uint16 u2_Data, const uint8 u1_Shift)
{
	return (uint16)((uint32)u2_Data << (uint32)u1_Shift);
}
/**---------------------------------------------------------------------------
 * @breif	Logical Left Shift (uint32)
 * @param	uint32	u4_Data		:	Shift Value
 * @param	uint8	u1_Shift	:	Bits for shift
 * @return	Result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
static inline uint32 UTIL_ShiftLeft_U4(const uint32 u4_Data, const uint8 u1_Shift) __attribute__((always_inline, unused));
static inline uint32 UTIL_ShiftLeft_U4(const uint32 u4_Data, const uint8 u1_Shift)
{
	return (uint32)((uint32)u4_Data << (uint32)u1_Shift);
}

/**---------------------------------------------------------------------------
 * @breif	Logical Right Shift (uint8)
 * @param	uint8	u1_Data		:	Shift Value
 * @param	uint8	u1_Shift	:	Bits for shift
 * @return	Result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
static inline uint8 UTIL_ShiftRight_U1(const uint8 u1_Data, const uint8 u1_Shift) __attribute__((always_inline, unused));
static inline uint8 UTIL_ShiftRight_U1(const uint8 u1_Data, const uint8 u1_Shift)
{
	return (uint8)((uint32)u1_Data >> (uint32)u1_Shift);
}
/**---------------------------------------------------------------------------
 * @breif	Logical Right Shift (uint16)
 * @param	uint16	u2_Data		:	Shift Value
 * @param	uint8	u1_Shift	:	Bits for shift
 * @return	Result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
static inline uint16 UTIL_ShiftRight_U2(const uint16 u2_Data, const uint8 u1_Shift) __attribute__((always_inline, unused));
static inline uint16 UTIL_ShiftRight_U2(const uint16 u2_Data, const uint8 u1_Shift)
{
	return (uint16)((uint32)u2_Data >> (uint32)u1_Shift);
}

/**---------------------------------------------------------------------------
 * @breif	Logical Right Shift (uint32)
 * @param	uint32	u4_Data		:	Shift Value
 * @param	uint8	u1_Shift	:	Bits for shift
 * @return	Result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
static inline uint32 UTIL_ShiftRight_U4(const uint32 u4_Data, const uint8 u1_Shift) __attribute__((always_inline, unused));
static inline uint32 UTIL_ShiftRight_U4(const uint32 u4_Data, const uint8 u1_Shift)
{
	return (uint32)((uint32)u4_Data >> (uint32)u1_Shift);
}

#endif	/* UTIL_SHIFT_H */
