#ifndef	ECUM_TYPES_DUMMY_H
#define	ECUM_TYPES_DUMMY_H

#include "Std_Types.h"
typedef uint32   EcuM_WakeupSourceType;

#endif 
