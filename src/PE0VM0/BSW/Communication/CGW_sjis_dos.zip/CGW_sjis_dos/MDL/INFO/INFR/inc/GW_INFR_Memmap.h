/****************************************************************************/
/* Copyright DENSO Corporation. All rights reserved                         */
/*************************************************************************//**
 * @file GW_INFR_Memmap.h
 ****************************************************************************/

#include "Section_Util.h"

/*--------------------------------------------------------------------------*/
/* Check Error                                                              */
/*--------------------------------------------------------------------------*/
#if (defined MEMMAP_ERROR)  /* Memmap���Ԉ�������@�Ŏg�p����Ă��Ȃ����m�F */
    #error MEMMAP_ERROR defined, wrong Memmap.h usage
#endif /* if (defined MEMMAP_ERROR) */

#define MEMMAP_ERROR

/*--------------------------------------------------------------------------*/
/* Start Memory Mapping                                                     */
/*--------------------------------------------------------------------------*/
/* GW_INFR_CODE */
#if defined GW_INFR_START_SEC_CODE
    #undef MEMMAP_ERROR
    PRAGMA_SECTION(text, ".gw_infr_code")
    #undef GW_INFR_START_SEC_CODE
#elif defined GW_INFR_STOP_SEC_CODE
    #undef MEMMAP_ERROR
    PRAGMA_SECTION_DEFAULT(text)
    #undef GW_INFR_STOP_SEC_CODE

/* GW_INFR_VAR_NO_INIT */
#elif defined GW_INFR_START_SEC_VAR_NO_INIT
    #undef MEMMAP_ERROR
    PRAGMA_SECTION(bss, ".gw_infr_no_init")
    #undef GW_INFR_START_SEC_VAR_NO_INIT
#elif defined GW_INFR_STOP_SEC_VAR_NO_INIT
    #undef MEMMAP_ERROR
    PRAGMA_SECTION_DEFAULT(bss)
    #undef GW_INFR_STOP_SEC_VAR_NO_INIT

#endif

#if defined MEMMAP_ERROR
    #error "GW_INFR_Memmap.h, wrong Memmap.h usage"
#endif /* MEMMAP_ERROR */
