/****************************************************************************/
/*            Copyright DENSO Corporation. All rights reserved.             */
/****************************************************************************/
/*************************************************************************//**
 * @file        GSS_PostRunReq.h
 * @brief       PostRun��Ԉێ��v��I/F
 * @attention   �Ȃ�
 * @note        �Ȃ�
 ****************************************************************************/
#ifndef GSS_POSTRUNREQ_H
#define GSS_POSTRUNREQ_H

/*--------------------------------------------------------------------------*/
/*        �t�@�C���C���N���[�h                                              */
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"
#include "../cfg/GSS_Cfg.h"

/*--------------------------------------------------------------------------*/
/*        �֐���`                                                          */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_CODE
#include "GW_GSS_Memmap.h"

#if (GSS_USE_POSTRUN_REQUEST == STD_ON)
void	GSS_SetPostRunRequest(const uint16 id);
void	GSS_ClearPostRunRequest(const uint16 id);
boolean GSS_IsPostRunRequested(const uint16 id);
boolean GSS_GetPostRunRequested(void);
void	GSS_InitPostRunRequest(void);
#else
/* PostRun�ێ��v���pI/F���s�v�Ȃ���GSS_State�ɑg�ݕt���Ă��鏉����I/F�𖳌������� */
#define GSS_InitPostRunRequest()
#endif

#define GW_GSS_STOP_SEC_CODE
#include "GW_GSS_Memmap.h"

#endif /* GSS_POSTRUNREQ_H */
