/****************************************************************************/
/*            Copyright DENSO Corporation. All rights reserved.             */
/****************************************************************************/
/*************************************************************************//**
 * @file        GSS_RunReq.c
 * @brief       Run��Ԉێ��v��I/F
 * @attention   �Ȃ�
 * @note        �Ȃ�
 ****************************************************************************/
/*--------------------------------------------------------------------------*/
/*        �t�@�C���C���N���[�h                                              */
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"
#include "../inc/GSS_RunReq.h"
#include "../inc/GSS_StateReqCommon.h"

/*--------------------------------------------------------------------------*/
/*        �t�@�C�����ϐ�                                                    */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_VAR_NO_INIT
#include "GW_GSS_Memmap.h"

static uint32 GSS_State_runRequest; /**< Run�v���v�� */

#define GW_GSS_STOP_SEC_VAR_NO_INIT
#include "GW_GSS_Memmap.h"

/*--------------------------------------------------------------------------*/
/*        �֐���`                                                          */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_CODE
#include "GW_GSS_Memmap.h"
/*************************************************************************//**
 * @brief      RUN�v�����W�@�\�̏�����
 * @return     None
 * @attention  None
 * @note       None
 ****************************************************************************/
void GSS_InitRunRequest(void)
{
	GSS_State_runRequest = (uint32)GSS_STATE_RUNREQ_NOREQ;
	return;
}

/*************************************************************************//**
 * @brief      RUN�v���̃Z�b�g
 * @param[in]  id RUN�v���v��ID
 * @return     None
 * @attention  Run��Ԃ���R�[���\
 * @note       None
 ****************************************************************************/
void GSS_SetRunRequest(const uint16 id)
{
	GSS_SetStateRequest(&GSS_State_runRequest, (uint32)id);
	return;
}

/*************************************************************************//**
 * @brief      RUN�v���̃N���A
 * @param[in]  id RUN�v���v��ID
 * @return     None
 * @attention  Run��Ԃ���R�[���\
 * @note       None
 ****************************************************************************/
void GSS_ClearRunRequest(const uint16 id)
{
	GSS_ClearStateRequest(&GSS_State_runRequest, (uint32)id);
	return;
}

/*************************************************************************//**
 * @brief      RUN�v���̎Q��
 * @param[in]  id RUN�v���v��ID
 * @return     RUN�v���̗L��
 * @attention  Run��Ԃ���R�[���\
 * @note       None
 ****************************************************************************/
boolean GSS_IsRunRequested(const uint16 id)
{
	return (GSS_IsStateRequested(&GSS_State_runRequest, (uint32)id));
}

/*************************************************************************//**
 * @brief      �S�Ă�RUN�v���L��(���C���R�A)
 * @return     RUN�v���̗L��
 * @attention  None
 * @note       None
 ****************************************************************************/
boolean GSS_GetRunRequested( void )
{
	return (GSS_GetStateRequested(&GSS_State_runRequest));
}
#define GW_GSS_STOP_SEC_CODE
#include "GW_GSS_Memmap.h"
