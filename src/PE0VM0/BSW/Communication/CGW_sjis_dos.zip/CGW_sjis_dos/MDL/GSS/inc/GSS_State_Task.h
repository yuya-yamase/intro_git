/****************************************************************************/
/*            Copyright DENSO Corporation. All rights reserved.             */
/****************************************************************************/
/*************************************************************************//**
 * @file        GSS_State_Task.h
 * @brief       SS��ԃR�[���A�E�g�֑g�ݕt���p�֐��̌��J
 * @attention   �Ȃ�
 * @note        �Ȃ�
 ****************************************************************************/

/*--------------------------------------------------------------------------*/
/*        �Q�d�C���N���[�h�h�~                                              */
/*--------------------------------------------------------------------------*/
#ifndef    GSS_STATE_TASK_H
#define    GSS_STATE_TASK_H

/*--------------------------------------------------------------------------*/
/*        �t�@�C���C���N���[�h                                              */
/*--------------------------------------------------------------------------*/
#include <Std_Types.h>

/*--------------------------------------------------------------------------*/
/*        �O�����J�ϐ�                                                      */
/*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/
/*        �}�N����`                                                        */
/*--------------------------------------------------------------------------*/
/* GSS�̓E�F�C�N�A�b�v���ۂ��݂̂ŏ����𕪊򂳂���̂ŉ��L2�l�̂ݒ�`���� */
#define GSS_RESET_FACTOR_CATEGORY_NOT_DEEPSTOP (0x01U)
#define GSS_RESET_FACTOR_CATEGORY_DEEPSTOP	   (0x02U)

/*--------------------------------------------------------------------------*/
/*        �v���g�^�C�v�錾                                                  */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_CODE
#include "GW_GSS_Memmap.h"

void GSS_State_ExecPreClockUpCallout(const uint32 resetFactor);
void GSS_State_ExecPostClockUpCallout(const uint32 resetFactor);
void GSS_State_ExecEntryPreRunCallout( void );
void GSS_State_ExecReEntryPreRunCallout( void );
void GSS_State_ExecEntryRunCallout( void );
void GSS_State_ExecEntryPostRunCallout( void );
void GSS_State_ExecPreArbitrationCallout( void );
void GSS_State_ExecShutdownCallout(void);
void GSS_State_ExecDriverTaskUserHook( void );
void GSS_State_ExecIdleTaskUserHook( void );

#define GW_GSS_STOP_SEC_CODE
#include "GW_GSS_Memmap.h"

/*--------------------------------------------------------------------------*/
/*        �Q�d�C���N���[�h�h�~                                              */
/*--------------------------------------------------------------------------*/
#endif    /* GSS_STATE_CALLOUT_H */
