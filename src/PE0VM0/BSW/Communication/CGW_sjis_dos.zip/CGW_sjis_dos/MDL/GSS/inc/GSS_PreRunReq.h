/****************************************************************************/
/*            Copyright DENSO Corporation. All rights reserved.             */
/****************************************************************************/
/*************************************************************************//**
 * @file        GSS_PreRunReq.h
 * @brief       PreRun��Ԉێ��v��I/F
 * @attention   �Ȃ�
 * @note        �Ȃ�
 ****************************************************************************/
#ifndef GSS_PRERUNREQ_H
#define GSS_PRERUNREQ_H

/*--------------------------------------------------------------------------*/
/*        �t�@�C���C���N���[�h                                              */
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"
#include "../cfg/GSS_Cfg.h"

/*--------------------------------------------------------------------------*/
/*        �֐���`                                                          */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_CODE
#include "GW_GSS_Memmap.h"

#if (GSS_USE_PRERUN_REQUEST == STD_ON)
void	GSS_SetPreRunRequest(const uint16 id);
void	GSS_ClearPreRunRequest(const uint16 id);
boolean GSS_IsPreRunRequested(const uint16 id);
boolean GSS_GetPreRunRequested(void);
void	GSS_InitPreRunRequest(void);
#else
/* PreRun�ێ��v���pI/F���s�v�Ȃ���GSS_State�ɑg�ݕt���Ă��鏉����I/F�𖳌������� */
#define GSS_SetPreRunRequest(id)
#define GSS_InitPreRunRequest()
#endif

#define GW_GSS_STOP_SEC_CODE
#include "GW_GSS_Memmap.h"

#endif /* GSS_PRERUNREQ_H */
