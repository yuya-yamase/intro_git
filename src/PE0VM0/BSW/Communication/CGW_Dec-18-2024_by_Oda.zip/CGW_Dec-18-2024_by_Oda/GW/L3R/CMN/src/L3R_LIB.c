/****************************************************************************/
/*  ファイル名      L3R_LIB.c                                               */
/*  モジュール名    ライブラリ                                              */
/*  機能            ライブラリ                                              */
/*  備考                                                                    */
/*  変更履歴        V1.00   2013.05.13  Y.Kaseda                            */
/*                        新規作成            CGWコーディング規約 V1.00準拠 */
/*                  V1.01   2013.09.26  Y.tabuchi                           */
/*                        読み込みのみの変数がROM領域に割り付けられるよう   */
/*                        修正                                              */
/*                  V1.02   2017.03.03  Y.Katayama                          */
/*                        19PF向け型定義対応                                */
/*                  V1.03   2018/05/11  A.Yasui(FSI)                        */
/*                        中継のCHとPRTCL_BITの命名規則明確化レベルアップ   */
/*                  V1.04   2018/05/21  A.Yasui(FSI)                        */
/*                        中継のCHとPRTCL_BITの命名規則明確化レベルアップ2  */
/*                  V1.05   2018/10/25  T.Yamamura                          */
/*                        コードレベルアップ対応(オブジェクト不変)          */
/*                  V2.00   2018.11.21 Y.Katayama                           */
/*                        中継改善(オブジェクト不変）                       */
/****************************************************************************/

#include "L3R_Common.h"
#include "L3R_LIB.h"

/*----プロトタイプ宣言------------------------------------------------------*/

/*----外部変数宣言----------------------------------------------------------*/

#define GW_L3R_START_SEC_CONST
#include "GW_L3R_Memmap.h"
const uint16 L3R_ConvertChToPrtclBit[L3R_TOTALCH_MAX] = {
	L3R_PRTCL_BIT_0,
	L3R_PRTCL_BIT_1,
	L3R_PRTCL_BIT_2,
	L3R_PRTCL_BIT_3,
	L3R_PRTCL_BIT_4,
	L3R_PRTCL_BIT_5,
	L3R_PRTCL_BIT_6,
	L3R_PRTCL_BIT_7,
	L3R_PRTCL_BIT_8,
	L3R_PRTCL_BIT_9,
	L3R_PRTCL_BIT_10,
	L3R_PRTCL_BIT_11,
	L3R_PRTCL_BIT_12,
	L3R_PRTCL_BIT_13,
	L3R_PRTCL_BIT_14,
	L3R_PRTCL_BIT_15
};

#define GW_L3R_STOP_SEC_CONST
#include "GW_L3R_Memmap.h"
/*----置換マクロ------------------------------------------------------------*/
