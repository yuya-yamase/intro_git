/****************************************************************************/
/*            Copyright DENSO Corporation. All rights reserved.             */
/****************************************************************************/
/*************************************************************************//**
 * @file        GSS_RunReq.h
 * @brief       Run状態維持要求I/F
 * @attention   なし
 * @note        なし
 ****************************************************************************/
#ifndef GSS_RUNREQ_H
#define GSS_RUNREQ_H

/*--------------------------------------------------------------------------*/
/*        ファイルインクルード                                              */
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"
#include "../cfg/GSS_Cfg.h"

/*--------------------------------------------------------------------------*/
/*        関数定義                                                          */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_CODE
#include "GW_GSS_Memmap.h"

void	GSS_SetRunRequest(const uint16 id);
void	GSS_ClearRunRequest(const uint16 id);
boolean GSS_IsRunRequested(const uint16 id);
boolean GSS_GetRunRequested(void);
void	GSS_InitRunRequest(void);

#if (GSS_USE_RUNREQ_HOOK == STD_ON)
void	GSS_CheckRunRequest(void);
#else
#define GSS_CheckRunRequest()
#endif

#define GW_GSS_STOP_SEC_CODE
#include "GW_GSS_Memmap.h"

#endif /* GSS_RUNREQ_H */
