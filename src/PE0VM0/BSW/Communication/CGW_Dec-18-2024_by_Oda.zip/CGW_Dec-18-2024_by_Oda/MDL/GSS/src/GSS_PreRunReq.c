/****************************************************************************/
/*            Copyright DENSO Corporation. All rights reserved.             */
/****************************************************************************/
/*************************************************************************//**
 * @file        GSS_PreRunReq.c
 * @brief       PreRun状態維持要求I/F
 * @attention   なし
 * @note        なし
 ****************************************************************************/
/*--------------------------------------------------------------------------*/
/*        ファイルインクルード                                              */
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"
#include "../cfg/GSS_Cfg.h"
#include "../inc/GSS_PreRunReq.h"
#include "../inc/GSS_StateReqCommon.h"

#if (GSS_USE_PRERUN_REQUEST == STD_ON)
/*--------------------------------------------------------------------------*/
/*        ファイル内変数                                                    */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_VAR_NO_INIT
#include "GW_GSS_Memmap.h"

static uint32 GSS_State_preRunRequest; /**< PreRun要求要因 */

#define GW_GSS_STOP_SEC_VAR_NO_INIT
#include "GW_GSS_Memmap.h"

/*--------------------------------------------------------------------------*/
/*        関数定義                                                          */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_CODE
#include "GW_GSS_Memmap.h"
/*************************************************************************//**
 * @brief      PreRun要求収集機能の初期化
 * @return     None
 * @attention  None
 * @note       None
 ****************************************************************************/
void GSS_InitPreRunRequest(void)
{
	GSS_State_preRunRequest = (uint32)GSS_STATE_RUNREQ_NOREQ;
	return;
}

/*************************************************************************//**
 * @brief      PreRun要求のセット
 * @param[in]  id RUN要求要因ID
 * @return     None
 * @attention  PreRun状態からコール可能
 * @note       要求用のIDはRun要求要因IDを共用している
 ****************************************************************************/
void GSS_SetPreRunRequest(const uint16 id)
{
	GSS_SetStateRequest(&GSS_State_preRunRequest, (uint32)id);
	return;
}

/*************************************************************************//**
 * @brief      PreRun要求のクリア
 * @param[in]  id RUN要求要因ID
 * @return     None
 * @attention  PreRun状態からコール可能
 * @note       要求用のIDはRun要求要因IDを共用している
 ****************************************************************************/
void GSS_ClearPreRunRequest(const uint16 id)
{
	GSS_ClearStateRequest(&GSS_State_preRunRequest, (uint32)id);
	return;
}

/*************************************************************************//**
 * @brief      PreRun要求の参照
 * @param[in]  id RUN要求要因ID
 * @return     PreRun要求の有無
 * @attention  PreRun状態からコール可能
 * @note       要求用のIDはRun要求要因IDを共用している
 ****************************************************************************/
boolean GSS_IsPreRunRequested(const uint16 id)
{
	return GSS_IsStateRequested(&GSS_State_preRunRequest, (uint32)id);
}

/*************************************************************************//**
 * @brief      全てのPreRun要求有無(メインコア)
 * @return     PreRun要求の有無
 * @attention  None
 * @note       None
 ****************************************************************************/
boolean GSS_GetPreRunRequested( void )
{
	return GSS_GetStateRequested(&GSS_State_preRunRequest);
}
#define GW_GSS_STOP_SEC_CODE
#include "GW_GSS_Memmap.h"

#endif /* (GSS_USE_PRERUN_REQUEST == STD_ON) */
