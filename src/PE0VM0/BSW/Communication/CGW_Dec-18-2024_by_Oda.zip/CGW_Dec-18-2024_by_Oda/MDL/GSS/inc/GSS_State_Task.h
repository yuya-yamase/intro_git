/****************************************************************************/
/*            Copyright DENSO Corporation. All rights reserved.             */
/****************************************************************************/
/*************************************************************************//**
 * @file        GSS_State_Task.h
 * @brief       SS状態コールアウトへ組み付け用関数の公開
 * @attention   なし
 * @note        なし
 ****************************************************************************/

/*--------------------------------------------------------------------------*/
/*        ２重インクルード防止                                              */
/*--------------------------------------------------------------------------*/
#ifndef    GSS_STATE_TASK_H
#define    GSS_STATE_TASK_H

/*--------------------------------------------------------------------------*/
/*        ファイルインクルード                                              */
/*--------------------------------------------------------------------------*/
#include <Std_Types.h>

/*--------------------------------------------------------------------------*/
/*        外部公開変数                                                      */
/*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/
/*        マクロ定義                                                        */
/*--------------------------------------------------------------------------*/
/* GSSはウェイクアップか否かのみで処理を分岐させるので下記2値のみ定義する */
#define GSS_RESET_FACTOR_CATEGORY_NOT_DEEPSTOP (0x01U)
#define GSS_RESET_FACTOR_CATEGORY_DEEPSTOP	   (0x02U)

/*--------------------------------------------------------------------------*/
/*        プロトタイプ宣言                                                  */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_CODE
#include "GW_GSS_Memmap.h"

void GSS_State_ExecPreClockUpCallout(const uint32 resetFactor);
void GSS_State_ExecPostClockUpCallout(const uint32 resetFactor);
void GSS_State_ExecEntryPreRunCallout( void );
void GSS_State_ExecReEntryPreRunCallout( void );
void GSS_State_ExecEntryRunCallout( void );
void GSS_State_ExecEntryPostRunCallout( void );
void GSS_State_ExecPreArbitrationCallout( void );
void GSS_State_ExecShutdownCallout(void);
void GSS_State_ExecDriverTaskUserHook( void );
void GSS_State_ExecIdleTaskUserHook( void );

#define GW_GSS_STOP_SEC_CODE
#include "GW_GSS_Memmap.h"

/*--------------------------------------------------------------------------*/
/*        ２重インクルード防止                                              */
/*--------------------------------------------------------------------------*/
#endif    /* GSS_STATE_CALLOUT_H */
