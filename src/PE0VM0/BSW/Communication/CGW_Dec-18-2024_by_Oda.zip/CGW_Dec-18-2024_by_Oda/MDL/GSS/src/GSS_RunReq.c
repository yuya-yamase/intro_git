/****************************************************************************/
/*            Copyright DENSO Corporation. All rights reserved.             */
/****************************************************************************/
/*************************************************************************//**
 * @file        GSS_RunReq.c
 * @brief       Run状態維持要求I/F
 * @attention   なし
 * @note        なし
 ****************************************************************************/
/*--------------------------------------------------------------------------*/
/*        ファイルインクルード                                              */
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"
#include "../inc/GSS_RunReq.h"
#include "../inc/GSS_StateReqCommon.h"

/*--------------------------------------------------------------------------*/
/*        ファイル内変数                                                    */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_VAR_NO_INIT
#include "GW_GSS_Memmap.h"

static uint32 GSS_State_runRequest; /**< Run要求要因 */

#define GW_GSS_STOP_SEC_VAR_NO_INIT
#include "GW_GSS_Memmap.h"

/*--------------------------------------------------------------------------*/
/*        関数定義                                                          */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_CODE
#include "GW_GSS_Memmap.h"
/*************************************************************************//**
 * @brief      RUN要求収集機能の初期化
 * @return     None
 * @attention  None
 * @note       None
 ****************************************************************************/
void GSS_InitRunRequest(void)
{
	GSS_State_runRequest = (uint32)GSS_STATE_RUNREQ_NOREQ;
	return;
}

/*************************************************************************//**
 * @brief      RUN要求のセット
 * @param[in]  id RUN要求要因ID
 * @return     None
 * @attention  Run状態からコール可能
 * @note       None
 ****************************************************************************/
void GSS_SetRunRequest(const uint16 id)
{
	GSS_SetStateRequest(&GSS_State_runRequest, (uint32)id);
	return;
}

/*************************************************************************//**
 * @brief      RUN要求のクリア
 * @param[in]  id RUN要求要因ID
 * @return     None
 * @attention  Run状態からコール可能
 * @note       None
 ****************************************************************************/
void GSS_ClearRunRequest(const uint16 id)
{
	GSS_ClearStateRequest(&GSS_State_runRequest, (uint32)id);
	return;
}

/*************************************************************************//**
 * @brief      RUN要求の参照
 * @param[in]  id RUN要求要因ID
 * @return     RUN要求の有無
 * @attention  Run状態からコール可能
 * @note       None
 ****************************************************************************/
boolean GSS_IsRunRequested(const uint16 id)
{
	return (GSS_IsStateRequested(&GSS_State_runRequest, (uint32)id));
}

/*************************************************************************//**
 * @brief      全てのRUN要求有無(メインコア)
 * @return     RUN要求の有無
 * @attention  None
 * @note       None
 ****************************************************************************/
boolean GSS_GetRunRequested( void )
{
	return (GSS_GetStateRequested(&GSS_State_runRequest));
}
#define GW_GSS_STOP_SEC_CODE
#include "GW_GSS_Memmap.h"
