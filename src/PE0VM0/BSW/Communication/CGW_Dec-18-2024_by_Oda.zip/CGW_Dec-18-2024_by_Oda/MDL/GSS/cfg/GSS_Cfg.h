/****************************************************************************/
/*            Copyright DENSO Corporation. All rights reserved.             */
/****************************************************************************/
/*************************************************************************//**
 * @file        GSS_Cfg.h
 * @brief       RUN要求ID定義
 * @attention   なし
 * @note        なし
 ****************************************************************************/

/*--------------------------------------------------------------------------*/
/*        ２重インクルード防止                                              */
/*--------------------------------------------------------------------------*/
#ifndef GSS_CFG_H
#define GSS_CFG_H

/*--------------------------------------------------------------------------*/
/*        ファイルインクルード                                              */
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"

/*--------------------------------------------------------------------------*/
/*        コンフィグ                                                        */
/*--------------------------------------------------------------------------*/
/**
 * PostRunでアプリのシャットダウン処理をするか否かを切り替える。
 * STD_ON： SSのPostRun状態でアプリをシャットダウンし、
 *          ドタキャンにも対応する（梅アーキ想定）。
 * STD_OFF：SSのShutdownフックでアプリをシャットダウンし、
 *          アプリ的にはドタキャンが存在しない遷移になる（竹アーキ想定）。
 */
#define GSS_USE_SLEEPCANCEL      (STD_OFF)

/**
 * PostRunの周回タスクを使用するか否かを設定する。
 * STD_ON： PostRun周回タスクを使用する
 * STD_OFF：PostRun周回タスクを使用しない（梅アーキ想定）
 */
#define GSS_USE_POSTRUN          (STD_OFF)

/**
 * PreRun維持要求のI/Fを使用するか否かを設定する。
 * STD_ON： PreRun維持要求I/Fを使用する
 * STD_OFF：PreRun維持要求I/Fを使用しない
 */
#define GSS_USE_PRERUN_REQUEST   (STD_OFF)

/**
 * PostRun維持要求のI/Fを使用するか否かを設定する。
 * STD_ON： PostRun維持要求I/Fを使用する（竹アーキ想定）
 * STD_OFF：PostRun維持要求I/Fを使用しない
 * ※PostRun5階層を使用する場合、PostRun状態を維持するI/Fも必要になるはずなので、
 * 下記の設定は「GSS_USE_POSTRUN」と連動させている。
 */
#define GSS_USE_POSTRUN_REQUEST  (GSS_USE_POSTRUN)

/**
 * 製品要件のRun要求確認用フックを使用するか否かを設定する。
 * STD_ON： GSS_RunReqHookを使用する
 * STD_OFF：GSS_RunReqHookを使用しない
 */
#define GSS_USE_RUNREQ_HOOK      (STD_OFF)

/* Run要求要因ID（PreRun/PostRun要求のI/Fの引数としても使用する） */
/* vv Add RUNREQ ID start vv */
#define GSS_RUNREQ_SS_AWAKE                 (0U)    /* [TMC_標準][TMC_拡張][SBR] */
#define GSS_RUNREQ_PDRV_ACCIG               (1U)    /* [TMC_標準][TMC_拡張][SBR] */
#define GSS_RUNREQ_CANTRCV_AWAKE            (2U)    /* [TMC_標準][TMC_拡張][SBR] */
#define GSS_RUNREQ_SYNC_AWAKE               (3U)    /* [TMC_標準][TMC_拡張][SBR] */
#define GSS_RUNREQ_CMN_WUPMNG               (4U)    /* [TMC_標準][TMC_拡張][SBR] */
#define GSS_RUNREQ_INMED                    (5U)    /* [TMC_標準][TMC_拡張][SBR] */
#define GSS_RUNREQ_APP                      (6U)    /* [TMC_標準][TMC_拡張][SBR] */
#define GSS_RUNREQ_OUTMED                   (7U)    /* [TMC_標準][TMC_拡張][SBR] */
#define GSS_RUNREQ_TIMER                    (8U)    /* [TMC_標準][TMC_拡張][SBR] */
#define GSS_RUNREQ_DGCM_SWM_MANAGE          (9U)    /* [TMC_標準][TMC_拡張][SBR] */
#define GSS_RUNREQ_MS_OPERATING             (10U)   /* [TMC_標準][TMC_拡張][SBR] */
#define GSS_RUNREQ_DNM_AWAKE                (11U)   /* [SBR] */
#define GSS_RUNREQ_IOC_AWAKE_MAIN           (12U)   /* [TMC_拡張] */
#define GSS_RUNREQ_L3R_AWAKE                (13U)   /* [TMC_標準][TMC_拡張][SBR] */
#define GSS_RUNREQ_HSINI_AWAKE              (14U)   /* [TMC PINIT][SBR PINIT] */
#define GSS_RUNREQ_PIF_AWAKE                (15U)   /* [TMC PINIT][SBR PINIT] */
#define GSS_RUNREQ_SECIF_AWAKE              (16U)   /* [TMC_標準][TMC_拡張][SBR] */
#define GSS_RUNREQ_ETH_AWAKE                (17U)   /* [TMC_拡張]*/
#define GSS_RUNREQ_SS_AWAKE_SUB             (18U)
#define GSS_RUNREQ_IOC_AWAKE_SUB            (19U)
/* ^^ Add RUNREQ ID end ^^ */

/*--------------------------------------------------------------------------*/
/*        デバッグ用コンフィグ                                              */
/*--------------------------------------------------------------------------*/
#ifdef _DEBUG
#include "GSS_Cfg_Debug.h"
#endif

/*--------------------------------------------------------------------------*/
/*        ２重インクルード防止                                              */
/*--------------------------------------------------------------------------*/
#endif  /* GSS_CFG_H */
