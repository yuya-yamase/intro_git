/****************************************************************************/
/*            Copyright DENSO Corporation. All rights reserved.             */
/****************************************************************************/
/*************************************************************************//**
 * @file        GSS_PostRunReq.c
 * @brief       PostRun状態維持要求I/F
 * @attention   なし
 * @note        なし
 ****************************************************************************/
/*--------------------------------------------------------------------------*/
/*        ファイルインクルード                                              */
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"
#include "../cfg/GSS_Cfg.h"
#include "../inc/GSS_PostRunReq.h"
#include "../inc/GSS_StateReqCommon.h"

#if (GSS_USE_POSTRUN_REQUEST == STD_ON)
/*--------------------------------------------------------------------------*/
/*        ファイル内変数                                                    */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_VAR_NO_INIT
#include "GW_GSS_Memmap.h"

static uint32 GSS_State_postRunRequest; /**< PostRun要求要因 */

#define GW_GSS_STOP_SEC_VAR_NO_INIT
#include "GW_GSS_Memmap.h"

/*--------------------------------------------------------------------------*/
/*        関数定義                                                          */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_CODE
#include "GW_GSS_Memmap.h"
/*************************************************************************//**
 * @brief      PostRun要求収集機能の初期化
 * @return     None
 * @attention  None
 * @note       None
 ****************************************************************************/
void GSS_InitPostRunRequest(void)
{
	GSS_State_postRunRequest = (uint32)GSS_STATE_RUNREQ_NOREQ;
	return;
}

/*************************************************************************//**
 * @brief      PostRun要求のセット
 * @param[in]  id RUN要求要因ID
 * @return     None
 * @attention  PostRun状態からコール可能
 * @note       要求用のIDはRun要求要因IDを共用している
 ****************************************************************************/
void GSS_SetPostRunRequest(const uint16 id)
{
	GSS_SetStateRequest(&GSS_State_postRunRequest, (uint32)id);
	return;
}

/*************************************************************************//**
 * @brief      PostRun要求のクリア
 * @param[in]  id RUN要求要因ID
 * @return     None
 * @attention  PostRun状態からコール可能
 * @note       要求用のIDはRun要求要因IDを共用している
 ****************************************************************************/
void GSS_ClearPostRunRequest(const uint16 id)
{
	GSS_ClearStateRequest(&GSS_State_postRunRequest, (uint32)id);
	return;
}

/*************************************************************************//**
 * @brief      PostRun要求の参照
 * @param[in]  id RUN要求要因ID
 * @return     PostRun要求の有無
 * @attention  PostRun状態からコール可能
 * @note       要求用のIDはRun要求要因IDを共用している
 ****************************************************************************/
boolean GSS_IsPostRunRequested(const uint16 id)
{
	return GSS_IsStateRequested(&GSS_State_postRunRequest, (uint32)id);
}

/*************************************************************************//**
 * @brief      全てのPostRun要求有無(メインコア)
 * @return     PostRun要求の有無
 * @attention  None
 * @note       None
 ****************************************************************************/
boolean GSS_GetPostRunRequested(void)
{
	return GSS_GetStateRequested(&GSS_State_postRunRequest);
}
#define GW_GSS_STOP_SEC_CODE
#include "GW_GSS_Memmap.h"

#endif /* (GSS_USE_POSTRUN_REQUEST == STD_ON) */
