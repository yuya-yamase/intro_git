/****************************************************************************/
/*            Copyright DENSO Corporation. All rights reserved.             */
/****************************************************************************/
/*************************************************************************//**
 * @file      GSS_State_ExtraHook.c
 * @brief     内製SSのシステム状態遷移を抽象化
 * @attention GSS_State_ExecPreArbitrationCalloutを組み付けている場合は、
 *            本ファイル内の関数は使用不可。
 * @note      5階層の各段階のフックを個別に組み付ける場合にビルド対象にする。
 ****************************************************************************/

/*--------------------------------------------------------------------------*/
/*        ファイルインクルード                                              */
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"

#include "../cfg/GSS_Cfg.h"
#include "../inc/GSS_State.h"
#include "../inc/GSS_State_ExtraHook.h"

/* ehvm\SCH.hが存在し、その中でSCH_Hが#defineされるため、FWのSCHの定義が取り込めなくなる
 * そのため、暫定処置でundefしている。FWのSCH側でファイル名変更等の対応をする必要がある */
#undef SCH_H
#include "../../FW/SCH/cfg/SCH.h"

/*--------------------------------------------------------------------------*/
/*        関数定義                                                          */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_CODE
#include "GW_GSS_Memmap.h"
/*************************************************************************//**
 * @brief      PreRunSup状態の入力ドライバ処理
 * @return     None
 * @attention  リセット起動時PreRunでコールされるように組み付けること
 * @note       None
 ****************************************************************************/
void GSS_State_ExecPreRunSupInDrvHook( void )
{
	GSS_InitPreRunRequest();
	SCH_startupInDrvHook_0();
	return;
}

/*************************************************************************//**
 * @brief      PreRunSup状態の入力調停処理
 * @return     None
 * @attention  リセット起動時PreRunでコールされるように組み付けること
 * @note       None
 ****************************************************************************/
void GSS_State_ExecPreRunSupInMedHook( void )
{
	SCH_startupInMedHook_0();
	return;
}

/*************************************************************************//**
 * @brief      PreRunSup状態のアプリ処理
 * @return     None
 * @attention  リセット起動時PreRunでコールされるように組み付けること
 * @note       None
 ****************************************************************************/
void GSS_State_ExecPreRunSupAppHook( void )
{
	SCH_startupAppHook_0();
	return;
}

/*************************************************************************//**
 * @brief      PreRunSup状態の出力調停処理
 * @return     None
 * @attention  リセット起動時PreRunでコールされるように組み付けること
 * @note       None
 ****************************************************************************/
void GSS_State_ExecPreRunSupOutMedHook( void )
{
	SCH_startupOutMedHook_0();
	return;
}

/*************************************************************************//**
 * @brief      PreRunSup状態の出力ドライバ処理
 * @return     None
 * @attention  リセット起動時PreRunでコールされるように組み付けること
 * @note       None
 ****************************************************************************/
void GSS_State_ExecPreRunSupOutDrvHook( void )
{
	SCH_startupOutDrvHook_0();
	return;
}

/*************************************************************************//**
 * @brief      PreRunWup状態の入力ドライバ処理
 * @return     None
 * @attention  ウェイクアップ起動時PreRunでコールされるように組み付けること。
 *             GSS_USE_SLEEPCANCEL==STD_ONの場合はドタキャン時もコールすること。
 * @note       None
 ****************************************************************************/
void GSS_State_ExecPreRunWupInDrvHook( void )
{
	GSS_InitPreRunRequest();
	SCH_wakeupInDrvHook_DeepS_0();
	return;
}

/*************************************************************************//**
 * @brief      PreRunWup状態の入力調停処理
 * @return     None
 * @attention  ウェイクアップ起動時PreRunでコールされるように組み付けること。
 *             GSS_USE_SLEEPCANCEL==STD_ONの場合はドタキャン時もコールすること。
 * @note       None
 ****************************************************************************/
void GSS_State_ExecPreRunWupInMedHook( void )
{
	SCH_wakeupInMedHook_DeepS_0();
	return;
}

/*************************************************************************//**
 * @brief      PreRunWup状態のアプリ処理
 * @return     None
 * @attention  ウェイクアップ起動時PreRunでコールされるように組み付けること。
 *             GSS_USE_SLEEPCANCEL==STD_ONの場合はドタキャン時もコールすること。
 * @note       None
 ****************************************************************************/
void GSS_State_ExecPreRunWupAppHook( void )
{
	SCH_wakeupAppHook_DeepS_0();
	return;
}

/*************************************************************************//**
 * @brief      PreRunWup状態の出力調停処理
 * @return     None
 * @attention  ウェイクアップ起動時PreRunでコールされるように組み付けること。
 *             GSS_USE_SLEEPCANCEL==STD_ONの場合はドタキャン時もコールすること。
 * @note       None
 ****************************************************************************/
void GSS_State_ExecPreRunWupOutMedHook( void )
{
	SCH_wakeupOutMedHook_DeepS_0();
	return;
}

/*************************************************************************//**
 * @brief      PreRunWup状態の出力ドライバ処理
 * @return     None
 * @attention  ウェイクアップ起動時PreRunでコールされるように組み付けること。
 *             GSS_USE_SLEEPCANCEL==STD_ONの場合はドタキャン時もコールすること。
 * @note       None
 ****************************************************************************/
void GSS_State_ExecPreRunWupOutDrvHook( void )
{
	SCH_wakeupOutDrvHook_DeepS_0();
	return;
}

/*************************************************************************//**
 * @brief      Run状態の入力ドライバ処理
 * @return     None
 * @attention  Run状態でコールされるように組み付けること
 * @note       None
 ****************************************************************************/
void GSS_State_ExecRunInDrvHook( void )
{
	/*GSS要因のRun要求をクリア。GSSとしてRun要求があれば5階層の中でセットする*/
	GSS_InitRunRequest();
	SCH_runInDrvHook_0();
	return;
}

/*************************************************************************//**
 * @brief      Run状態の入力調停処理
 * @return     None
 * @attention  Run状態でコールされるように組み付けること
 * @note       None
 ****************************************************************************/
void GSS_State_ExecRunInMedHook( void )
{
	SCH_runInMedHook_0();
	return;
}

/*************************************************************************//**
 * @brief      Run状態のアプリ処理
 * @return     None
 * @attention  Run状態でコールされるように組み付けること
 * @note       None
 ****************************************************************************/
void GSS_State_ExecRunAppHook( void )
{
	SCH_runAppHook_0();
	return;
}

/*************************************************************************//**
 * @brief      Run状態の出力調停処理
 * @return     None
 * @attention  Run状態でコールされるように組み付けること
 * @note       None
 ****************************************************************************/
void GSS_State_ExecRunOutMedHook( void )
{
	SCH_runOutMedHook_0();
	return;
}

/*************************************************************************//**
 * @brief      Run状態の出力ドライバ処理
 * @return     None
 * @attention  Run状態でコールされるように組み付けること
 * @note       None
 ****************************************************************************/
void GSS_State_ExecRunOutDrvHook( void )
{
	SCH_runOutDrvHook_0();
	return;
}

#if (GSS_USE_SLEEPCANCEL == STD_OFF)
/*************************************************************************//**
 * @brief      PostRun状態の入力ドライバ処理
 * @return     None
 * @attention  PostRun状態でコールされるように組み付けること。
 *             GSS_USE_SLEEPCANCEL==STD_ONの場合は組付け不要。
 * @note       None
 ****************************************************************************/
void GSS_State_ExecPostRunInDrvHook( void )
{
	SCH_postRunInDrvHook_0();
	return;
}

/*************************************************************************//**
 * @brief      PostRun状態の入力調停処理
 * @return     None
 * @attention  PostRun状態でコールされるように組み付けること。
 *             GSS_USE_SLEEPCANCEL==STD_ONの場合は組付け不要。
 * @note       None
 ****************************************************************************/
void GSS_State_ExecPostRunInMedHook( void )
{
	SCH_postRunInMedHook_0();
	return;
}

/*************************************************************************//**
 * @brief      PostRun状態のアプリ処理
 * @return     None
 * @attention  PostRun状態でコールされるように組み付けること。
 *             GSS_USE_SLEEPCANCEL==STD_ONの場合は組付け不要。
 * @note       None
 ****************************************************************************/
void GSS_State_ExecPostRunAppHook( void )
{
	SCH_postRunAppHook_0();
	return;
}

/*************************************************************************//**
 * @brief      PostRun状態の出力調停処理
 * @return     None
 * @attention  PostRun状態でコールされるように組み付けること。
 *             GSS_USE_SLEEPCANCEL==STD_ONの場合は組付け不要。
 * @note       None
 ****************************************************************************/
void GSS_State_ExecPostRunOutMedHook( void )
{
	SCH_postRunOutMedHook_0();
	return;
}

/*************************************************************************//**
 * @brief      PostRun状態の出力ドライバ処理
 * @return     None
 * @attention  PostRun状態でコールされるように組み付けること。
 *             GSS_USE_SLEEPCANCEL==STD_ONの場合は組付け不要。
 * @note       None
 ****************************************************************************/
void GSS_State_ExecPostRunOutDrvHook( void )
{
	SCH_postRunOutDrvHook_0();
	return;
}
#endif /*(GSS_USE_SLEEPCANCEL == STD_OFF)*/
#define GW_GSS_STOP_SEC_CODE
#include "GW_GSS_Memmap.h"
