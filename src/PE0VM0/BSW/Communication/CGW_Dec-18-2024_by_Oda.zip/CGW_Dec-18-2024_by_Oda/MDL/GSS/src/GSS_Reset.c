/****************************************************************************/
/*            Copyright DENSO Corporation. All rights reserved.             */
/****************************************************************************/
/*************************************************************************//**
 * @file        GSS_Reset.c
 * @brief       リセット関連APIの抽象化
 * @attention   なし
 * @note        なし
 ****************************************************************************/

/*--------------------------------------------------------------------------*/
/*        ファイルインクルード                                              */
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"

#include "../cfg/GSS_Connector.h"
#include "../inc/GSS_Reset.h"

/*--------------------------------------------------------------------------*/
/*        関数定義                                                          */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_CODE
#include "GW_GSS_Memmap.h"
/*************************************************************************//**
 * @brief      正常リセット
 * @return     None
 * @attention  None
 * @note       リセット前に必要な処理を実行後、リセットする
 ****************************************************************************/
void GSS_Reset(void)
{
	GSS_ExecPreResetHook();
	while (TRUE) {
		/* リセットするまでループでコールし続ける */
		GSS_PerformReset();
	}
	/* 直前の無限ループによりreturnに到達できない旨の警告を抑制する */
#ifdef MK_OPT_IGNR_WARN_111
	_Pragma("ghs nowarning 111")
#endif
	return;
#ifdef MK_OPT_IGNR_WARN_111
	_Pragma("ghs endnowarning")
#endif
}

/*************************************************************************//**
 * @brief      正常リセット可能判定
 * @retval     TRUE:  正常リセット可能な状態
 * @retval     FALSE: リセット不可な状態
 * @attention  None
 * @note       正常リセットの事前条件を満たしているかを判定
 ****************************************************************************/
boolean GSS_IsPrepareReset(void)
{
	return (GSS_CheckResetPrecondition());
}

/*************************************************************************//**
 * @brief        緊急リセット
 * @return       None
 * @attention    正常系では使用しないこと
 * @note         リソース停止を行わずソフトリセット
 ****************************************************************************/
void GSS_EmergencyReset(void)
{
	while (TRUE) {
		/* リセットするまでループでコールし続ける */
		GSS_PerformReset();
	}
	/* 直前の無限ループによりreturnに到達できない旨の警告を抑制する */
#ifdef MK_OPT_IGNR_WARN_111
	_Pragma("ghs nowarning 111")
#endif
	return;
#ifdef MK_OPT_IGNR_WARN_111
	_Pragma("ghs endnowarning")
#endif
}
#define GW_GSS_STOP_SEC_CODE
#include "GW_GSS_Memmap.h"
