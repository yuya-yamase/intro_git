/****************************************************************************/
/*            Copyright DENSO Corporation. All rights reserved.             */
/****************************************************************************/
/*************************************************************************//**
 * @file        GSS_State.h
 * @brief       システム状態制御のAPI
 * @attention   なし
 * @note        システム状態の取得APIを提供
 ****************************************************************************/

/*--------------------------------------------------------------------------*/
/*        ２重インクルード防止                                              */
/*--------------------------------------------------------------------------*/
#ifndef GSS_STATE_H
#define GSS_STATE_H

/*--------------------------------------------------------------------------*/
/*        ファイルインクルード                                              */
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"
#include "../cfg/GSS_Cfg.h"
#include "../inc/GSS_PostRunReq.h"
#include "../inc/GSS_PreRunReq.h"
#include "../inc/GSS_RunReq.h"

/*--------------------------------------------------------------------------*/
/*        外部公開定数                                                      */
/*--------------------------------------------------------------------------*/
/* PreRun遷移要因 */
#define GSS_PRERUN_FACTOR_RESET		   (0x3CACACACU) /**< リセット*/
#define GSS_PRERUN_FACTOR_DEEPSTOP	   (0x36969696U) /**< ウェイクアップ*/
#define GSS_PRERUN_FACTOR_SLEEPCANCEL  (0x3A5A5A5AU) /**< スリープドタキャン*/
#define GSS_PRERUN_FACTOR_DEFAULT	   (0x35959595U) /**< 無効値*/

/*--------------------------------------------------------------------------*/
/*        マクロ定義                                                        */
/*--------------------------------------------------------------------------*/
/*19PF由来のアプリ向けにローワーキャメルの関数名の置き換えマクロを供給*/
#define GSS_setRunRequest   GSS_SetRunRequest
#define GSS_clearRunRequest GSS_ClearRunRequest
#define GSS_isRunRequested  GSS_IsRunRequested

/*--------------------------------------------------------------------------*/
/*        プロトタイプ宣言                                                  */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_CODE
#include "GW_GSS_Memmap.h"

boolean GSS_IsRun(void);
boolean GSS_IsSupPreRun(void);
boolean GSS_IsPostRun(void);
boolean GSS_IsWupPreRun(void);
boolean GSS_IsSleepCancelPreRun(void);
uint32  GSS_GetPreRunFactor(void);

#define GW_GSS_STOP_SEC_CODE
#include "GW_GSS_Memmap.h"

/* ↓↓↓ビルド確認処置↓↓↓ */
void GSS_State_execPreRunSupHook(void);
void GSS_State_execPreRunWupHook(void);
void GSS_State_execRunHook(void);
void GSS_State_execPostRunHook(void);
/* ↑↑↑ビルド確認処置↑↑↑ */
/*--------------------------------------------------------------------------*/
/*        ２重インクルード防止                                              */
/*--------------------------------------------------------------------------*/
#endif /* GSS_STATE_H */
