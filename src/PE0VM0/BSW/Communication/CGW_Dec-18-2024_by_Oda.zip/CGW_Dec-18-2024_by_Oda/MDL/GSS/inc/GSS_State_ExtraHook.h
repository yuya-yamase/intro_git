/****************************************************************************/
/*            Copyright DENSO Corporation. All rights reserved.             */
/****************************************************************************/
/*************************************************************************//**
 * @file      GSS_State_ExtraHook.h
 * @brief     SS状態コールアウトへ組み付け用関数の公開
 * @attention GSS_State_ExecPreArbitrationCalloutを組み付けている場合は、
 *            本ファイル内の関数は使用不可。
 * @note      None
 ****************************************************************************/

/*--------------------------------------------------------------------------*/
/*        ２重インクルード防止                                              */
/*--------------------------------------------------------------------------*/
#ifndef    GSS_STATE_EXTRAHOOK_H
#define    GSS_STATE_EXTRAHOOK_H

/*--------------------------------------------------------------------------*/
/*        ファイルインクルード                                              */
/*--------------------------------------------------------------------------*/
#include "../cfg/GSS_Cfg.h"

/*--------------------------------------------------------------------------*/
/*        プロトタイプ宣言                                                  */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_CODE
#include "GW_GSS_Memmap.h"

void GSS_State_ExecPreRunSupInDrvHook(void);
void GSS_State_ExecPreRunSupInMedHook(void);
void GSS_State_ExecPreRunSupAppHook(void);
void GSS_State_ExecPreRunSupOutMedHook(void);
void GSS_State_ExecPreRunSupOutDrvHook(void);
void GSS_State_ExecPreRunWupInDrvHook(void);
void GSS_State_ExecPreRunWupInMedHook(void);
void GSS_State_ExecPreRunWupAppHook(void);
void GSS_State_ExecPreRunWupOutMedHook(void);
void GSS_State_ExecPreRunWupOutDrvHook(void);
void GSS_State_ExecRunInDrvHook(void);
void GSS_State_ExecRunInMedHook(void);
void GSS_State_ExecRunAppHook(void);
void GSS_State_ExecRunOutMedHook(void);
void GSS_State_ExecRunOutDrvHook(void);

#if (GSS_USE_SLEEPCANCEL == STD_OFF)
void GSS_State_ExecPostRunInDrvHook(void);
void GSS_State_ExecPostRunInMedHook(void);
void GSS_State_ExecPostRunAppHook(void);
void GSS_State_ExecPostRunOutMedHook(void);
void GSS_State_ExecPostRunOutDrvHook(void);
#endif /*(GSS_USE_SLEEPCANCEL == STD_OFF)*/

#define GW_GSS_STOP_SEC_CODE
#include "GW_GSS_Memmap.h"
/*--------------------------------------------------------------------------*/
/*        ２重インクルード防止                                              */
/*--------------------------------------------------------------------------*/
#endif    /* GSS_STATE_EXTRAHOOK_H */
