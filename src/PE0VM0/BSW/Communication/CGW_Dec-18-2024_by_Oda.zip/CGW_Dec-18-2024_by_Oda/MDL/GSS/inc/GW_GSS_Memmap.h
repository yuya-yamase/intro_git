/****************************************************************************/
/* Copyright DENSO Corporation. All rights reserved                         */
/*************************************************************************//**
 * @file GW_GSS_Memmap.h
 ****************************************************************************/

#include "Section_Util.h"

/*--------------------------------------------------------------------------*/
/* Check Error                                                              */
/*--------------------------------------------------------------------------*/
#if (defined MEMMAP_ERROR)  /* Memmapが間違った方法で使用されていないか確認 */
    #error MEMMAP_ERROR defined, wrong Memmap.h usage
#endif /* if (defined MEMMAP_ERROR) */

#define MEMMAP_ERROR

/*--------------------------------------------------------------------------*/
/* Start Memory Mapping                                                     */
/*--------------------------------------------------------------------------*/
/* GW_GSS_CODE */
#if defined GW_GSS_START_SEC_CODE
    #undef MEMMAP_ERROR
    PRAGMA_SECTION(text, ".gw_gss_code")
    #undef GW_GSS_START_SEC_CODE
#elif defined GW_GSS_STOP_SEC_CODE
    #undef MEMMAP_ERROR
    PRAGMA_SECTION_DEFAULT(text)
    #undef GW_GSS_STOP_SEC_CODE

/* GW_GSS_VAR_NO_INIT */
#elif defined GW_GSS_START_SEC_VAR_NO_INIT
    #undef MEMMAP_ERROR
    PRAGMA_SECTION(bss, ".gw_gss_no_init")
    #undef GW_GSS_START_SEC_VAR_NO_INIT
#elif defined GW_GSS_STOP_SEC_VAR_NO_INIT
    #undef MEMMAP_ERROR
    PRAGMA_SECTION_DEFAULT(bss)
    #undef GW_GSS_STOP_SEC_VAR_NO_INIT

#endif

#if defined MEMMAP_ERROR
    #error "GW_GSS_Memmap.h, wrong Memmap.h usage"
#endif /* MEMMAP_ERROR */
