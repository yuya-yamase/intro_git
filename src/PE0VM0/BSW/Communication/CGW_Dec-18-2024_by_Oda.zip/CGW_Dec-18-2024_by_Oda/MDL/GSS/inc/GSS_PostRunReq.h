/****************************************************************************/
/*            Copyright DENSO Corporation. All rights reserved.             */
/****************************************************************************/
/*************************************************************************//**
 * @file        GSS_PostRunReq.h
 * @brief       PostRun状態維持要求I/F
 * @attention   なし
 * @note        なし
 ****************************************************************************/
#ifndef GSS_POSTRUNREQ_H
#define GSS_POSTRUNREQ_H

/*--------------------------------------------------------------------------*/
/*        ファイルインクルード                                              */
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"
#include "../cfg/GSS_Cfg.h"

/*--------------------------------------------------------------------------*/
/*        関数定義                                                          */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_CODE
#include "GW_GSS_Memmap.h"

#if (GSS_USE_POSTRUN_REQUEST == STD_ON)
void	GSS_SetPostRunRequest(const uint16 id);
void	GSS_ClearPostRunRequest(const uint16 id);
boolean GSS_IsPostRunRequested(const uint16 id);
boolean GSS_GetPostRunRequested(void);
void	GSS_InitPostRunRequest(void);
#else
/* PostRun維持要求用I/Fが不要なためGSS_Stateに組み付けている初期化I/Fを無効化する */
#define GSS_InitPostRunRequest()
#endif

#define GW_GSS_STOP_SEC_CODE
#include "GW_GSS_Memmap.h"

#endif /* GSS_POSTRUNREQ_H */
