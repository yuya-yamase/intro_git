/****************************************************************************/
/*            Copyright DENSO Corporation. All rights reserved.             */
/****************************************************************************/
/*************************************************************************//**
 * @file        GSS_PreRunReq.h
 * @brief       PreRun状態維持要求I/F
 * @attention   なし
 * @note        なし
 ****************************************************************************/
#ifndef GSS_PRERUNREQ_H
#define GSS_PRERUNREQ_H

/*--------------------------------------------------------------------------*/
/*        ファイルインクルード                                              */
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"
#include "../cfg/GSS_Cfg.h"

/*--------------------------------------------------------------------------*/
/*        関数定義                                                          */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_CODE
#include "GW_GSS_Memmap.h"

#if (GSS_USE_PRERUN_REQUEST == STD_ON)
void	GSS_SetPreRunRequest(const uint16 id);
void	GSS_ClearPreRunRequest(const uint16 id);
boolean GSS_IsPreRunRequested(const uint16 id);
boolean GSS_GetPreRunRequested(void);
void	GSS_InitPreRunRequest(void);
#else
/* PreRun維持要求用I/Fが不要なためGSS_Stateに組み付けている初期化I/Fを無効化する */
#define GSS_SetPreRunRequest(id)
#define GSS_InitPreRunRequest()
#endif

#define GW_GSS_STOP_SEC_CODE
#include "GW_GSS_Memmap.h"

#endif /* GSS_PRERUNREQ_H */
