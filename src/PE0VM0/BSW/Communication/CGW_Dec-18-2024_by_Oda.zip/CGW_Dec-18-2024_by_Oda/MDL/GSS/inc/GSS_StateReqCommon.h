/****************************************************************************/
/*            Copyright DENSO Corporation. All rights reserved.             */
/****************************************************************************/
/*************************************************************************//**
 * @file        GSS_StateReqCommon.h
 * @brief       システム状態維持要求の共通関数
 * @attention   【非公開】GSS外部から参照しないこと
 * @note        なし
 ****************************************************************************/
#ifndef GSS_STATEREQCOMMON_H
#define GSS_STATEREQCOMMON_H

/*--------------------------------------------------------------------------*/
/*        ファイルインクルード                                              */
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"

/*--------------------------------------------------------------------------*/
/*        マクロ定義                                                        */
/*--------------------------------------------------------------------------*/
#define GSS_STATE_RUNREQ_ID_BIT1   (0x01U) /**< Run要求IDのビットマップ計算用 */
#define GSS_STATE_RUNREQ_IDNUM_MAX (32U)   /**< 定義可能なRun要求IDの最大数 */
#define GSS_STATE_RUNREQ_NOREQ	   (0U)	   /**< 要求無しを示す */

/*--------------------------------------------------------------------------*/
/*        関数定義                                                          */
/*--------------------------------------------------------------------------*/
/*************************************************************************//**
 * @brief      状態維持要求のセット
 * @param[in]  pReqData 状態要求を保持する変数へのアドレス
 * @param[in]  id RUN要求要因ID
 * @return     None
 * @attention  【非公開】GSS外部から参照しないこと
 * @note       None
 ****************************************************************************/
static inline void GSS_SetStateRequest(uint32* const pReqData, const uint32 id) __attribute__((always_inline));
static inline void GSS_SetStateRequest(uint32* const pReqData, const uint32 id)
{
	if (id < (uint32)GSS_STATE_RUNREQ_IDNUM_MAX) {
		*pReqData |= ((uint32)GSS_STATE_RUNREQ_ID_BIT1 << id);
	}
	return;
}

/*************************************************************************//**
 * @brief      状態維持要求のクリア
 * @param[in]  pReqData 状態要求を保持する変数へのアドレス
 * @param[in]  id RUN要求要因ID
 * @return     None
 * @attention  【非公開】GSS外部から参照しないこと
 * @note       None
 ****************************************************************************/
static inline void GSS_ClearStateRequest(uint32* const pReqData, const uint32 id) __attribute__((always_inline));
static inline void GSS_ClearStateRequest(uint32* const pReqData, const uint32 id)
{
	if (id < (uint32)GSS_STATE_RUNREQ_IDNUM_MAX) {
		*pReqData &= ~((uint32)GSS_STATE_RUNREQ_ID_BIT1 << id);
	}
	return;
}

/*************************************************************************//**
 * @brief      状態維持要求の参照
 * @param[in]  pReqData 状態要求を保持する変数へのアドレス
 * @param[in]  id RUN要求要因ID
 * @return     状態維持要求の有無
 * @attention  【非公開】GSS外部から参照しないこと
 * @note       None
 ****************************************************************************/
static inline boolean GSS_IsStateRequested(const uint32* const pReqData, const uint32 id) __attribute__((always_inline));
static inline boolean GSS_IsStateRequested(const uint32* const pReqData, const uint32 id)
{
	boolean b_Request;
	b_Request = FALSE;

	if (id < (uint32)GSS_STATE_RUNREQ_IDNUM_MAX) {
		if ((*pReqData & ((uint32)GSS_STATE_RUNREQ_ID_BIT1 << id)) != (uint32)GSS_STATE_RUNREQ_NOREQ) {
			b_Request = TRUE;
		}
	}
	return b_Request;
}

/*************************************************************************//**
 * @brief      状態維持要求有無の取得
 * @param[in]  pReqData 状態要求を保持する変数へのアドレス
 * @return     状態維持要求の有無
 * @attention  【非公開】GSS外部から参照しないこと
 * @note       None
 ****************************************************************************/
static inline boolean GSS_GetStateRequested(const uint32* const pReqData) __attribute__((always_inline));
static inline boolean GSS_GetStateRequested(const uint32* const pReqData)
{
	boolean b_Req;
	b_Req = FALSE;

	if (*pReqData != (uint32)GSS_STATE_RUNREQ_NOREQ) {
		b_Req = TRUE;
	}
	return b_Req;
}
#endif /* GSS_STATEREQCOMMON_H */
