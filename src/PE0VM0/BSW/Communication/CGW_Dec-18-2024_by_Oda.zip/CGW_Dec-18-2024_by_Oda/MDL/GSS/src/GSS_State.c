/****************************************************************************/
/*            Copyright DENSO Corporation. All rights reserved.             */
/****************************************************************************/
/*************************************************************************//**
 * @file        GSS_State.c
 * @brief       内製SSのシステム状態遷移を抽象化
 * @attention   なし
 * @note        なし
 ****************************************************************************/

/*--------------------------------------------------------------------------*/
/*        ファイルインクルード                                                */
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"
#include "SS.h"

#include "../cfg/GSS_Cfg.h"
#include "../inc/GSS_PostRunReq.h"
#include "../inc/GSS_PreRunReq.h"
#include "../inc/GSS_RunReq.h"
#include "../inc/GSS_State.h"
#include "../inc/GSS_State_Task.h"

/* ehvm\SCH.hが存在し、その中でSCH_Hが#defineされるため、FWのSCHの定義が取り込めなくなる
 * そのため、暫定処置でundefしている。FWのSCH側でファイル名変更等の対応をする必要がある */
#undef SCH_H
#include "../../FW/SCH/cfg/SCH.h"

/*--------------------------------------------------------------------------*/
/*        ファイル内変数                                                    */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_VAR_NO_INIT
#include "GW_GSS_Memmap.h"

static uint32 GSS_State_preRunFactor; /**< PreRun遷移要因 */

#define GW_GSS_STOP_SEC_VAR_NO_INIT
#include "GW_GSS_Memmap.h"

/*--------------------------------------------------------------------------*/
/*        プロトタイプ宣言                                                  */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_CODE
#include "GW_GSS_Memmap.h"

/* ↓↓↓ビルド確認処置↓↓↓ */
//static void GSS_State_execPreRunSupHook(void);
//static void GSS_State_execPreRunWupHook(void);
//static void GSS_State_execRunHook(void);
//static void GSS_State_execPostRunHook(void);
/* ↑↑↑ビルド確認処置↑↑↑ */
static boolean GSS_isPreRun(const uint32 factor);

#define GW_GSS_STOP_SEC_CODE
#include "GW_GSS_Memmap.h"

/* unused: GSS_USE_POSTRUN/GSS_USE_SLEEPCANCELコンフィグによって下記関数は使用しないことがあるため */
static inline void GSS_State_execEntryPostRunCalloutImplP0S0(void) __attribute__((always_inline, unused));
static inline void GSS_State_execEntryPostRunCalloutImplP1S0(void) __attribute__((always_inline, unused));
static inline void GSS_State_execEntryPostRunCalloutImplP0S1(void) __attribute__((always_inline, unused));
static inline void GSS_State_execEntryPostRunCalloutImplP1S1(void) __attribute__((always_inline, unused));
static inline void GSS_State_execPostRunHookImplP0S0(void) __attribute__((always_inline, unused));
static inline void GSS_State_execPostRunHookImplP1S0(void) __attribute__((always_inline, unused));
static inline void GSS_State_execPostRunHookImplP0S1(void) __attribute__((always_inline, unused));
static inline void GSS_State_execPostRunHookImplP1S1(void) __attribute__((always_inline, unused));
static inline void GSS_State_execShutdownCalloutImplP0S0(void) __attribute__((always_inline, unused));
static inline void GSS_State_execShutdownCalloutImplP1S0(void) __attribute__((always_inline, unused));
static inline void GSS_State_execShutdownCalloutImplP0S1(void) __attribute__((always_inline, unused));
static inline void GSS_State_execShutdownCalloutImplP1S1(void) __attribute__((always_inline, unused));

/*--------------------------------------------------------------------------*/
/*        コンフィグによる切り替え                                          */
/*--------------------------------------------------------------------------*/
#if (GSS_USE_POSTRUN == STD_OFF) && (GSS_USE_SLEEPCANCEL == STD_OFF)
#define GSS_State_execEntryPostRunCalloutImpl() GSS_State_execEntryPostRunCalloutImplP0S0()
#define GSS_State_execPostRunHookImpl()         GSS_State_execPostRunHookImplP0S0()
#define GSS_State_execShutdownCalloutImpl()     GSS_State_execShutdownCalloutImplP0S0()

#elif (GSS_USE_POSTRUN == STD_ON) && (GSS_USE_SLEEPCANCEL == STD_OFF)
#define GSS_State_execEntryPostRunCalloutImpl() GSS_State_execEntryPostRunCalloutImplP1S0()
#define GSS_State_execPostRunHookImpl()         GSS_State_execPostRunHookImplP1S0()
#define GSS_State_execShutdownCalloutImpl()     GSS_State_execShutdownCalloutImplP1S0()

#elif (GSS_USE_POSTRUN == STD_OFF) && (GSS_USE_SLEEPCANCEL == STD_ON)
#define GSS_State_execEntryPostRunCalloutImpl() GSS_State_execEntryPostRunCalloutImplP0S1()
#define GSS_State_execPostRunHookImpl()         GSS_State_execPostRunHookImplP0S1()
#define GSS_State_execShutdownCalloutImpl()     /*GSS_State_execShutdownCalloutImplP0S1()*/

#elif (GSS_USE_POSTRUN == STD_ON) && (GSS_USE_SLEEPCANCEL == STD_ON)
#define GSS_State_execEntryPostRunCalloutImpl() GSS_State_execEntryPostRunCalloutImplP1S1()
#define GSS_State_execPostRunHookImpl()         GSS_State_execPostRunHookImplP1S1()
#define GSS_State_execShutdownCalloutImpl()     GSS_State_execShutdownCalloutImplP1S1()

#else
#error "invalid configuration"
#endif

#ifdef _DEBUG
#include "GSS_State_Debug.h"
#endif

/*--------------------------------------------------------------------------*/
/*        関数定義                                                          */
/*--------------------------------------------------------------------------*/
#define GW_GSS_START_SEC_CODE
#include "GW_GSS_Memmap.h"
/*************************************************************************//**
 * @brief      SS_Pm_preClockUpCalloutに組み付ける処理
 * @return     None
 * @param      resetFactor リセット要因
 * @attention  リセットorウェイクアップの判定結果を引数に設定しコールすること
 * @note       None
 ****************************************************************************/
void GSS_State_ExecPreClockUpCallout(const uint32 resetFactor)
{
	/* PreClockUp⇒PostClockUpの間でSSによるRAM初期化があるため、
	 * この時点ではリセット要因をGSS内のRAMへコピーしない */

	if (resetFactor != (uint32)GSS_RESET_FACTOR_CATEGORY_DEEPSTOP) {
		/* ウェイクアップ以外はリセットとして扱う */
		SCH_powerOnInitHook_0();
	} else {
		SCH_preWakeupHook_0();
	}
	return;
}

/*************************************************************************//**
 * @brief      SS_Pm_postClockUpCalloutに組み付ける処理
 * @return     None
 * @param      resetFactor リセット要因
 * @attention  リセットorウェイクアップの判定結果を引数に設定しコールすること
 * @note       None
 ****************************************************************************/
void GSS_State_ExecPostClockUpCallout(const uint32 resetFactor)
{
	if (resetFactor != (uint32)GSS_RESET_FACTOR_CATEGORY_DEEPSTOP) {
		/* PreRun遷移要因にリセットをセット。
		 * (ウェイクアップ以外はリセットとして扱う) */
		SCH_resetInitHook_0();
		GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_RESET;
	} else {
		/* PreRun遷移要因にウェイクアップをセット */
		SCH_wakeupHook_0();
		GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_DEEPSTOP;
	}
	return;
}

/*************************************************************************//**
 * @brief      SS_Mm_entryPreRunCalloutに組み付ける処理
 * @return     None
 * @attention  None
 * @note       None
 ****************************************************************************/
void GSS_State_ExecEntryPreRunCallout( void )
{
	GSS_InitPreRunRequest();

	switch (GSS_State_preRunFactor) {
	default:
	case (uint32)GSS_PRERUN_FACTOR_SLEEPCANCEL:
	case (uint32)GSS_PRERUN_FACTOR_DEFAULT:
		/* 異常。リセット時処理を実行する */
	case (uint32)GSS_PRERUN_FACTOR_RESET:
		SCH_entryPreRunHook_0();
		GSS_SetPreRunRequest((uint16)GSS_RUNREQ_SS_AWAKE); /* 1周はPreRun5階層を実行する */
		GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_RESET;
		break;
	case (uint32)GSS_PRERUN_FACTOR_DEEPSTOP:
		/* 梅では異常遷移だが、竹では正常。処理共通化のため正常扱いにする */
		SCH_reEntryPreRunHook_DeepS_0();
		GSS_SetPreRunRequest((uint16)GSS_RUNREQ_SS_AWAKE); /* 1周はPreRun5階層を実行する */
		GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_DEEPSTOP;
		break;
	}
	return;
}

/*************************************************************************//**
 * @brief      SS_Mm_reEntryPreRunCalloutに組み付ける処理
 * @return     None
 * @attention  None
 * @note       None
 ****************************************************************************/
void GSS_State_ExecReEntryPreRunCallout( void )
{
	GSS_InitPreRunRequest();

	switch (GSS_State_preRunFactor) {
	default:
	case (uint32)GSS_PRERUN_FACTOR_RESET:
		/* 異常。要因無し時の処理を実行する */
	case (uint32)GSS_PRERUN_FACTOR_DEFAULT:
		GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_DEFAULT;
		break;
	case (uint32)GSS_PRERUN_FACTOR_DEEPSTOP:
		/* 竹では異常遷移だが、梅では正常。処理共通化のため正常扱いにする */
		SCH_reEntryPreRunHook_DeepS_0();
		GSS_SetPreRunRequest((uint16)GSS_RUNREQ_SS_AWAKE); /* 1周はPreRun5階層を実行する */
		GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_DEEPSTOP;
		break;	
	case (uint32)GSS_PRERUN_FACTOR_SLEEPCANCEL:
		SCH_reEntryPreRunHook_DeepS_0();
		GSS_SetPreRunRequest((uint16)GSS_RUNREQ_SS_AWAKE); /* 1周はPreRun5階層を実行する */
		GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_SLEEPCANCEL;
		break;
	}
	return;
}

/*************************************************************************//**
 * @brief      SS_Mm_entryRunCalloutに組み付ける処理
 * @return     None
 * @attention  None
 * @note       None
 ****************************************************************************/
void GSS_State_ExecEntryRunCallout( void )
{
	GSS_InitRunRequest();
	
	switch (GSS_State_preRunFactor) {
	case (uint32)GSS_PRERUN_FACTOR_RESET:
		SCH_entryRunHook_Reset_0();
		break;
	case (uint32)GSS_PRERUN_FACTOR_DEEPSTOP:
	case (uint32)GSS_PRERUN_FACTOR_SLEEPCANCEL:
		SCH_entryRunHook_Wkup_0();
		break;
	case (uint32)GSS_PRERUN_FACTOR_DEFAULT:
		/* 処理無し */
	default:
		/* 異常。処理なし */
		break;
	}
	/* Run状態まで遷移するとPreRun要因は、その後の遷移に関係ないため
	 * フェール処置として無効値をセットする */
	GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_DEFAULT;

	/* Run状態のメインタスクを最低1度は実行するため、GSSとしてRun要求を出す。
	 * (EntryRunに処理が無く、Run状態5階層にのみ処理があるアプリを想定した処置) */
	GSS_SetRunRequest((uint16)GSS_RUNREQ_SS_AWAKE);
	
	return;
}

/*************************************************************************//**
 * @brief      EntryPostRun時の処理
 * @return     None
 * @attention  None
 * @note       None
 ****************************************************************************/
void GSS_State_ExecEntryPostRunCallout( void )
{
	GSS_State_execEntryPostRunCalloutImpl();
	return;
}

/*************************************************************************//**
 * @brief      メインタスク5階層の処理
 * @return     None
 * @attention  None
 * @note       None
 ****************************************************************************/
void GSS_State_ExecPreArbitrationCallout( void )
{
	SS_Mm_modeType state;

	state = SS_Mm_getMode();
	switch ((uint32)state) {
	case (uint32)SS_MM_PRERUN_SUP:
		GSS_State_execPreRunSupHook();
		break;
	case (uint32)SS_MM_PRERUN_WUP:
		GSS_State_execPreRunWupHook();
		break;
	case (uint32)SS_MM_RUN:
		GSS_State_execRunHook();
		break;
	case (uint32)SS_MM_POSTRUN:
		GSS_State_execPostRunHook();
		break;
	default:
		/* あり得ない。SS_Mm_getMode内の検査でリセットになるはず */
		break;
	}
	return;
}

/*************************************************************************//**
 * @brief      SSがPreRunSupを通知した場合の処理
 * @return     None
 * @attention  None
 * @note       PreRunSup時の5階層
 ****************************************************************************/
void GSS_State_execPreRunSupHook( void )
{
	GSS_InitPreRunRequest();

	switch (GSS_State_preRunFactor) {
	case (uint32)GSS_PRERUN_FACTOR_RESET:
		SCH_startupInDrvHook_0();
		SCH_startupInMedHook_0();
		SCH_startupAppHook_0();
		SCH_startupOutMedHook_0();
		SCH_startupOutDrvHook_0();
		GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_RESET;
		break;
	case (uint32)GSS_PRERUN_FACTOR_DEEPSTOP:
		SCH_wakeupInDrvHook_DeepS_0();
		SCH_wakeupInMedHook_DeepS_0();
		SCH_wakeupAppHook_DeepS_0();
		SCH_wakeupOutMedHook_DeepS_0();
		SCH_wakeupOutDrvHook_DeepS_0();
		GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_DEEPSTOP;
		break;
	case (uint32)GSS_PRERUN_FACTOR_SLEEPCANCEL:
	case (uint32)GSS_PRERUN_FACTOR_DEFAULT:
	default:
		/* 異常。要因無し時の処理を実行する */
		GSS_State_preRunFactor = GSS_PRERUN_FACTOR_DEFAULT;
		break;
	}
	return;
}

/*************************************************************************//**
 * @brief      SSがPreRunWupを通知した場合の処理
 * @return     None
 * @attention  None
 * @note       PreRunWup時の5階層
 ****************************************************************************/
void GSS_State_execPreRunWupHook(void)
{
	GSS_InitPreRunRequest();

	switch (GSS_State_preRunFactor) {
	default:
	case (uint32)GSS_PRERUN_FACTOR_RESET:
	case (uint32)GSS_PRERUN_FACTOR_DEEPSTOP:
		/* 異常。要因無し時の処理を実行する */
	case (uint32)GSS_PRERUN_FACTOR_DEFAULT:
		GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_DEFAULT;
		break;
	case (uint32)GSS_PRERUN_FACTOR_SLEEPCANCEL:
		SCH_wakeupInDrvHook_DeepS_0();
		SCH_wakeupInMedHook_DeepS_0();
		SCH_wakeupAppHook_DeepS_0();
		SCH_wakeupOutMedHook_DeepS_0();
		SCH_wakeupOutDrvHook_DeepS_0();
		GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_SLEEPCANCEL;
		break;
	}
	return;
}

/*************************************************************************//**
 * @brief      SSがRun状態を通知した場合の処理
 * @return     None
 * @attention  None
 * @note       Run時の5階層
 ****************************************************************************/
void GSS_State_execRunHook( void )
{
	/* GSS要因のRun要求をクリア。GSSとしてRun要求があれば5階層の中でセットする */
	GSS_InitRunRequest();
	
	SCH_runInDrvHook_0();
	SCH_runInMedHook_0();
	SCH_runAppHook_0();
	SCH_runOutMedHook_0();
	SCH_runOutDrvHook_0();
	/* 製品要件のRun要求確認のフックを起動 */
	GSS_CheckRunRequest();
	GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_DEFAULT;
	return;
}

/*************************************************************************//**
 * @brief      SSがPostRun状態を通知した場合の処理
 * @return     None
 * @attention  None
 * @note       停止準備処理を実行する
 ****************************************************************************/
void GSS_State_execPostRunHook( void )
{
	GSS_State_execPostRunHookImpl();
	return;
}

/*************************************************************************//**
 * @brief      スリープ直前の処理
 * @details    スリープ前に実施する処理（CSのシャットダウン等）
 * @return     None
 * @attention  SS_Pm_shutdownCalloutに組み付けること
 * @note       None
 ****************************************************************************/
void GSS_State_ExecShutdownCallout( void )
{
	GSS_State_execShutdownCalloutImpl();
	return;
}

/*************************************************************************//**
 * @brief      高優先度タスクの処理
 * @return     None
 * @attention  None
 * @note       None
 ****************************************************************************/
void GSS_State_ExecDriverTaskUserHook( void )
{
	SCH_driverTaskUserHook_0();
	return;
}

/*************************************************************************//**
 * @brief      アイドル時の処理
 * @return     None
 * @attention  None
 * @note       None
 ****************************************************************************/
void GSS_State_ExecIdleTaskUserHook( void )
{
	SCH_idleTaskUserHook_0();
	return;
}

/*--------------------------------------------------------------------------*/
/*        コンフィグ毎の処理                                                */
/*--------------------------------------------------------------------------*/
#if ((GSS_USE_POSTRUN == STD_OFF) && (GSS_USE_SLEEPCANCEL == STD_OFF)) || defined(_DEBUG)
/*************************************************************************//**
 * @brief      GSS_USE_POSTRUN==STD_OFF && GSS_USE_SLEEPCANCEL=STD_OFFの場合の
 *             GSS_State_ExecEntryPostRunCalloutの処理
 * @return     None
 ****************************************************************************/
static inline void GSS_State_execEntryPostRunCalloutImplP0S0(void)
{
	SCH_entryPostRunHook_0();
	GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_DEFAULT;
	return;
}

/*************************************************************************//**
 * @brief      GSS_USE_POSTRUN==STD_OFF && GSS_USE_SLEEPCANCEL=STD_OFFの場合の
 *             GSS_State_execPostRunHookの処理
 * @return     None
 ****************************************************************************/
static inline void GSS_State_execPostRunHookImplP0S0(void)
{
	GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_DEFAULT;
	return;
}

/*************************************************************************//**
 * @brief      GSS_USE_POSTRUN==STD_OFF && GSS_USE_SLEEPCANCEL=STD_OFFの場合の
 *             GSS_State_ExecShutdownCalloutの処理
 * @return     None
 ****************************************************************************/
static inline void GSS_State_execShutdownCalloutImplP0S0(void)
{
	SCH_sleepHook_0();
	return;
}
#endif /* ((GSS_USE_POSTRUN == STD_OFF) && (GSS_USE_SLEEPCANCEL == STD_OFF)) || defined(_DEBUG) */

#if ((GSS_USE_POSTRUN == STD_ON) && (GSS_USE_SLEEPCANCEL == STD_OFF)) || defined(_DEBUG)
/*************************************************************************//**
 * @brief      GSS_USE_POSTRUN==STD_ON && GSS_USE_SLEEPCANCEL=STD_OFFの場合の
 *             GSS_State_ExecEntryPostRunCalloutの処理
 * @return     None
 ****************************************************************************/
static inline void GSS_State_execEntryPostRunCalloutImplP1S0(void)
{
	GSS_InitPostRunRequest();
	SCH_entryPostRunHook_0();
	GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_DEFAULT;
	/* 1周はPostRun5階層を実行する */
	GSS_SetPostRunRequest((uint16)GSS_RUNREQ_SS_AWAKE);
	return;
}

/*************************************************************************//**
 * @brief      GSS_USE_POSTRUN==STD_ON && GSS_USE_SLEEPCANCEL=STD_OFFの場合の
 *             GSS_State_execPostRunHookの処理
 * @return     None
 ****************************************************************************/
static inline void GSS_State_execPostRunHookImplP1S0(void)
{
	if ((uint32)GSS_GetPostRunRequested() == (uint32)TRUE) {
		GSS_InitPostRunRequest();

		SCH_postRunInDrvHook_0();
		SCH_postRunInMedHook_0();
		SCH_postRunAppHook_0();
		SCH_postRunOutMedHook_0();
		SCH_postRunOutDrvHook_0();
	}
	GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_DEFAULT;
	return;
}

/*************************************************************************//**
 * @brief      GSS_USE_POSTRUN==STD_ON && GSS_USE_SLEEPCANCEL=STD_OFFの場合の
 *             GSS_State_ExecShutdownCalloutの処理
 * @return     None
 ****************************************************************************/
static inline void GSS_State_execShutdownCalloutImplP1S0(void)
{
	SCH_sleepHook_0();
	return;
}
#endif /* ((GSS_USE_POSTRUN == STD_ON) && (GSS_USE_SLEEPCANCEL == STD_OFF)) || defined(_DEBUG) */

#if ((GSS_USE_POSTRUN == STD_OFF) && (GSS_USE_SLEEPCANCEL == STD_ON)) || defined(_DEBUG)
/*************************************************************************//**
 * @brief      GSS_USE_POSTRUN==STD_OFF && GSS_USE_SLEEPCANCEL=STD_ONの場合の
 *             GSS_State_ExecEntryPostRunCalloutの処理
 * @return     None
 ****************************************************************************/
static inline void GSS_State_execEntryPostRunCalloutImplP0S1(void)
{
	SCH_entryPostRunHook_0();
	GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_DEFAULT;
	
	SCH_sleepHook_0();
	/* アプリのシャットダウンを完了したため、
	 * PreRunWupに遷移した場合はドタキャンとして扱う */
	GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_SLEEPCANCEL;
	return;
}

/*************************************************************************//**
 * @brief      GSS_USE_POSTRUN==STD_OFF && GSS_USE_SLEEPCANCEL=STD_ONの場合の
 *             GSS_State_execPostRunHookの処理
 * @return     None
 ****************************************************************************/
static inline void GSS_State_execPostRunHookImplP0S1(void)
{
	GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_SLEEPCANCEL;
	return;
}

/*************************************************************************//**
 * @brief      GSS_USE_POSTRUN==STD_OFF && GSS_USE_SLEEPCANCEL=STD_ONの場合の
 *             GSS_State_ExecShutdownCalloutの処理
 * @return     None
 ****************************************************************************/
/* 下記の場合の処理が無い。M3CM Rule-2.2で警告が出るためコメントアウトする。
static inline void GSS_State_execShutdownCalloutImplP0S1(void)
{
	return;
} */
#endif /* ((GSS_USE_POSTRUN == STD_OFF) && (GSS_USE_SLEEPCANCEL == STD_ON)) || defined(_DEBUG) */

#if ((GSS_USE_POSTRUN == STD_ON) && (GSS_USE_SLEEPCANCEL == STD_ON)) || defined(_DEBUG)
/*************************************************************************//**
 * @brief      GSS_USE_POSTRUN==STD_ON && GSS_USE_SLEEPCANCEL=STD_ONの場合の
 *             GSS_State_ExecEntryPostRunCalloutの処理
 * @return     None
 ****************************************************************************/
static inline void GSS_State_execEntryPostRunCalloutImplP1S1(void)
{
	GSS_InitPostRunRequest();
	SCH_entryPostRunHook_0();
	GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_DEFAULT;
	/* 1周はPostRun5階層を実行する */
	GSS_SetPostRunRequest((uint16)GSS_RUNREQ_SS_AWAKE);
	return;
}

/*************************************************************************//**
 * @brief      GSS_USE_POSTRUN==STD_ON && GSS_USE_SLEEPCANCEL=STD_ONの場合の
 *             GSS_State_execPostRunHookの処理
 * @return     None
 ****************************************************************************/
static inline void GSS_State_execPostRunHookImplP1S1(void)
{
	if ((uint32)GSS_GetPostRunRequested() == (uint32)TRUE) {
		GSS_InitPostRunRequest();

		SCH_postRunInDrvHook_0();
		SCH_postRunInMedHook_0();
		SCH_postRunAppHook_0();
		SCH_postRunOutMedHook_0();
		SCH_postRunOutDrvHook_0();
		GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_DEFAULT;

		if ((uint32)GSS_GetPostRunRequested() == (uint32)FALSE) {
			/* PostRun要求が無いためアプリを停止する */
			SCH_sleepHook_0();
			/* アプリのシャットダウンを完了したため、
			 * PreRunWupに遷移した場合はドタキャンとして扱う */
			GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_SLEEPCANCEL;
		}
	} else {
		GSS_State_preRunFactor = (uint32)GSS_PRERUN_FACTOR_SLEEPCANCEL;
	}
	return;
}

/*************************************************************************//**
 * @brief      GSS_USE_POSTRUN==STD_ON && GSS_USE_SLEEPCANCEL=STD_ONの場合の
 *             GSS_State_ExecShutdownCalloutの処理
 * @return     None
 ****************************************************************************/
static inline void GSS_State_execShutdownCalloutImplP1S1(void)
{
	if (((uint32)GSS_GetPostRunRequested() == (uint32)TRUE) 
		|| (GSS_State_preRunFactor != (uint32)GSS_PRERUN_FACTOR_SLEEPCANCEL)) {
		/* フェール処置。正常であればこの処理に至ることは無い。
		 * PostRun5階層の停止準備処理が完了していない状態で、
		 * このフックにSSが遷移しているため、シャットダウン処理を実行する */
		SCH_sleepHook_0();
	}
	return;
}
#endif /* ((GSS_USE_POSTRUN == STD_ON) && (GSS_USE_SLEEPCANCEL == STD_ON)) || defined(_DEBUG) */

/*--------------------------------------------------------------------------*/
/*        システム状態の取得用I/F                                           */
/*--------------------------------------------------------------------------*/
/*************************************************************************//**
 * @brief      Run状態か判定する
 * @return     Run状態か否か
 * @attention  5階層でのみコール可能
 * @note       None
 ****************************************************************************/
boolean GSS_IsRun(void)
{
	return (boolean)((uint32)SS_Mm_getMode() == (uint32)SS_MM_RUN);
}

/*************************************************************************//**
 * @brief      PreRunStartup状態か判定する
 * @return     PreRun状態か否か
 * @attention  5階層でのみコール可能
 * @note       None
 ****************************************************************************/
boolean GSS_IsSupPreRun(void)
{
	boolean retval = FALSE;
	if ((uint32)SS_Mm_getMode() == (uint32)SS_MM_PRERUN_SUP) {
		if (GSS_State_preRunFactor == (uint32)GSS_PRERUN_FACTOR_RESET) {
			retval = TRUE;
		}
	}
	return retval;
}

/*************************************************************************//**
 * @brief      PostRun状態か判定する
 * @return     PostRun状態か否か
 * @attention  5階層でのみコール可能
 * @note       None
 ****************************************************************************/
boolean GSS_IsPostRun(void)
{
	return (boolean)((uint32)SS_Mm_getMode() == (uint32)SS_MM_POSTRUN);
}

/*************************************************************************//**
 * @brief      ウェイクアップorドタキャンのどちらのPreRun状態か判定する
 * @param[in]  factor 比較対象のPreRun要因を指定(DEEPSTOP or SLEEPCANCEL)
 * @retval     TRUE  factorと一致するPreRun状態である
 * @retval     FALSE factorと一致しない
 * @attention  5階層でのみコール可能
 * @note       None
 ****************************************************************************/
static boolean GSS_isPreRun(const uint32 factor)
{
	boolean        retval = FALSE;
	SS_Mm_modeType state;

	state = SS_Mm_getMode();
	switch ((uint32)state) {
	case (uint32)SS_MM_PRERUN_SUP:
	case (uint32)SS_MM_PRERUN_WUP:
		/* SS_USE_SLEEP次第でウェイクアップ時に通知されるSS状態が異なるため
		 * SUPとWUPの両パターンに対応する */
		if (GSS_State_preRunFactor == factor) {
			retval = TRUE;
		}
		break;
	case (uint32)SS_MM_RUN:
	case (uint32)SS_MM_POSTRUN:
	default:
		/* 処理なし */
		break;
	}
	return retval;
}

/*************************************************************************//**
 * @brief      PreRunWakeup状態か判定する
 * @return     ウェイクアップ時のPreRunか否か
 * @attention  5階層でのみコール可能
 * @note       None
 ****************************************************************************/
boolean GSS_IsWupPreRun(void)
{
	return GSS_isPreRun((uint32)GSS_PRERUN_FACTOR_DEEPSTOP);
}

/*************************************************************************//**
 * @brief      スリープドタキャンのPreRun状態か判定する
 * @return     ドタキャン時のPreRunか否か
 * @attention  5階層でのみコール可能
 * @note       None
 ****************************************************************************/
boolean GSS_IsSleepCancelPreRun(void)
{
	return GSS_isPreRun((uint32)GSS_PRERUN_FACTOR_SLEEPCANCEL);
}

/*************************************************************************//**
 * @brief      PreRun遷移要因を返す
 * @return     PreRun遷移要因
 * @attention  None
 * @note       None
 ****************************************************************************/
uint32 GSS_GetPreRunFactor(void)
{
	return GSS_State_preRunFactor;
}
#define GW_GSS_STOP_SEC_CODE
#include "GW_GSS_Memmap.h"
