 /****************************************************************************
 *  Copyright (c) 2010 Denso Corporation
 *  機能            イベント発火時に呼び出す関数リストのプロトタイプ宣言をする
 *
 *  備考            CodeGenFWから自動生成
 ****************************************************************************/
#ifndef EVT_FUNCLIST_H
#define EVT_FUNCLIST_H

#define UTIL_EVENT_INMED_MAX_EVENT_NUM      (2U)
#define UTIL_EVENT_APP_MAX_EVENT_NUM        (2U)
#define UTIL_EVENT_OUTMED_MAX_EVENT_NUM     (2U)

#define UTIL_INMED_USED_BIT_AREA_AT_LASTARRAY   (0x00000003U)
#define UTIL_APP_USED_BIT_AREA_AT_LASTARRAY     (0x00000003U)
#define UTIL_OUTMED_USED_BIT_AREA_AT_LASTARRAY  (0x00000003U)

typedef void (*EventFunction) (void);

#define GW_FW_START_SEC_CONST
#include "GW_FW_Memmap.h"
/*イベント発火時に呼び出す関数リスト(入力調停層用)*/
extern const EventFunction Util_Event_InMed_FunctionList[UTIL_EVENT_INMED_MAX_EVENT_NUM];
/*イベント発火時に呼び出す関数リスト(アプリ層用)*/
extern const EventFunction Util_Event_App_FunctionList[UTIL_EVENT_APP_MAX_EVENT_NUM];
/*イベント発火時に呼び出す関数リスト(出力調停層用)*/
extern const EventFunction Util_Event_OutMed_FunctionList[UTIL_EVENT_OUTMED_MAX_EVENT_NUM];
#define GW_FW_STOP_SEC_CONST
#include "GW_FW_Memmap.h"


#define GW_FW_START_SEC_CODE
#include "GW_FW_Memmap.h"
/* 入力調停層 */

void EvtImL3RCan300MtrSuspendList(void);
void EvtImL3RCtrlfrmMtrSuspendList(void);

/* アプリ層 */

void EvtApL3RCan300MtrSuspendList(void);
void EvtApL3RCtrlfrmMtrSuspendList(void);

/* 出力調停層 */

void EvtOmL3RCan300MtrSuspendList(void);
void EvtOmL3RCtrlfrmMtrSuspendList(void);
#define GW_FW_STOP_SEC_CODE
#include "GW_FW_Memmap.h"



#endif /* EVT_FUNCLIST_H */
