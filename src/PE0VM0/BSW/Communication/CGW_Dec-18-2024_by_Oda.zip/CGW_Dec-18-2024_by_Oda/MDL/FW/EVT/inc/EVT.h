 /****************************************************************************
 *  Copyright (c) 2010 Denso Corporation
 *  機能            イベントの登録・発行を行う
 *
 *  備考            なし
 ****************************************************************************/
#ifndef EVT_H
#define EVT_H

#include "Std_Types.h"
#include "EVT_ID.h"

#define GW_FW_START_SEC_VAR_NO_INIT
#include "GW_FW_Memmap.h"

extern boolean Util_Event_SendEnable;

#define GW_FW_STOP_SEC_VAR_NO_INIT
#include "GW_FW_Memmap.h"

#define GW_FW_START_SEC_CODE
#include "GW_FW_Memmap.h"

/**
* 作動準備中以外かどうかを切り替える
* @param なし
* @return なし
* @attention 作動準備完了フックの最初と、RAM化け対策のため通常作動の周期タスクで利用する
*/
#define EVT_SetSendEnable() (Util_Event_SendEnable = TRUE)

void EVT_SendInMed(const uint16 eventID);
void EVT_SendApp(const uint16 eventID);
void EVT_SendOutMed(const uint16 eventID);

void EVT_DispatchInMed(void);
void EVT_DispatchApp(void);
void EVT_DispatchOutMed(void);

#ifdef _DEBUG
void EVT_DebugInit(void);
#endif

#define GW_FW_STOP_SEC_CODE
#include "GW_FW_Memmap.h"

#endif /* EVT_H */
