/****************************************************************************/
/* Copyright DENSO Corporation. All rights reserved                         */
/*************************************************************************//**
 * @file GW_FW_Memmap.h
 ****************************************************************************/

#include "Section_Util.h"

/*--------------------------------------------------------------------------*/
/* Check Error                                                              */
/*--------------------------------------------------------------------------*/
#if (defined MEMMAP_ERROR)  /* Memmapが間違った方法で使用されていないか確認 */
    #error MEMMAP_ERROR defined, wrong Memmap.h usage
#endif /* if (defined MEMMAP_ERROR) */

#define MEMMAP_ERROR

/*--------------------------------------------------------------------------*/
/* Start Memory Mapping                                                     */
/*--------------------------------------------------------------------------*/
/* GW_FW_CODE */
#if defined GW_FW_START_SEC_CODE
    #undef MEMMAP_ERROR
    PRAGMA_SECTION(text, ".gw_fw_code")
    #undef GW_FW_START_SEC_CODE
#elif defined GW_FW_STOP_SEC_CODE
    #undef MEMMAP_ERROR
    PRAGMA_SECTION_DEFAULT(text)
    #undef GW_FW_STOP_SEC_CODE

/* GW_FW_CONST */
#elif defined GW_FW_START_SEC_CONST
    #undef MEMMAP_ERROR
    PRAGMA_SECTION(rodata, ".gw_fw_const")
    #undef GW_FW_START_SEC_CONST
#elif defined GW_FW_STOP_SEC_CONST
    #undef MEMMAP_ERROR
    PRAGMA_SECTION_DEFAULT(rodata)
    #undef GW_FW_STOP_SEC_CONST

/* GW_FW_VAR_NO_INIT */
#elif defined GW_FW_START_SEC_VAR_NO_INIT
    #undef MEMMAP_ERROR
    PRAGMA_SECTION(bss, ".gw_fw_no_init")
    #undef GW_FW_START_SEC_VAR_NO_INIT
#elif defined GW_FW_STOP_SEC_VAR_NO_INIT
    #undef MEMMAP_ERROR
    PRAGMA_SECTION_DEFAULT(bss)
    #undef GW_FW_STOP_SEC_VAR_NO_INIT

#endif

#if defined MEMMAP_ERROR
    #error "GW_FW_Memmap.h, wrong Memmap.h usage"
#endif /* MEMMAP_ERROR */
