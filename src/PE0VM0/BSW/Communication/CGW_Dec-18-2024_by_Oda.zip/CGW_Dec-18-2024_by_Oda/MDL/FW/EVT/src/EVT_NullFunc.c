 /****************************************************************************
 *  Copyright (c) 2011 Denso Corporation
 *  機能           EVTで利用する空関数を定義する
 *
 *  備考
 ****************************************************************************/
#include "Std_Types.h"
#include "EVT_NullFunc.h"

#define GW_FW_START_SEC_CODE
#include "GW_FW_Memmap.h"

/**
*　空関数
* @param なし
* @return なし
*/
void EVT_NullFunc_void(void)
{
	return;
}

#define GW_FW_STOP_SEC_CODE
#include "GW_FW_Memmap.h"

