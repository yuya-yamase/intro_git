 /****************************************************************************
 *  Copyright (c) 2010 Denso Corporation
 *  機能            イベントが使用するIDを定義する
 *
 *  備考            CodeGenFWから自動生成
 ****************************************************************************/
#ifndef EVT_ID_H
#define EVT_ID_H

/* 入力調停層 */
#define EVT_IM_L3R_CAN300_MTR_SUSPEND (0U)
#define EVT_IM_L3R_CTRLFRM_MTR_SUSPEND (1U)

/* アプリ層 */
#define EVT_AP_L3R_CAN300_MTR_SUSPEND (0U)
#define EVT_AP_L3R_CTRLFRM_MTR_SUSPEND (1U)

/* 出力調停層 */
#define EVT_OM_L3R_CAN300_MTR_SUSPEND (0U)
#define EVT_OM_L3R_CTRLFRM_MTR_SUSPEND (1U)

#endif /* EVT_ID_H */
