/****************************************************************************/
/*            Copyright DENSO Corporation. All rights reserved.             */
/****************************************************************************/
/*************************************************************************//**
 * @file        SCH.h
 * @brief       フレームワーク スケジューラ 外部公開ヘッダ
 * @details     スケジューラ外部公開ヘッダ
 * @date        
 * @attention   なし
 * @note        CodeGenFWにより生成
 ****************************************************************************/
#ifndef SCH_H
#define SCH_H

/*--------------------------------------------------------------------------*/
/* ファイルインクルード                                                     */
/*--------------------------------------------------------------------------*/
#include "CS_Can.h"
#include "TIM.h"
#include "L3R.h"
#include "EVT.h"
#include "INFR_SysTimer.h"
#include "L3R_canmbq_main.h"
//#include "Cgw_oem.h"

/*--------------------------------------------------------------------------*/
/* inline関数                                                               */
/*--------------------------------------------------------------------------*/

/*----- 入力ドライバ (InDrv) Hook ------------------------------------------*/
static inline void SCH_startupInDrvHook_0(void) __attribute__((always_inline));
static inline void SCH_startupInDrvHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    TIM_Ticker_Base_TickID();
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    BswM_CS_MainFunctionMiddle();
    L3R_System_MainInDrvTask();
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_runInDrvHook_0(void) __attribute__((always_inline));
static inline void SCH_runInDrvHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    TIM_Ticker_Base_TickID();
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    BswM_CS_MainFunctionMiddle();
    L3R_System_MainInDrvTask();
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_postRunInDrvHook_0(void) __attribute__((always_inline));
static inline void SCH_postRunInDrvHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    BswM_CS_MainFunctionMiddle();
    L3R_System_MainInDrvTask();
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_wakeupInDrvHook_DeepS_0(void) __attribute__((always_inline));
static inline void SCH_wakeupInDrvHook_DeepS_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    BswM_CS_MainFunctionMiddle();
    L3R_System_MainInDrvTask();
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

/*----- 入力調停 (InMed) Hook ----------------------------------------------*/
static inline void SCH_startupInMedHook_0(void) __attribute__((always_inline));
static inline void SCH_startupInMedHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    TIM_Ticker_Base_TickIM();
    EVT_DispatchInMed();
    INFR_SysTimer_Update();
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    L3R_System_MainInMedTask();
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_runInMedHook_0(void) __attribute__((always_inline));
static inline void SCH_runInMedHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    TIM_Ticker_Base_TickIM();
    EVT_DispatchInMed();
    INFR_SysTimer_Update();
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    L3R_System_MainInMedTask();
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_postRunInMedHook_0(void) __attribute__((always_inline));
static inline void SCH_postRunInMedHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    EVT_DispatchInMed();
    INFR_SysTimer_Update();
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    L3R_System_MainInMedTask();
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_wakeupInMedHook_DeepS_0(void) __attribute__((always_inline));
static inline void SCH_wakeupInMedHook_DeepS_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    EVT_DispatchInMed();
    INFR_SysTimer_Update();
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    L3R_System_MainInMedTask();
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

/*----- アプリケーション (App) Hook ----------------------------------------*/
static inline void SCH_startupAppHook_0(void) __attribute__((always_inline));
static inline void SCH_startupAppHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    TIM_Ticker_Base_TickAP();
    EVT_DispatchApp();
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    CANMBQ_Omed_Er();
    L3R_System_MainAppTask();
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_runAppHook_0(void) __attribute__((always_inline));
static inline void SCH_runAppHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    TIM_Ticker_Base_TickAP();
    EVT_DispatchApp();
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    CANMBQ_Omed_Er();
    L3R_System_MainAppTask();
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_postRunAppHook_0(void) __attribute__((always_inline));
static inline void SCH_postRunAppHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    EVT_DispatchApp();
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    CANMBQ_Omed_Er();
    L3R_System_MainAppTask();
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_wakeupAppHook_DeepS_0(void) __attribute__((always_inline));
static inline void SCH_wakeupAppHook_DeepS_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    EVT_DispatchApp();
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    CANMBQ_Omed_Er();
    L3R_System_MainAppTask();
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

/*----- 出力調停 (OutMed) Hook ---------------------------------------------*/
static inline void SCH_startupOutMedHook_0(void) __attribute__((always_inline));
static inline void SCH_startupOutMedHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    TIM_Ticker_Base_TickOM();
    EVT_DispatchOutMed();
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    L3R_System_MainOutMedTask();
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_runOutMedHook_0(void) __attribute__((always_inline));
static inline void SCH_runOutMedHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    TIM_Ticker_Base_TickOM();
    EVT_DispatchOutMed();
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    L3R_System_MainOutMedTask();
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_postRunOutMedHook_0(void) __attribute__((always_inline));
static inline void SCH_postRunOutMedHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    EVT_DispatchOutMed();
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    L3R_System_MainOutMedTask();
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_wakeupOutMedHook_DeepS_0(void) __attribute__((always_inline));
static inline void SCH_wakeupOutMedHook_DeepS_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    EVT_DispatchOutMed();
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    L3R_System_MainOutMedTask();
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

/*----- 出力ドライバ (OutDrv) Hook -----------------------------------------*/
static inline void SCH_startupOutDrvHook_0(void) __attribute__((always_inline));
static inline void SCH_startupOutDrvHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    TIM_Ticker_Base_TickOD();
    EVT_SetSendEnable();
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    /* 基準：FW_TAIL_start */
    TIM_Ticker_Base_ChkEnableSleep();
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_runOutDrvHook_0(void) __attribute__((always_inline));
static inline void SCH_runOutDrvHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    TIM_Ticker_Base_TickOD();
    EVT_SetSendEnable();
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    /* 基準：FW_TAIL_start */
    TIM_Ticker_Base_ChkEnableSleep();
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_postRunOutDrvHook_0(void) __attribute__((always_inline));
static inline void SCH_postRunOutDrvHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    EVT_SetSendEnable();
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_wakeupOutDrvHook_DeepS_0(void) __attribute__((always_inline));
static inline void SCH_wakeupOutDrvHook_DeepS_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    EVT_SetSendEnable();
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

/*----- 初期化Hook ---------------------------------------------------------*/
static inline void SCH_powerOnInitHook_0(void) __attribute__((always_inline));
static inline void SCH_powerOnInitHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_resetInitHook_0(void) __attribute__((always_inline));
static inline void SCH_resetInitHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_entryPreRunHook_0(void) __attribute__((always_inline));
static inline void SCH_entryPreRunHook_0(void)
{
    /* 基準：HEAD */
    BswM_CS_Init();
    /* 基準：FW_HEAD_start */
    EVT_SetSendEnable();
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    INFR_SysTimer_Init();
    CANMBQ_ClrSendLockFlg();
    L3R_System_ResetInitialze();
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_preWakeupHook_0(void) __attribute__((always_inline));
static inline void SCH_preWakeupHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_wakeupHook_0(void) __attribute__((always_inline));
static inline void SCH_wakeupHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_reEntryPreRunHook_DeepS_0(void) __attribute__((always_inline));
static inline void SCH_reEntryPreRunHook_DeepS_0(void)
{
    /* 基準：HEAD */
    BswM_CS_Wakeup();
    /* 基準：FW_HEAD_start */
    EVT_SetSendEnable();
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    INFR_SysTimer_Init();
    CANMBQ_ClrSendLockFlg();
    L3R_System_WakeUpInitialze();
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_sleepHook_0(void) __attribute__((always_inline));
static inline void SCH_sleepHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    TIM_Ticker_Base_InitSlpInTimer();
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    BswM_CS_Sleep();
    L3R_System_EntryPostRunHook();
    L3R_System_SleepInitialze();
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

/*----- 状態移行Hook -------------------------------------------------------*/
static inline void SCH_entryRunHook_Reset_0(void) __attribute__((always_inline));
static inline void SCH_entryRunHook_Reset_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_entryPostRunHook_0(void) __attribute__((always_inline));
static inline void SCH_entryPostRunHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_entryRunHook_Wkup_0(void) __attribute__((always_inline));
static inline void SCH_entryRunHook_Wkup_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_sleepCheckHook_0(void) __attribute__((always_inline));
static inline void SCH_sleepCheckHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

static inline void SCH_wupCheckHook_0(void) __attribute__((always_inline));
static inline void SCH_wupCheckHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

/*----- ドライバタスクHook -------------------------------------------------*/
static inline void SCH_driverTaskUserHook_0(void) __attribute__((always_inline));
static inline void SCH_driverTaskUserHook_0(void)
{
    /* 基準：HEAD */
    BswM_CS_MainFunctionHigh();
    L3R_System_DriverTask();
    CANMBQ_DriverTask();
    INFR_SysTimer_Update_1ms();
    /* 基準：FW_HEAD_start */
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

/*----- アイドルタスクHook -------------------------------------------------*/
static inline void SCH_idleTaskUserHook_0(void) __attribute__((always_inline));
static inline void SCH_idleTaskUserHook_0(void)
{
    /* 基準：HEAD */
    /* 基準：FW_HEAD_start */
    /* 基準：FW_HEAD_end */
    /* 基準：BSW_CS_start */
    /* 基準：BSW_CS_end */
    /* 基準：BSW_MS_start */
    /* 基準：BSW_MS_end */
    /* 基準：APP_start */
    /* 基準：UNSPECIFIED */
    /* 基準：FW_TAIL_start */
    /* 基準：FW_TAIL_end */
    /* 基準：TAIL */
}

/*----- 入力ドライバ (InDrv) Hook ------------------------------------------*/
static inline void SCH_startupInDrvHook_1(void) __attribute__((always_inline));
static inline void SCH_startupInDrvHook_1(void)
{
}

static inline void SCH_runInDrvHook_1(void) __attribute__((always_inline));
static inline void SCH_runInDrvHook_1(void)
{
}

static inline void SCH_postRunInDrvHook_1(void) __attribute__((always_inline));
static inline void SCH_postRunInDrvHook_1(void)
{
}

static inline void SCH_wakeupInDrvHook_DeepS_1(void) __attribute__((always_inline));
static inline void SCH_wakeupInDrvHook_DeepS_1(void)
{
}

/*----- 入力調停 (InMed) Hook ----------------------------------------------*/
static inline void SCH_startupInMedHook_1(void) __attribute__((always_inline));
static inline void SCH_startupInMedHook_1(void)
{
}

static inline void SCH_runInMedHook_1(void) __attribute__((always_inline));
static inline void SCH_runInMedHook_1(void)
{
}

static inline void SCH_postRunInMedHook_1(void) __attribute__((always_inline));
static inline void SCH_postRunInMedHook_1(void)
{
}

static inline void SCH_wakeupInMedHook_DeepS_1(void) __attribute__((always_inline));
static inline void SCH_wakeupInMedHook_DeepS_1(void)
{
}

/*----- アプリケーション (App) Hook ----------------------------------------*/
static inline void SCH_startupAppHook_1(void) __attribute__((always_inline));
static inline void SCH_startupAppHook_1(void)
{
}

static inline void SCH_runAppHook_1(void) __attribute__((always_inline));
static inline void SCH_runAppHook_1(void)
{
}

static inline void SCH_postRunAppHook_1(void) __attribute__((always_inline));
static inline void SCH_postRunAppHook_1(void)
{
}

static inline void SCH_wakeupAppHook_DeepS_1(void) __attribute__((always_inline));
static inline void SCH_wakeupAppHook_DeepS_1(void)
{
}

/*----- 出力調停 (OutMed) Hook ---------------------------------------------*/
static inline void SCH_startupOutMedHook_1(void) __attribute__((always_inline));
static inline void SCH_startupOutMedHook_1(void)
{
}

static inline void SCH_runOutMedHook_1(void) __attribute__((always_inline));
static inline void SCH_runOutMedHook_1(void)
{
}

static inline void SCH_postRunOutMedHook_1(void) __attribute__((always_inline));
static inline void SCH_postRunOutMedHook_1(void)
{
}

static inline void SCH_wakeupOutMedHook_DeepS_1(void) __attribute__((always_inline));
static inline void SCH_wakeupOutMedHook_DeepS_1(void)
{
}

/*----- 出力ドライバ (OutDrv) Hook -----------------------------------------*/
static inline void SCH_startupOutDrvHook_1(void) __attribute__((always_inline));
static inline void SCH_startupOutDrvHook_1(void)
{
}

static inline void SCH_runOutDrvHook_1(void) __attribute__((always_inline));
static inline void SCH_runOutDrvHook_1(void)
{
}

static inline void SCH_postRunOutDrvHook_1(void) __attribute__((always_inline));
static inline void SCH_postRunOutDrvHook_1(void)
{
}

static inline void SCH_wakeupOutDrvHook_DeepS_1(void) __attribute__((always_inline));
static inline void SCH_wakeupOutDrvHook_DeepS_1(void)
{
}

/*----- 初期化Hook ---------------------------------------------------------*/
static inline void SCH_powerOnInitHook_1(void) __attribute__((always_inline));
static inline void SCH_powerOnInitHook_1(void)
{
}

static inline void SCH_resetInitHook_1(void) __attribute__((always_inline));
static inline void SCH_resetInitHook_1(void)
{
}

static inline void SCH_entryPreRunHook_1(void) __attribute__((always_inline));
static inline void SCH_entryPreRunHook_1(void)
{
}

static inline void SCH_preWakeupHook_1(void) __attribute__((always_inline));
static inline void SCH_preWakeupHook_1(void)
{
}

static inline void SCH_wakeupHook_1(void) __attribute__((always_inline));
static inline void SCH_wakeupHook_1(void)
{
}

static inline void SCH_reEntryPreRunHook_DeepS_1(void) __attribute__((always_inline));
static inline void SCH_reEntryPreRunHook_DeepS_1(void)
{
}

static inline void SCH_sleepHook_1(void) __attribute__((always_inline));
static inline void SCH_sleepHook_1(void)
{
}

/*----- 状態移行Hook -------------------------------------------------------*/
static inline void SCH_entryRunHook_Reset_1(void) __attribute__((always_inline));
static inline void SCH_entryRunHook_Reset_1(void)
{
}

static inline void SCH_entryPostRunHook_1(void) __attribute__((always_inline));
static inline void SCH_entryPostRunHook_1(void)
{
}

static inline void SCH_entryRunHook_Wkup_1(void) __attribute__((always_inline));
static inline void SCH_entryRunHook_Wkup_1(void)
{
}

static inline void SCH_sleepCheckHook_1(void) __attribute__((always_inline));
static inline void SCH_sleepCheckHook_1(void)
{
}

static inline void SCH_wupCheckHook_1(void) __attribute__((always_inline));
static inline void SCH_wupCheckHook_1(void)
{
}

/*----- ドライバタスクHook -------------------------------------------------*/
static inline void SCH_driverTaskUserHook_1(void) __attribute__((always_inline));
static inline void SCH_driverTaskUserHook_1(void)
{
}

/*----- アイドルタスクHook -------------------------------------------------*/
static inline void SCH_idleTaskUserHook_1(void) __attribute__((always_inline));
static inline void SCH_idleTaskUserHook_1(void)
{
}

#endif /* SCH_H */
/*----End of File-----------------------------------------------------------*/
