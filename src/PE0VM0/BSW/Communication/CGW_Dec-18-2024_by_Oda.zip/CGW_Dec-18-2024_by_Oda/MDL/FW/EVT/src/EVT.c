/****************************************************************************
 *  Copyright (c) 2010 Denso Corporation
 *  機能            イベントの登録・発行を行う
 *
 *  備考            なし
 ****************************************************************************/
#include "Std_Types.h"
#include "GSS.h"
#include "EVT_FuncList.h"
#include "UTIL_SLIB.h"
#include "EVT.h"

#define UTIL_EVENT_BIT_FLAG_SIZE        (32U)
#define UTIL_EVENT_ARRAY_SHIFT_LENGTH   (5U)
#define UTIL_EVENT_BIT_REQUEST_NOTHING  (UTIL_EVENT_BIT_OFF)
#define UTIL_EVENT_BIT_OFF              (0x00000000U)
#define UTIL_EVENT_ID_MASK              (0x001FU)

#define UTIL_INMED_EVENT_BUFF_SIZE   ((UTIL_EVENT_INMED_MAX_EVENT_NUM + UTIL_EVENT_ID_MASK) / UTIL_EVENT_BIT_FLAG_SIZE)
#define UTIL_APP_EVENT_BUFF_SIZE     ((UTIL_EVENT_APP_MAX_EVENT_NUM + UTIL_EVENT_ID_MASK) / UTIL_EVENT_BIT_FLAG_SIZE)
#define UTIL_OUTMED_EVENT_BUFF_SIZE  ((UTIL_EVENT_OUTMED_MAX_EVENT_NUM + UTIL_EVENT_ID_MASK) / UTIL_EVENT_BIT_FLAG_SIZE)

#define GW_FW_START_SEC_VAR_NO_INIT
#include "GW_FW_Memmap.h"

boolean Util_Event_SendEnable;                                /*イベント発火できるようにするためのフラグ*/

static uint32 Util_Event_InMedRequest[UTIL_INMED_EVENT_BUFF_SIZE];     /* 入力調停のイベントバッファ */
static uint32 Util_Event_AppRequest[UTIL_APP_EVENT_BUFF_SIZE];         /* アプリ層用イベントバッファ */
static uint32 Util_Event_OutMedRequest[UTIL_OUTMED_EVENT_BUFF_SIZE];   /* 出力調停のイベントバッファ */

#define GW_FW_STOP_SEC_VAR_NO_INIT
#include "GW_FW_Memmap.h"


#define GW_FW_START_SEC_CODE
#include "GW_FW_Memmap.h"

static void EVT_EventCommonCall(const uint16 eventID, const uint16 maxIDNum, uint32* const eventFlagRequest);
static void EVT_EventCommonDispatcher(uint32* const array, const uint32 arraySize, const EventFunction functionList[]);

/**
 *　入力調停層のイベント発行
 * @param eventID イベントのID
 * @return なし
 * @attention 発火処理中にイベントが立つことを防ぐため、入力調停層では使用しないこと
 */
void EVT_SendInMed(const uint16 eventID) 
{
    EVT_EventCommonCall(eventID, UTIL_EVENT_INMED_MAX_EVENT_NUM, Util_Event_InMedRequest);
    GSS_setRunRequest(GSS_RUNREQ_INMED);
    return;
}

/**
 *　アプリ層のイベント発行
 * @param eventID イベントのID
 * @return なし
 * @attention 発火処理中にイベントが立つことを防ぐため、アプリ層では使用しないこと
 */
void EVT_SendApp(const uint16 eventID) 
{
    if ((uint32)TRUE == (uint32)Util_Event_SendEnable) {
    	EVT_EventCommonCall(eventID, UTIL_EVENT_APP_MAX_EVENT_NUM, Util_Event_AppRequest);
    	GSS_setRunRequest(GSS_RUNREQ_APP);
    }
    return;
}

/**
 *　出力調停層のイベント発行
 * @param eventID イベントのID
 * @return なし
 * @attention 発火処理中にイベントが立つことを防ぐため、出力調停層では使用しないこと
 */
void EVT_SendOutMed(const uint16 eventID) 
{
    if ((uint32)TRUE == (uint32)Util_Event_SendEnable) {
    	EVT_EventCommonCall(eventID, UTIL_EVENT_OUTMED_MAX_EVENT_NUM, Util_Event_OutMedRequest);
    	GSS_setRunRequest(GSS_RUNREQ_OUTMED);
    }
    return;
}

static void EVT_EventCommonCall(const uint16 eventID, const uint16 maxIDNum, uint32 *const eventFlagRequest)
{
    if ((uint32)eventID < (uint32)maxIDNum) {
        /* IDに対応した要求フラグを立てる */
        eventFlagRequest [ ((uint32)eventID >> (uint32)UTIL_EVENT_ARRAY_SHIFT_LENGTH)]
                |= (((uint32)1U) << ((uint32)eventID & ((uint32)UTIL_EVENT_ID_MASK)));
    }
    return;
}

/**
 *　入力調停層のイベント発火
 * @param なし
 * @return なし
 * @attention 入力調停層でイベントを１つも利用しない車両の場合は、空となります。
 */
void EVT_DispatchInMed(void) 
{
#if (UTIL_INMED_EVENT_BUFF_SIZE > 0UL)
	/* 最後の配列の場合のみ、RAM化け対策として未使用領域を0でマスクする処理を記述 */
	Util_Event_InMedRequest[UTIL_INMED_EVENT_BUFF_SIZE - 1U] &= (uint32)UTIL_INMED_USED_BIT_AREA_AT_LASTARRAY;
	EVT_EventCommonDispatcher(Util_Event_InMedRequest, UTIL_INMED_EVENT_BUFF_SIZE, Util_Event_InMed_FunctionList);
	GSS_clearRunRequest(GSS_RUNREQ_INMED);
#else
#endif
	return;
}

/**
 *　アプリ層のイベント発火
 * @param なし
 * @return なし
 * @attention アプリ層でイベントを１つも利用しない車両の場合は、空となります。
 */
void EVT_DispatchApp(void) 
{
#if (UTIL_APP_EVENT_BUFF_SIZE > 0UL)
	/* 最後の配列の場合のみ、RAM化け対策として未使用領域を0でマスクする処理を記述 */
	Util_Event_AppRequest[UTIL_APP_EVENT_BUFF_SIZE - 1U] &= (uint32)UTIL_APP_USED_BIT_AREA_AT_LASTARRAY;
	EVT_EventCommonDispatcher(Util_Event_AppRequest, UTIL_APP_EVENT_BUFF_SIZE, Util_Event_App_FunctionList);
	GSS_clearRunRequest(GSS_RUNREQ_APP);
#else
#endif
	return;
}

/**
 *　出力調停層のイベント発火
 * @param なし
 * @return なし
 * @attention 出力調停層でイベントを１つも利用しない車両の場合は、空となります。
 */
void EVT_DispatchOutMed(void) 
{
#if (UTIL_OUTMED_EVENT_BUFF_SIZE > 0UL)
	/* 最後の配列の場合のみ、RAM化け対策として未使用領域を0でマスクする処理を記述 */
	Util_Event_OutMedRequest[UTIL_OUTMED_EVENT_BUFF_SIZE - 1U] &= (uint32)UTIL_OUTMED_USED_BIT_AREA_AT_LASTARRAY;
	EVT_EventCommonDispatcher(Util_Event_OutMedRequest, UTIL_OUTMED_EVENT_BUFF_SIZE, Util_Event_OutMed_FunctionList);
	GSS_clearRunRequest(GSS_RUNREQ_OUTMED);
#else
#endif
	return;
}

/* イベントを発火する関数 */
static void EVT_EventCommonDispatcher(uint32 *const array, const uint32 arraySize, const EventFunction functionList[]) 
{
    uint32 i;
    uint32 k;
    uint32 checkBit;
    uint32 restoreId;
    uint32 *const eventRequest = array;
	uint32 shiftresult;

    /* イベントリクエスト(Bit管理)の数(イベント数 / 32(Bit管理なので))でループ */
    for (i = 0U; i < arraySize; i++) {
        checkBit = 1U;
        k = 0U;
        /* イベントリクエストで各bitをチェックするために32回ループ */
        while((eventRequest[i] != (uint32)UTIL_EVENT_BIT_REQUEST_NOTHING) &&
              (k < (uint32)UTIL_EVENT_BIT_FLAG_SIZE)) {
            /* 該当bitのイベントが発火されているかチェック */
            if ((eventRequest[i] & checkBit) != (uint32)UTIL_EVENT_BIT_OFF) {
                /* 該当Bitのイベントを0からの連番に変換 */
            	shiftresult = i << (uint32)UTIL_EVENT_ARRAY_SHIFT_LENGTH;
                restoreId = UTIL_AddU4(shiftresult, k);
                /* 該当Bitのイベント関数をコール */
                functionList[restoreId]();
                /* 該当Bitのイベントを落とす */
                eventRequest[i] &= (uint32) ~checkBit;
            }
            checkBit <<= 1U;
            k++;
        }
    }
    return;
}
#ifdef _DEBUG
/**
 *　初期化関数（テスト用）
 * @param なし
 * @return なし
 * @attention テストケース毎に初期化する必要がある場合に呼び出す
 */
void EVT_DebugInit(void)
{
	uint32 i;
	
	Util_Event_SendEnable = 0U;
	
	for (i = 0U; i < UTIL_INMED_EVENT_BUFF_SIZE; i++) {
		Util_Event_InMedRequest[i] = 0U;
	}
	
	for (i = 0U; i < UTIL_INMED_EVENT_BUFF_SIZE; i++) {
		Util_Event_InMedRequest[i] = 0U;
	}
	
	for (i = 0U; i < UTIL_INMED_EVENT_BUFF_SIZE; i++) {
		Util_Event_InMedRequest[i] = 0U;
	}
	return;
}
#endif

#define GW_FW_STOP_SEC_CODE
#include "GW_FW_Memmap.h"

