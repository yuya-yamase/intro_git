 /****************************************************************************
 *  Copyright (c) 2011 Denso Corporation
 *  機能           ドメイン共通で利用する空関数を定義する
 *
 *  備考
 ****************************************************************************/
#ifndef EVT_NULLFUNC_H
#define EVT_NULLFUNC_H

#define GW_FW_START_SEC_CODE
#include "GW_FW_Memmap.h"

void EVT_NullFunc_void(void);

#define GW_FW_STOP_SEC_CODE
#include "GW_FW_Memmap.h"

#endif /* EVT_NULLFUNC_H */
