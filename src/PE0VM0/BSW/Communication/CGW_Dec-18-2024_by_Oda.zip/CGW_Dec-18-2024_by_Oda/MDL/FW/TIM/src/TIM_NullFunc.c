 /****************************************************************************
 *  Copyright (c) 2011 Denso Corporation
 *  機能           ドメイン共通で利用する空関数を定義する
 *
 *  備考
 ****************************************************************************/
#include "Std_Types.h"

#include "TIM_NullFunc.h"

#define GW_FW_START_SEC_CODE
#include "GW_FW_Memmap.h"

/**
*　空関数
* @param なし
* @return なし
*/

void TIM_NullFunc_void(void *Arg)
{
	return;
}

#define GW_FW_STOP_SEC_CODE
#include "GW_FW_Memmap.h"

