 /****************************************************************************
 *  Copyright (c) 2010-11 Denso Corporation
 *  機能            ベースチッカ
 *
 *  備考            アプリスケジューラとのIF
 ****************************************************************************/
#include "Std_Types.h"
#include "INFR_SS.h"

#include "TIM_Ticker.h"
#include "TIM_Ticker_Cfg.h"
#include "TIM_Ticker_Base.h"
#include "UTIL_SLIB.h"

#define MINUTES_TICKER	 	(((uint32)UTIL_TICKER_MN_TIME_LSB / INFR_U4MAINTASK_ACTIVATECYCLE))
#define SECOND_TICK_MASK	(0x0003U)				/* Secondチッカを発火するために必要 */

#define GW_FW_START_SEC_VAR_NO_INIT
#include "GW_FW_Memmap.h"

static uint32 BaseCounter; 							/* second、minutesチッカを発火させるために必要な変数 */

#define GW_FW_STOP_SEC_VAR_NO_INIT
#include "GW_FW_Memmap.h"


#define GW_FW_START_SEC_CODE
#include "GW_FW_Memmap.h"

void TIM_Ticker_Base_TickBaseTime(void)
{
	/* リセットがあるまでチッカカウンタの初期化は行わない。
	 * 作動準備、通常作動の開始時にチッカカウンタ値が異なることによる
	 * 発火のタイミングの違いは許容する。 */
	BaseCounter = UTIL_IncU4( BaseCounter );
	if ( BaseCounter >= (uint32)MINUTES_TICKER ) {
		BaseCounter = 0U;
	}
	return;
}

boolean TIM_Ticker_Base_CanTickScTimer(void)
{
    boolean Rslt = FALSE;
    
    if ( (BaseCounter & (uint32)SECOND_TICK_MASK) == (uint32)0U ) {
        Rslt = TRUE;
    }
    return (Rslt);
}

boolean TIM_Ticker_Base_CanTickMnTimer(void)
{
    boolean Rslt = FALSE;
    
    if ( BaseCounter == (uint32)0U ) {
        Rslt = TRUE;
    }
    return (Rslt);
}

#ifdef _DEBUG
/**
 *　初期化関数（テスト用）
 * @param なし
 * @return なし
 * @attention テストケース毎に初期化する必要がある場合に呼び出す
 */
void TIM_Ticker_Base_DebugInit(void)
{
	BaseCounter = 0U;
	return;
}
#endif

#define GW_FW_STOP_SEC_CODE
#include "GW_FW_Memmap.h"

