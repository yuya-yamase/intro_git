 /****************************************************************************
 *  Copyright (c) 2011 Denso Corporation
 *  機能            使用するタイマに応じ、関連する処理の有無を調整する
 *
 *  備考            CodeGenFWから自動生成
 ****************************************************************************/
#ifndef TIM_TICKER_CFG_H
#define TIM_TICKER_CFG_H

#include "TIM_Ticker.h"
#include "TIM_Cfg.h"

/*********************
 * tickコンフィグ
 *********************/
/*** Normalチッカ ***/
/* 入力ドライバ MilliSec */
#define Util_Ticker_ID_MS_tick()

/* 入力ドライバ Second */
#define Util_Ticker_ID_SC_tick()

/* 入力ドライバ Minutes */
#define Util_Ticker_ID_MN_tick()

/* 入力調停 MilliSec */
#define Util_Ticker_IM_MS_tick()

/* 入力調停 Second */
#define Util_Ticker_IM_SC_tick()

/* 入力調停 Minutes */
#define Util_Ticker_IM_MN_tick()

/* アプリ MilliSec */
#define Util_Ticker_AP_MS_tick()

/* アプリ Second */
#define Util_Ticker_AP_SC_tick()

/* アプリ Minutes */
#define Util_Ticker_AP_MN_tick()

/* 出力調停 MilliSec */
#define Util_Ticker_OM_MS_tick()

/* 出力調停 Second */
#define Util_Ticker_OM_SC_tick()

/* 出力調停 Minutes */
#define Util_Ticker_OM_MN_tick()

/* 出力ドライバ MilliSec */
#define Util_Ticker_OD_MS_tick()

/* 出力ドライバ Second */
#define Util_Ticker_OD_SC_tick()

/* 出力ドライバ Minutes */
#define Util_Ticker_OD_MN_tick()

/*** Dozyチッカ ***/
/* 入力ドライバ Dozy Minutes */
#define Util_Ticker_ID_DMN_tick()

/* 入力調停 Dozy Minutes */
#define Util_Ticker_IM_DMN_tick()

/* アプリ Dozy Minutes */
#define Util_Ticker_AP_DMN_tick()

/* 出力調停 Dozy Minutes */
#define Util_Ticker_OM_DMN_tick()

/* 出力ドライバ Dozy Minutes */
#define Util_Ticker_OD_DMN_tick()

/*** SlpInチッカ ***/
/* 入力ドライバ SlpIn MilliSec */
#define Util_Ticker_ID_SMS_tick()

/* 入力ドライバ SlpIn Second */
#define Util_Ticker_ID_SSC_tick()

/* 入力ドライバ SlpIn Minutes */
#define Util_Ticker_ID_SMN_tick()

/* 入力調停 SlpIn MilliSec */
#define Util_Ticker_IM_SMS_tick()

/* 入力調停 SlpIn Second */
#define Util_Ticker_IM_SSC_tick()

/* 入力調停 SlpIn Minutes */
#define Util_Ticker_IM_SMN_tick()

/* アプリ SlpIn MilliSec */
#define Util_Ticker_AP_SMS_tick()

/* アプリ SlpIn Second */
#define Util_Ticker_AP_SSC_tick()

/* アプリ SlpIn Minutes */
#define Util_Ticker_AP_SMN_tick()

/* 出力調停 SlpIn MilliSec */
#define Util_Ticker_OM_SMS_tick()

/* 出力調停 SlpIn Second */
#define Util_Ticker_OM_SSC_tick()

/* 出力調停 SlpIn Minutes */
#define Util_Ticker_OM_SMN_tick()

/* 出力ドライバ SlpIn MilliSec */
#define Util_Ticker_OD_SMS_tick()

/* 出力ドライバ SlpIn Second */
#define Util_Ticker_OD_SSC_tick()

/* 出力ドライバ SlpIn Minutes */
#define Util_Ticker_OD_SMN_tick()

/*********************
 * checkSleepNGコンフィグ
 *********************/
#define Util_Ticker_checkSleepNGAll()

/*********************
 * WakeUpコンフィグ
 *********************/
/* 入力ドライバ Dozy Minutes */
#define Util_Ticker_ID_DMN_wakeUp()

/* 入力調停 Dozy Minutes */
#define Util_Ticker_IM_DMN_wakeUp()

/* アプリ Dozy Minutes */
#define Util_Ticker_AP_DMN_wakeUp()

/* 出力調停 Dozy Minutes */
#define Util_Ticker_OM_DMN_wakeUp()

/* 出力ドライバ Dozy Minutes */
#define Util_Ticker_OD_DMN_wakeUp()


/*********************
 * initSlpコンフィグ
 *********************/
#define Util_Ticker_initSlpInTimerAll()


#endif /* TIM_TICKER_CFG_H */
