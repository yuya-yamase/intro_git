 /****************************************************************************
 *  Copyright (c) 2010 Denso Corporation  
 *  機能            イベント発火時に呼び出す関数リストを定義する            
 *                                                                          
 *  備考            CodeGenFWから自動生成
 ****************************************************************************/
#include "Std_Types.h"
#include "EVT_FuncList.h"

#define GW_FW_START_SEC_CONST
#include "GW_FW_Memmap.h"
/*イベント発火時に呼び出す関数リスト(入力調停層用)*/
const EventFunction Util_Event_InMed_FunctionList[UTIL_EVENT_INMED_MAX_EVENT_NUM] =
{
        &EvtImL3RCan300MtrSuspendList,
        &EvtImL3RCtrlfrmMtrSuspendList,
};

/*イベント発火時に呼び出す関数リスト(アプリ層用)*/
const EventFunction Util_Event_App_FunctionList[UTIL_EVENT_APP_MAX_EVENT_NUM] =
{
        &EvtApL3RCan300MtrSuspendList,
        &EvtApL3RCtrlfrmMtrSuspendList,
};

/*イベント発火時に呼び出す関数リスト(出力調停層用)*/
const EventFunction Util_Event_OutMed_FunctionList[UTIL_EVENT_OUTMED_MAX_EVENT_NUM] =
{
        &EvtOmL3RCan300MtrSuspendList,
        &EvtOmL3RCtrlfrmMtrSuspendList,
};
#define GW_FW_STOP_SEC_CONST
#include "GW_FW_Memmap.h"
