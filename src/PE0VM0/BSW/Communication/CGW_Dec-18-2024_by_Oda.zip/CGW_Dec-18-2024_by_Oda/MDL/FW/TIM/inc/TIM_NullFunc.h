 /****************************************************************************
 *  Copyright (c) 2011 Denso Corporation
 *  機能           ドメイン共通で利用する空関数を定義する
 *
 *  備考
 ****************************************************************************/
#ifndef TIM_NULLFUNC_H
#define TIM_NULLFUNC_H

#define GW_FW_START_SEC_CODE
#include "GW_FW_Memmap.h"

void TIM_NullFunc_void(void *Arg);

#define GW_FW_STOP_SEC_CODE
#include "GW_FW_Memmap.h"

#endif /* TIM_NULLFUNC_H */
