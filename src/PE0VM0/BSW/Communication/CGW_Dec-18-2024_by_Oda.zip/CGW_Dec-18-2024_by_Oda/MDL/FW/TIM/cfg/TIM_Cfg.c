 /****************************************************************************
 *  Copyright (c) 2010-11 Denso Corporation
 *  機能            各階層でタイマ時間経過後に発火する関数配列と時間を入れる配列の初期化
 *
 *  備考            CodeGenFWから自動生成
 ****************************************************************************/
#include "Std_Types.h"

#include "TIM.h"
#include "TIM_Cfg.h"

#define GW_FW_START_SEC_VAR_NO_INIT
#include "GW_FW_Memmap.h"
/*関数が発火する時間を入れる配列*/
uint16 Util_Timer_Time[UTIL_TIMER_ALL_NUM];
#define GW_FW_STOP_SEC_VAR_NO_INIT
#include "GW_FW_Memmap.h"

#define GW_FW_START_SEC_CONST
#include "GW_FW_Memmap.h"
/*各層、各チッカで発火する関数を登録している配列*/
ST_TMR_FUNC Util_Timer_Function[UTIL_TIMER_ALL_NUM] = {
};
#define GW_FW_STOP_SEC_CONST
#include "GW_FW_Memmap.h"
