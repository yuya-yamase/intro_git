 /****************************************************************************
 *  Copyright (c) 2010 Denso Corporation
 *  機能            イベントのリストが呼び出す関数を定義する
 *
 *  備考            CodeGenFWから自動生成
 ****************************************************************************/
#include "Std_Types.h"
#include "EVT_FuncList.h"

#include "EVT_NullFunc.h"

#define GW_FW_START_SEC_CODE
#include "GW_FW_Memmap.h"
/*イベントのリストが呼び出す関数リスト(入力調停層用)*/
void EvtImL3RCan300MtrSuspendList(void){
	EVT_NullFunc_void();
	return;
}
void EvtImL3RCtrlfrmMtrSuspendList(void){
	EVT_NullFunc_void();
	return;
}
/*イベントのリストが呼び出す関数リスト(アプリ層用)*/
void EvtApL3RCan300MtrSuspendList(void){
	EVT_NullFunc_void();
	return;
}
void EvtApL3RCtrlfrmMtrSuspendList(void){
	EVT_NullFunc_void();
	return;
}
/*イベントのリストが呼び出す関数リスト(出力調停層用)*/
void EvtOmL3RCan300MtrSuspendList(void){
	EVT_NullFunc_void();
	return;
}
void EvtOmL3RCtrlfrmMtrSuspendList(void){
	EVT_NullFunc_void();
	return;
}
#define GW_FW_STOP_SEC_CODE
#include "GW_FW_Memmap.h"
