/*****************************************************************************
 *	Copyright DENSO Corporation. All rights reserved.
 ****************************************************************************/
/*****************************************************************************
 * @file		UTIL_TYPE.h
 * @breif		System symbols
 * @attention	None
 * @note		None
 ****************************************************************************/
#ifndef     UTIL_TYPE_H
#define     UTIL_TYPE_H

/*----------------------------------------------------------------------------
 *		Symbols
 *--------------------------------------------------------------------------*/
#define UTIL_TYPE_U1BITSIZE    (8U)
#define UTIL_TYPE_U2BITSIZE    (16U)
#define UTIL_TYPE_U4BITSIZE    (32U)

#define UTIL_TYPE_U1SIGNBIT    (0x80U)
#define UTIL_TYPE_U2SIGNBIT    (0x8000U)
#define UTIL_TYPE_U4SIGNBIT    (0x80000000U)

#define UTIL_TYPE_S1MIN          (-128)
#define UTIL_TYPE_S1MAX          (127)

#define UTIL_TYPE_S2MIN          (-32768)
#define UTIL_TYPE_S2MAX          (32767)

/* S4_MIN: "-1" is a measure for the QAC-tool's bug that warn -2147483648L at 101-situations */
#define UTIL_TYPE_S4MIN          ((-2147483647 - 1))
#define UTIL_TYPE_S4MAX          (2147483647)

#define UTIL_TYPE_U1MIN          (0U)
#define UTIL_TYPE_U1MAX          (255U)

#define UTIL_TYPE_U2MIN          (0U)
#define UTIL_TYPE_U2MAX          (65535U)

#define UTIL_TYPE_U4MIN          (0U)
#define UTIL_TYPE_U4MAX          (4294967295U)

#endif  /* UTIL_TYPE_H */
