/*****************************************************************************
 *	Copyright DENSO Corporation. All rights reserved.
 ****************************************************************************/
/*****************************************************************************
 * @file	UTIL_Arithmacro.h
 * @brief	Basic Arithmetic Operations
 * @note	None
 ****************************************************************************/
#ifndef UTIL_ARITHMACRO_H
#define UTIL_ARITHMACRO_H

#include "UTIL_TYPE.h"

/*----------------------------------------------------------------------------
 *		Macros
 *--------------------------------------------------------------------------*/
/**---------------------------------------------------------------------------
 * @brief	absolute value of subtraction (|minuend-subtrahend|)
 * @param	u4_Minuend		:	minuend
 * @param	u4_Subtrahend	:	subtrahend
 * @return	result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
static inline uint32 UTIL_SubAbs_U4(const uint32 u4_Minuend, const uint32 u4_Subtrahend) __attribute__((always_inline, unused));
static inline uint32 UTIL_SubAbs_U4(const uint32 u4_Minuend, const uint32 u4_Subtrahend)
{
	uint32 retval = 0UL;
	if (u4_Minuend >= u4_Subtrahend) {
		retval = u4_Minuend - u4_Subtrahend;
	} else {
		retval = u4_Subtrahend - u4_Minuend;
	}
	return retval;
}

/**---------------------------------------------------------------------------
 * @brief	addition with upper guard (augend+addend lower than upperLimit)
 * @param	u4_UpperLimit	:	max value
 * @param	u4_Augend		:	augend
 * @param	u4_Addend		:	addend
 * @return	result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
static inline uint32 UTIL_AddClip_U4(const uint32 u4_UpperLimit, const uint32 u4_Augend, const uint32 u4_Addend) __attribute__((always_inline, unused));
static inline uint32 UTIL_AddClip_U4(const uint32 u4_UpperLimit, const uint32 u4_Augend, const uint32 u4_Addend)
{
	uint32 retval = 0UL;
	if ((((uint32)UTIL_TYPE_U4MAX - u4_Augend) >= u4_Addend)
		&& (u4_UpperLimit > (u4_Augend + u4_Addend))) {
		retval = u4_Augend + u4_Addend;
	} else {
		retval = u4_UpperLimit;
	}
	return retval;
}

/**---------------------------------------------------------------------------
 * @brief	subtraction with lower guard
 *			(minuend-subtrahend upper than lowerLimit)
 * @param	u4_LowerLimit	:	min value
 * @param	u4_Minuend		:	minuend
 * @param	u4_Subtrahend	:	subtrahend
 * @return	result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
static inline uint32 UTIL_SubClip_U4(const uint32 u4_LowerLimit, const uint32 u4_Minuend, const uint32 u4_Subtrahend) __attribute__((always_inline, unused));
static inline uint32 UTIL_SubClip_U4(const uint32 u4_LowerLimit, const uint32 u4_Minuend, const uint32 u4_Subtrahend)
{
	uint32 retval = 0UL;
	if ((u4_Minuend >= u4_Subtrahend) && (u4_LowerLimit < (u4_Minuend - u4_Subtrahend))) {
		retval = u4_Minuend - u4_Subtrahend;
	} else {
		retval = u4_LowerLimit;
	}
	return retval;
}

/**---------------------------------------------------------------------------
 * @brief	addition with upper guard (augend+addend lower than upperLimit)
 * @param	u4_UpperLimit	:	max value
 * @param	u4_LowerLimit	:   min value
 * @param	u4_Augend		:	augend
 * @param	u4_Addend		:	addend
 * @return	result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
static inline sint32 UTIL_AddClip_S4(const sint32 s4_UpperLimit, const sint32 s4_LowerLimit, const sint32 s4_Augend, const sint32 s4_Addend) __attribute__((always_inline, unused));
static inline sint32 UTIL_AddClip_S4(const sint32 s4_UpperLimit, const sint32 s4_LowerLimit, const sint32 s4_Augend, const sint32 s4_Addend)
{
	sint32 retval = 0L;
	if ((s4_Augend >= 0L) && (s4_Addend >= 0L) && ((s4_UpperLimit - s4_Augend) < s4_Addend)) {
		retval = s4_UpperLimit;
	} else {
		if ((s4_Augend < 0L) && (s4_Addend < 0L) && ((s4_LowerLimit - s4_Augend) > s4_Addend)) {
			retval = s4_LowerLimit;
		} else {
			retval = s4_Augend + s4_Addend;
		}
	}
	return retval;
}

/**---------------------------------------------------------------------------
 * @brief	subtraction with lower guard
 *			(minuend-subtrahend upper than lowerLimit)
 * @param	u4_UpperLimit	:	max value
 * @param	u4_LowerLimit	:	min value
 * @param	u4_Minuend		:	minuend
 * @param	u4_Subtrahend	:	subtrahend
 * @return	result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
static inline sint32 UTIL_SubClip_S4(const sint32 s4_UpperLimit, const sint32 s4_LowerLimit, const sint32 s4_Minuend, const sint32 s4_Subtrahend) __attribute__((always_inline, unused));
static inline sint32 UTIL_SubClip_S4(const sint32 s4_UpperLimit, const sint32 s4_LowerLimit, const sint32 s4_Minuend, const sint32 s4_Subtrahend)
{
	sint32 retval = 0L;
	if ((s4_Minuend >= 0L) && (s4_Subtrahend < 0L) && ((s4_UpperLimit + s4_Subtrahend) <= s4_Minuend)) {
		retval = s4_UpperLimit;
	} else {
		if ((s4_Minuend < 0L) && (s4_Subtrahend >= 0L) && ((s4_LowerLimit + s4_Subtrahend) >= s4_Minuend)) {
			retval = s4_LowerLimit;
		} else {
			retval = s4_Minuend - s4_Subtrahend;
		}
	}
	return retval;
}

#endif	/* UTIL_ARITHMACRO_H */
