/*****************************************************************************
 *	Copyright DENSO Corporation. All rights reserved.
 ****************************************************************************/
/*************************************************************************//**
 * @file		UTIL_Arithmacro.c
 * @brief		Basic Arithmacro Operation
 * @attention	None
 * @note		None
 ****************************************************************************/

/*----------------------------------------------------------------------------
 *		Headers
 *--------------------------------------------------------------------------*/
#include "Std_Types.h"

#include "UTIL_Arithmacro.h"
#include "UTIL_SLIB.h"

/*----------------------------------------------------------------------------
 *		Macros
 *--------------------------------------------------------------------------*/
#define UTIL_SVAL_INC1 (1)
#define UTIL_UVAL_INC1 (1U)

/*----------------------------------------------------------------------------
 *		Codes
 *--------------------------------------------------------------------------*/
#define GW_UTIL_START_SEC_CODE
#include "GW_UTIL_Memmap.h"

/**---------------------------------------------------------------------------
 * @brief	increase with max guard
 * @param	s#_Data : value to increase (#:1,2,4)
 * @return	result of increase
 * @note	None
 *--------------------------------------------------------------------------*/
sint8 UTIL_IncS1(const sint8 s1_Data)
{
	return (sint8)UTIL_AddClip_S4((sint32)UTIL_TYPE_S1MAX, (sint32)UTIL_TYPE_S1MIN, (sint32)s1_Data, (sint32)UTIL_SVAL_INC1);
}

sint16 UTIL_IncS2(const sint16 s2_Data)
{
	return (sint16)UTIL_AddClip_S4((sint32)UTIL_TYPE_S2MAX, (sint32)UTIL_TYPE_S2MIN, (sint32)s2_Data, (sint32)UTIL_SVAL_INC1);
}

sint32 UTIL_IncS4(const sint32 s4_Data)
{
	return UTIL_AddClip_S4((sint32)UTIL_TYPE_S4MAX, (sint32)UTIL_TYPE_S4MIN, s4_Data, (sint32)UTIL_SVAL_INC1);
}

/**---------------------------------------------------------------------------
 * @brief	increase with max guard
 * @param	u#_Data : value to increase (#:1,2,4)
 * @return	result of increase
 * @note	None
 *--------------------------------------------------------------------------*/
uint8 UTIL_IncU1(const uint8 u1_Data)
{
	return (uint8)UTIL_AddClip_U4((uint32)UTIL_TYPE_U1MAX, (uint32)u1_Data, (uint32)UTIL_UVAL_INC1);
}

uint16 UTIL_IncU2(const uint16 u2_Data)
{
	return (uint16)UTIL_AddClip_U4((uint32)UTIL_TYPE_U2MAX, (uint32)u2_Data, (uint32)UTIL_UVAL_INC1);
}

uint32 UTIL_IncU4(const uint32 u4_Data)
{
	return UTIL_AddClip_U4((uint32)UTIL_TYPE_U4MAX, (uint32)u4_Data, (uint32)UTIL_UVAL_INC1);
}

/**---------------------------------------------------------------------------
 * @brief	decrease with min guard
 * @param	s#_Data : value to decrease (#:1,2,4)
 * @return	result of decrease
 * @note	None
 *--------------------------------------------------------------------------*/
sint8 UTIL_DecS1(const sint8 s1_Data)
{
	return (sint8)UTIL_SubClip_S4((sint32)UTIL_TYPE_S1MAX, (sint32)UTIL_TYPE_S1MIN, (sint32)s1_Data, (sint32)UTIL_SVAL_INC1);
}

sint16 UTIL_DecS2(const sint16 s2_Data)
{
	return (sint16)UTIL_SubClip_S4((sint32)UTIL_TYPE_S2MAX, (sint32)UTIL_TYPE_S2MIN, (sint32)s2_Data, (sint32)UTIL_SVAL_INC1);
}

sint32 UTIL_DecS4(const sint32 s4_Data)
{
	return UTIL_SubClip_S4((sint32)UTIL_TYPE_S4MAX, (sint32)UTIL_TYPE_S4MIN, s4_Data, (sint32)UTIL_SVAL_INC1);
}

/**---------------------------------------------------------------------------
 * @brief	decrease with min guard
 * @param	u#_Data : value to decrease (#:1,2,4)
 * @return	result of decrease
 * @note	None
 *--------------------------------------------------------------------------*/
uint8 UTIL_DecU1(const uint8 u1_Data)
{
	return (uint8)UTIL_SubClip_U4((uint32)UTIL_TYPE_U1MIN, (uint32)u1_Data, (uint32)UTIL_UVAL_INC1);
}

uint16 UTIL_DecU2(const uint16 u2_Data)
{
	return (uint16)UTIL_SubClip_U4((uint32)UTIL_TYPE_U2MIN, (uint32)u2_Data, (uint32)UTIL_UVAL_INC1);
}

uint32 UTIL_DecU4(const uint32 u4_Data)
{
	return UTIL_SubClip_U4((uint32)UTIL_TYPE_U4MIN, (uint32)u4_Data, (uint32)UTIL_UVAL_INC1);
}

/**---------------------------------------------------------------------------
 * @brief	addition with max guard (augend+addend)
 * @param	s#_Augend : augend (#:1,2,4)
 * @param	s#_Addend : addend (#:1,2,4)
 * @return	result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
sint8 UTIL_AddS1(const sint8 s1_Augend, const sint8 s1_Addend)
{
	return (sint8)UTIL_AddClip_S4((sint32)UTIL_TYPE_S1MAX, (sint32)UTIL_TYPE_S1MIN, (sint32)s1_Augend, (sint32)s1_Addend);
}

sint16 UTIL_AddS2(const sint16 s2_Augend, const sint16 s2_Addend)
{
	return (sint16)UTIL_AddClip_S4((sint32)UTIL_TYPE_S2MAX, (sint32)UTIL_TYPE_S2MIN, (sint32)s2_Augend, (sint32)s2_Addend);
}

sint32 UTIL_AddS4(const sint32 s4_Augend, const sint32 s4_Addend)
{
	return UTIL_AddClip_S4((sint32)UTIL_TYPE_S4MAX, (sint32)UTIL_TYPE_S4MIN, s4_Augend, s4_Addend);
}

/**---------------------------------------------------------------------------
 * @brief	addition with max guard (augend+addend)
 * @param	u#_Augend : augend (#:1,2,4)
 * @param	u#_Addend : addend (#:1,2,4)
 * @return	result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
uint8 UTIL_AddU1(const uint8 u1_Augend, const uint8 u1_Addend)
{
	return (uint8)UTIL_AddClip_U4((uint32)UTIL_TYPE_U1MAX, (uint32)u1_Augend, (uint32)u1_Addend);
}

uint16 UTIL_AddU2(const uint16 u2_Augend, const uint16 u2_Addend)
{
	return (uint16)UTIL_AddClip_U4((uint32)UTIL_TYPE_U2MAX, (uint32)u2_Augend, (uint32)u2_Addend);
}

uint32 UTIL_AddU4(const uint32 u4_Augend, const uint32 u4_Addend)
{
	return UTIL_AddClip_U4((uint32)UTIL_TYPE_U4MAX, u4_Augend, u4_Addend);
}

/**---------------------------------------------------------------------------
 * @brief	subtraction with min guard (minuend-subtrahend)
 * @param	s#_Minuend : minuend (#:1,2,4)
 * @param	s#_Subtrahend : subtrahend (#:1,2,4)
 * @return	result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
sint8 UTIL_SubS1(const sint8 s1_Minuend, const sint8 s1_Subtrahend)
{
	return (sint8)UTIL_SubClip_S4((sint32)UTIL_TYPE_S1MAX, (sint32)UTIL_TYPE_S1MIN, (sint32)s1_Minuend, (sint32)s1_Subtrahend);
}

sint16 UTIL_SubS2(const sint16 s2_Minuend, const sint16 s2_Subtrahend)
{
	return (sint16)UTIL_SubClip_S4((sint32)UTIL_TYPE_S2MAX, (sint32)UTIL_TYPE_S2MIN, (sint32)s2_Minuend, (sint32)s2_Subtrahend);
}

sint32 UTIL_SubS4(const sint32 s4_Minuend, const sint32 s4_Subtrahend)
{
	return UTIL_SubClip_S4((sint32)UTIL_TYPE_S4MAX, (sint32)UTIL_TYPE_S4MIN, (sint32)s4_Minuend, (sint32)s4_Subtrahend);
}

/**---------------------------------------------------------------------------
 * @brief	subtraction with min guard (minuend-subtrahend)
 * @param	u#_Minuend : minuend (#:1,2,4)
 * @param	u#_Subtrahend : subtrahend (#:1,2,4)
 * @return	result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
uint8 UTIL_SubU1(const uint8 u1_Minuend, const uint8 u1_Subtrahend)
{
	return (uint8)UTIL_SubClip_U4((uint32)UTIL_TYPE_U1MIN, (uint32)u1_Minuend, (uint32)u1_Subtrahend);
}

uint16 UTIL_SubU2(const uint16 u2_Minuend, const uint16 u2_Subtrahend)
{
	return (uint16)UTIL_SubClip_U4((uint32)UTIL_TYPE_U2MIN, (uint32)u2_Minuend, (uint32)u2_Subtrahend);
}

uint32 UTIL_SubU4(const uint32 u4_Minuend, const uint32 u4_Subtrahend)
{
	return UTIL_SubClip_U4((uint32)UTIL_TYPE_U4MIN, (uint32)u4_Minuend, (uint32)u4_Subtrahend);
}

/**---------------------------------------------------------------------------
 * @brief	absolute value of subtraction (|minuend-subtrahend|)
 * @param	u#_Minuend : minuend (#:1,2,4)
 * @param	u#_Subtrahend : subtrahend (#:1,2,4)
 * @return	result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
uint8 UTIL_SubAbsU1(const uint8 u1_Minuend, const uint8 u1_Subtrahend)
{
	return (uint8)UTIL_SubAbs_U4((uint32)u1_Minuend, (uint32)u1_Subtrahend);
}

uint16 UTIL_SubAbsU2(const uint16 u2_Minuend, const uint16 u2_Subtrahend)
{
	return (uint16)UTIL_SubAbs_U4((uint32)u2_Minuend, (uint32)u2_Subtrahend);
}

uint32 UTIL_SubAbsU4(const uint32 u4_Minuend, const uint32 u4_Subtrahend)
{
	return UTIL_SubAbs_U4(u4_Minuend, u4_Subtrahend);
}

/**---------------------------------------------------------------------------
 * @brief	addition with upper guard (augend+addend lower than upperLimit)
 * @param	u#_UpperLimit :max value (#:1,2,4)
 * @param	u#_Augend : augend (#:1,2,4)
 * @param	u#_Addend : addend (#:1,2,4)
 * @return	result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
uint8 UTIL_AddClipU1(const uint8 u1_UpperLimit, const uint8 u1_Augend, const uint8 u1_Addend)
{
	return (uint8)UTIL_AddClip_U4((uint32)u1_UpperLimit, (uint32)u1_Augend, (uint32)u1_Addend);
}

uint16 UTIL_AddClipU2(const uint16 u2_UpperLimit, const uint16 u2_Augend, const uint16 u2_Addend)
{
	return (uint16)UTIL_AddClip_U4((uint32)u2_UpperLimit, (uint32)u2_Augend, (uint32)u2_Addend);
}

uint32 UTIL_AddClipU4(const uint32 u4_UpperLimit, const uint32 u4_Augend, const uint32 u4_Addend)
{
	return UTIL_AddClip_U4(u4_UpperLimit, u4_Augend, u4_Addend);
}

/**---------------------------------------------------------------------------
 * @brief	subtraction with lower guard
 *			(minuend-subtrahend upper than lowerLimit)
 * @param	u#_LowerLimit	:	min value (#:1,2,4)
 * @param	u#_Minuend		:	minuend (#:1,2,4)
 * @param	u#_Subtrahend	:	subtrahend (#:1,2,4)
 * @return	result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
uint8 UTIL_SubClipU1(const uint8 u1_LowerLimit, const uint8 u1_Minuend, const uint8 u1_Subtrahend)
{
	return (uint8)UTIL_SubClip_U4((uint32)u1_LowerLimit, (uint32)u1_Minuend, (uint32)u1_Subtrahend);
}

uint16 UTIL_SubClipU2(const uint16 u2_LowerLimit, const uint16 u2_Minuend, const uint16 u2_Subtrahend)
{
	return (uint16)UTIL_SubClip_U4((uint32)u2_LowerLimit, (uint32)u2_Minuend, (uint32)u2_Subtrahend);
}

uint32 UTIL_SubClipU4(const uint32 u4_LowerLimit, const uint32 u4_Minuend, const uint32 u4_Subtrahend)
{
	return UTIL_SubClip_U4(u4_LowerLimit, u4_Minuend, u4_Subtrahend);
}

#define GW_UTIL_STOP_SEC_CODE
#include "GW_UTIL_Memmap.h"

