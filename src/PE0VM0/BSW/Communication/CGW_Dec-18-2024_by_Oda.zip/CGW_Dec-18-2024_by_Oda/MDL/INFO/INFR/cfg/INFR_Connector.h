/****************************************************************************/
/*            Copyright DENSO Corporation. All rights reserved.             */
/****************************************************************************/
/*************************************************************************//**
 * @file        INFR_Connector.h
 * @brief       INFR外のコンポーネントのI/Fとの接続を定義
 * @attention   なし
 * @note        なし
 ****************************************************************************/
#ifndef INFR_CONNECTOR_H
#define INFR_CONNECTOR_H

/*--------------------------------------------------------------------------*/
/*        ファイルインクルード                                              */
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"
//#include "IoHwAb_Gpt.h"

/*--------------------------------------------------------------------------*/
/*        関数定義                                                          */
/*--------------------------------------------------------------------------*/
/*************************************************************************//**
 * @brief      フリーランタイマカウンタを取得する
 * @return     フリーランタイマカウンタ値（単位：us、LSB：1us）
 * @attention  組付け先システム毎のフリーランタイマに適合すること
 *             単位、LSBをあわせること
 * @note       None
 ****************************************************************************/
static inline uint32 INFR_GetFreeRunTimerCount(void) __attribute__((always_inline));
static inline uint32 INFR_GetFreeRunTimerCount(void)
{
	
	//IoHwAb_Gpt_TimeValue TimeValue;
	Std_ReturnType Ret;
	//uint32 timer;
	uint32 timer = 0U;
#if 0	/* ビルド暫定処置 */
	Ret = IoHwAb_Gpt_GetFreeRunTimer( IOHWAB_GPT_LSB_1US, &TimeValue);
	
	if (Ret == E_OK) {
		timer = (uint32)TimeValue;
	} else {
		timer = 0U;
	}
#endif
	return timer;
}

#endif /*INFR_CONNECTOR_H*/
