/*****************************************************************************
 *	Copyright DENSO Corporation. All rights reserved.
 ****************************************************************************/
/*****************************************************************************
 * @file		UTIL_Mul_tiplication.h
 * @brief		Multiplication Operations
 * @attention	None
 * @note		None
 ****************************************************************************/
#ifndef	UTIL_MULTIPLICATION_H
#define	UTIL_MULTIPLICATION_H

/*----------------------------------------------------------------------------
 *		Macros
 *--------------------------------------------------------------------------*/
/**---------------------------------------------------------------------------
 * @brief	Multiplication (uint8*uint8)
 * @param	uint8	u1_Multiplicand	:	multiplicand
 * @param	uint8	u1_Multiplier	:	multiplier
 * @return	Result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
static inline uint16 UTIL_Mul_U1(const uint8 u1_Multiplicand, const uint8 u1_Multiplier) __attribute__((always_inline, unused));
static inline uint16 UTIL_Mul_U1(const uint8 u1_Multiplicand, const uint8 u1_Multiplier)
{
	return (uint16)((uint32)u1_Multiplicand * (uint32)u1_Multiplier);
}

/**---------------------------------------------------------------------------
 * @brief	Multiplication (uint16*uint16)
 * @param	uint16	u2_Multiplicand	:	multiplicand
 * @param	uint16	u2_Multiplier	:	multiplier
 * @return	Result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
static inline uint32 UTIL_Mul_U2(const uint16 u2_Multiplicand, const uint16 u2_Multiplier) __attribute__((always_inline, unused));
static inline uint32 UTIL_Mul_U2(const uint16 u2_Multiplicand, const uint16 u2_Multiplier)
{
	return ((uint32)u2_Multiplicand * (uint32)u2_Multiplier);
}

#endif	/* UTIL_MULTIPLICATION_H */
