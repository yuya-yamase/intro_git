/*****************************************************************************
 *	Copyright DENSO Corporation. All rights reserved.
 ****************************************************************************/
/*****************************************************************************
 * @file		UTIL_Division.c
 * @brief		Division Operation
 * @attention	Division Operations
 * @note		None
 ****************************************************************************/

/*----------------------------------------------------------------------------
 *		Headers
 *--------------------------------------------------------------------------*/
#include "Std_Types.h"

#include "UTIL_Division.h"
#include "UTIL_SLIB.h"

/*----------------------------------------------------------------------------
 *		Codes
 *--------------------------------------------------------------------------*/
#define GW_UTIL_START_SEC_CODE
#include "GW_UTIL_Memmap.h"

/**---------------------------------------------------------------------------
 * @brief	Division (uint8/uint8)
 * @param	uint8	u1_Dividend	:	dividend
 * @param	uint8	u1_Divisor	:	divisor
 * @param	uint8*	pt_Quotient	:	quotient
 * @param	uint8*	pt_Remaindr	:	remaindr
 * @return	None
 * @note	None
 *--------------------------------------------------------------------------*/
void UTIL_DivU1(const uint8 u1_Dividend, const uint8 u1_Divisor, uint8* const pt_Quotient, uint8* const pt_Remaindr)
{
	if ((uint32)u1_Divisor != 0UL) {
		*pt_Quotient = (uint8)((uint32)u1_Dividend / (uint32)u1_Divisor);
		*pt_Remaindr = (uint8)((uint32)u1_Dividend % (uint32)u1_Divisor);
	} else {
		*pt_Quotient = (uint8)0UL;
		*pt_Remaindr = (uint8)0UL;
	}
	return;
}

/**---------------------------------------------------------------------------
 * @brief	Division (uint16/uint16)
 * @param	uint16	u2_Dividend	:	dividend
 * @param	uint16	u2_Divisor	:	divisor
 * @param	uint16*	pt_Quotient	:	quotient
 * @param	uint16*	pt_Remaindr	:	remaindr
 * @return	None
 * @note	None
 *--------------------------------------------------------------------------*/
void UTIL_DivU2(const uint16 u2_Dividend, const uint16 u2_Divisor, uint16* const pt_Quotient, uint16* const pt_Remaindr)
{
	if ((uint32)u2_Divisor != 0UL) {
		*pt_Quotient = (uint16)((uint32)u2_Dividend / (uint32)u2_Divisor);
		*pt_Remaindr = (uint16)((uint32)u2_Dividend % (uint32)u2_Divisor);
	} else {
		*pt_Quotient = (uint16)0UL;
		*pt_Remaindr = (uint16)0UL;
	}
	return;
}

/**---------------------------------------------------------------------------
 * @brief	Division (uint32/uint32)
 * @param	uint32	u4_Dividend	:	dividend
 * @param	uint32	u4_Divisor	:	divisor
 * @param	uint32*	quotient	:	quotient
 * @param	uint32*	remaindr	:	remaindr
 * @return	None
 * @note	None
 *--------------------------------------------------------------------------*/
void UTIL_DivU4(const uint32 u4_Dividend, const uint32 u4_Divisor, uint32* const pt_Quotient, uint32* const pt_Remaindr)
{
	if (u4_Divisor != 0UL) {
		*pt_Quotient = u4_Dividend / u4_Divisor;
		*pt_Remaindr = u4_Dividend % u4_Divisor;
	} else {
		*pt_Quotient = 0UL;
		*pt_Remaindr = 0UL;
	}
	return;
}

#define GW_UTIL_STOP_SEC_CODE
#include "GW_UTIL_Memmap.h"

