/*****************************************************************************
 *	Copyright DENSO Corporation. All rights reserved.
 ****************************************************************************/
/*****************************************************************************
 * @file		UTIL_Shift.c
 * @brief		Shift Operations
 * @attention	None
 * @note		None
 ****************************************************************************/

/*----------------------------------------------------------------------------
 *		Headers
 *--------------------------------------------------------------------------*/
#include "Std_Types.h"

#include "UTIL_Shift.h"
#include "UTIL_SLIB.h"

/*----------------------------------------------------------------------------
 *		Codes
 *--------------------------------------------------------------------------*/
#define GW_UTIL_START_SEC_CODE
#include "GW_UTIL_Memmap.h"

/**---------------------------------------------------------------------------
 * @brief	Logical Left Shift (uint8)
 * @param	uint8	u1_Data		:	Shift Value
 * @param	uint8	u1_Shift	:	Bits for shift
 * @return	Result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
uint8 UTIL_ShiftLeftU1(const uint8 u1_Data, const uint8 u1_Shift)
{
	return UTIL_ShiftLeft_U1(u1_Data, u1_Shift);
}

/**---------------------------------------------------------------------------
 * @brief	Logical Left Shift (uint16)
 * @param	uint16	u2_Data		:	Shift Value
 * @param	uint8	u1_Shift	:	Bits for shift
 * @return	Result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
uint16 UTIL_ShiftLeftU2(const uint16 u2_Data, const uint8 u1_Shift)
{
	return UTIL_ShiftLeft_U2(u2_Data, u1_Shift);
}

/**---------------------------------------------------------------------------
 * @brief	Logical Left Shift (uint32)
 * @param	uint32	u4_Data		:	Shift Value
 * @param	uint8	u1_Shift	:	Bits for shift
 * @return	Result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
uint32 UTIL_ShiftLeftU4(const uint32 u4_Data, const uint8 u1_Shift)
{
	return UTIL_ShiftLeft_U4(u4_Data, u1_Shift);
}

/**---------------------------------------------------------------------------
 * @brief	Logical Right Shift (uint8)
 * @param	uint8	u1_Data		:	Shift Value
 * @param	uint8	u1_Shift	:	Bits for shift
 * @return	Result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
uint8 UTIL_ShiftRightU1(const uint8 u1_Data, const uint8 u1_Shift)
{
	return UTIL_ShiftRight_U1(u1_Data, u1_Shift);
}

/**---------------------------------------------------------------------------
 * @brief	Logical Right Shift (uint16)
 * @param	uint16	u2_Data		:	Shift Value
 * @param	uint8	u1_Shift	:	Bits for shift
 * @return	Result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
uint16 UTIL_ShiftRightU2(const uint16 u2_Data, const uint8 u1_Shift)
{
	return UTIL_ShiftRight_U2(u2_Data, u1_Shift);
}

/**---------------------------------------------------------------------------
 * @brief	Logical Right Shift (uint32)
 * @param	uint32	u4_Data		:	Shift Value
 * @param	uint8	u1_Shift	:	Bits for shift
 * @return	Result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
uint32 UTIL_ShiftRightU4(const uint32 u4_Data, const uint8 u1_Shift)
{
	return UTIL_ShiftRight_U4(u4_Data, u1_Shift);
}

#define GW_UTIL_STOP_SEC_CODE
#include "GW_UTIL_Memmap.h"

