/****************************************************************************/
/*	Copyright DENSO Corporation. All rights reserved.                       */
/****************************************************************************/
/*************************************************************************//**
 * @file	INFR_SysTimer.c
 * @brief	共通システムタイマ
 * @details	INFR_FreeRunTimer_getCountを使用しMainTaskの周期に影響されないタイマ<BR>
 *			5msLSB/1msLSBのタイマカウンタを提供する。
 * @note	なし
 * @date	v1.00	2016/02/26	T.Matsumoto(FSI)	新規作成
 * @date	v1.01	2016/04/13	I.Wan(FSI)		C73 SD-2 欠陥898778対応<BR>
 *													タイマカウンタの算出方法の見直し
 * @date	v1.01	2016/09/21	N.Shiraishi(FSI)	GC7 SD-B XSS差し替え対応<BR>
 *													TYPE_Legacy.hのインクルード
 * @date	v3.00	2017/03/05	N.Shiraishi(FSI)	400B 試作HILS初回集約対応
 * @date	v3.01	2018/08/01	N.Shiraishi(FSI)	課題No.1019602対応<BR>
 *													RAM(タイマカウンタ)の配置を変更
 ****************************************************************************/
#include "Std_Types.h"
#include "INFR_SS.h"
#include "INFR_SysTimer.h"

/*----内部定数定義----------------------------------------------------------*/
#define INFR_SYSTIMER_LSB	(5000U)		/**< FreeRunTimerの取得値からのLSB変換(us⇒5ms)用 */
#define INFR_SYSTIMER_LSB_1MS	(1000U)		/**< FreeRunTimerの取得値からのLSB変換(us⇒1ms)用 */

/*----外部変数宣言----------------------------------------------------------*/
#define GW_INFR_START_SEC_VAR_NO_INIT
#include "GW_INFR_Memmap.h"

/**	
 *	@var	u2g_INFR_SysTimer_Counter
 *	@brief	タイマカウンタ
 */
static uint16 u2g_INFR_SysTimer_Counter;

/**	
 *	@var	u4g_INFR_SysTimer_Counter
 *	@brief	タイマカウンタ
 */
static uint32 u4g_INFR_SysTimer_Counter;

/**	
 *	@var	u4g_INFR_SysTimer_FreeRunTimeOld_5ms
 *	@brief	前回のタイマカウンタ加算を行った時刻(5msタイマ用)
 */
static uint32 u4g_INFR_SysTimer_FreeRunTimeOld_5ms;

/**	
 *	@var	u2g_INFR_SysTimer_Counter_1ms
 *	@brief	タイマカウンタ(1msタイマ(2byte)用)
 */
static uint16 u2g_INFR_SysTimer_Counter_1ms;

/**	
 *	@var	u4g_INFR_SysTimer_Counter_1ms
 *	@brief	タイマカウンタ(1msタイマ(4byte)用)
 */
static uint32 u4g_INFR_SysTimer_Counter_1ms;

/**	
 *	@var	u4g_INFR_SysTimer_FreeRunTimeOld_1ms
 *	@brief	前回のタイマカウンタ加算を行った時刻(1msタイマ用)
 */
static uint32 u4g_INFR_SysTimer_FreeRunTimeOld_1ms;


#define GW_INFR_STOP_SEC_VAR_NO_INIT
#include "GW_INFR_Memmap.h"


#define GW_INFR_START_SEC_CODE
#include "GW_INFR_Memmap.h"

/*************************************************************************//**
 * @fn			void vdg_INFR_SysTimer_Init(void)
 * @brief		タイマカウンタ初期化
 * @details		タイマカウンタの初期化処理を行う。
 * @param[in]	なし
 * @return		なし
 * @attention	SCH_entryPreRunHook_0とSCH_reEntryPreRunHook_DeepS_0に組み付けること。
 ****************************************************************************/
void INFR_SysTimer_Init(void)
{
	uint32 u4t_FreeRunTime;
	/*初期化処理を実行時のフリーランタイマ値を基準として、タイマカウント値の更新を始める*/
	u4t_FreeRunTime = INFR_GetFreeRunTimerCount();
	
	u2g_INFR_SysTimer_Counter = (uint16)0U;
	u4g_INFR_SysTimer_Counter = (uint32)0U;
	u4g_INFR_SysTimer_FreeRunTimeOld_5ms = u4t_FreeRunTime;
	u2g_INFR_SysTimer_Counter_1ms = (uint16)0U;
	u4g_INFR_SysTimer_Counter_1ms = (uint32)0U;
	u4g_INFR_SysTimer_FreeRunTimeOld_1ms = u4t_FreeRunTime;
	
	return;
}

/*************************************************************************//**
 * @fn			void INFR_SysTimer_update(void)
 * @brief		タイマカウンタ更新
 * @details		INFR_FreeRunTimer_getCount()からの取得値を元にタイマカウンタを更新する。<BR>
 *				MainTaskの以下タイミングで呼び出されタイマ値を更新する。<BR>
 *					 作動準備（入力調停の最後）<BR>
 *					 通常作動（入力調停の最後）<BR>
 *					 ウェイクアップ準備（入力調停の最後） <BR>
 * @param[in]	なし
 * @return		なし
 * @attention	なし
 * @date		v1.00	2016/02/26	T.Matsumoto		新規作成
 * @date		v1.01	2016/04/13	I.Wan(FSI)		C73 SD-2 欠陥898778対応<BR>
 *													タイマカウンタの算出方法の見直し
 * @date		v3.00	2017/03/05	N.Shiraisi(FSI)	400B 試作HILS初回集約対応
 ****************************************************************************/
void INFR_SysTimer_Update(void)
{
	uint32        u4t_FreeRunTime;
	uint32        u4t_ElapsedTime;					/* 前回のタイマカウンタ加算時刻からの経過時間 */
	uint32        u4t_RemaindTime;					/* タイマカウンタに加算されない余り時間       */
	uint16        u2t_AddCount;						/* タイマカウンタ加算値(2byte)                */
	uint32        u4t_AddCount;						/* タイマカウンタ加算値(4byte)                */
	
	/* フリーランタイマーの値を取得 */
	u4t_FreeRunTime = INFR_GetFreeRunTimerCount();
	
	/* 下記の減算はラップアラウンドを発生させるが、意図的な処置。
	 * (減算が、引く値の2の補数を加算する計算と等価であることを前提にしている) */
	u4t_ElapsedTime = u4t_FreeRunTime - u4g_INFR_SysTimer_FreeRunTimeOld_5ms;

	u2t_AddCount    = (uint16)(u4t_ElapsedTime / (uint32)INFR_SYSTIMER_LSB);
	u4t_AddCount    = u4t_ElapsedTime / (uint32)INFR_SYSTIMER_LSB;
	u4t_RemaindTime = u4t_ElapsedTime % (uint32)INFR_SYSTIMER_LSB;
	
	/* タイマカウンタの更新(2byte/4byte) 
	 * 下記の加算はラップアラウンドを発生させるが、意図的な処置 */
	u2g_INFR_SysTimer_Counter = (uint16)((uint32)u2g_INFR_SysTimer_Counter + (uint32)u2t_AddCount);
	u4g_INFR_SysTimer_Counter += u4t_AddCount;
	
	/* 前回のタイマカウンタ加算時刻の更新 */
	/* 現在のフリーランタイマ値から余り時間分時刻を戻し加算時刻に設定。
	 * 下記の減算はラップアラウンドを発生させるが、意図的な処置。 */
	u4g_INFR_SysTimer_FreeRunTimeOld_5ms = u4t_FreeRunTime - u4t_RemaindTime;
	
	return;
} 

/*************************************************************************//**
 * @brief		タイマカウンタ更新(1msタイマ(2byte/4byte)用)
 * @details		XSS_FreeRunTimer_getCount()からの取得値を元にタイマカウンタを更新する。<BR>
 *				DriverTaskの先頭で呼び出されタイマ値を更新する。<BR>
 * @param[in]	なし
 * @return		なし
 * @attention	なし
 ****************************************************************************/
void INFR_SysTimer_Update_1ms(void)
{
	uint32        u4t_FreeRunTime;
	uint32        u4t_ElapsedTime;					/* 前回のタイマカウンタ加算時刻からの経過時間 */
	uint32        u4t_RemaindTime;					/* タイマカウンタに加算されない余り時間       */
	uint16        u2t_AddCount;						/* タイマカウンタ加算値(2byte)                */
	uint32        u4t_AddCount;						/* タイマカウンタ加算値(4byte)                */
	
	/* フリーランタイマーの値を取得 */
	u4t_FreeRunTime = INFR_GetFreeRunTimerCount();
	
	/* 下記の減算はラップアラウンドを発生させるが、意図的な処置。
	 * (減算が、引く値の2の補数を加算する計算と等価であることを前提にしている) */
	u4t_ElapsedTime = u4t_FreeRunTime - u4g_INFR_SysTimer_FreeRunTimeOld_1ms;
	
	u2t_AddCount    = (uint16)(u4t_ElapsedTime / (uint32)INFR_SYSTIMER_LSB_1MS);
	u4t_AddCount    = u4t_ElapsedTime / (uint32)INFR_SYSTIMER_LSB_1MS;
	u4t_RemaindTime = u4t_ElapsedTime % (uint32)INFR_SYSTIMER_LSB_1MS;
	
	/* タイマカウンタの更新(2byte/4byte) 
	 * 下記の加算はラップアラウンドを発生させるが、意図的な処置 */
	u2g_INFR_SysTimer_Counter_1ms = (uint16)((uint32)u2g_INFR_SysTimer_Counter_1ms + (uint32)u2t_AddCount);
	u4g_INFR_SysTimer_Counter_1ms += u4t_AddCount;
	
	/* 前回のタイマカウンタ加算時刻の更新 */
	/* 現在のフリーランタイマ値から余り時間分時刻を戻し加算時刻に設定。
	 * 下記の減算はラップアラウンドを発生させるが、意図的な処置。 */
	u4g_INFR_SysTimer_FreeRunTimeOld_1ms = u4t_FreeRunTime - u4t_RemaindTime;
	
	return;
}

/*************************************************************************//**
 * @fn			uint16 INFR_SysTimer_GetCount16()
 * @brief		タイマカウンタを取得
 * @details		タイマカウンタを取得する<BR>
 *               ・タイマカウンタは5msLSBで保持。<BR>
 *               ・タイマカウンタは5ms毎にMainTaskの以下で更新される。<BR>
 *					 作動準備（入力調停の最後）<BR>
 *					 通常作動（入力調停の最後）<BR>
 *					 ウェイクアップ準備（入力調停の最後）<BR>
 *				 ・更新時にXSS_getFreeRunTimerCountの値を使用して更新している。<BR>
 *				 ・本APIは初回取得～以降取得時の経過時間を算出する用途を前提としている<BR>
 *				 ・本APIを用いてスリープ前後の時間差分を計測することはできない<BR>
 * 				   (スリープ前～スリープ後で取得したタイマの時間差分は正しいものとならない)<BR>
 *				 ・ウェイクアップ/リセット起動～入力調停の間に時間取得した場合は、<BR>
 * 				   ウェイクアップ/リセット起動時のタイマ値が取得される<BR>
 * param[in]	なし
 * @return		タイマカウンタ
 * @attention	なし
 ****************************************************************************/
uint16 INFR_SysTimer_GetCount16(void)
{
	return (u2g_INFR_SysTimer_Counter);
}

/*************************************************************************//**
 * @fn			uint32 INFR_SysTimer_GetCount32()
 * @brief		タイマカウンタを取得
 * @details		タイマカウンタを取得する<BR>
 *               ・タイマカウンタは5msLSBで保持。<BR>
 *               ・タイマカウンタは5ms毎にMainTaskの以下で更新される。<BR>
 *					 作動準備（入力調停の最後）<BR>
 *					 通常作動（入力調停の最後）<BR>
 *					 ウェイクアップ準備（入力調停の最後）<BR>
 *				 ・更新時にXSS_getFreeRunTimerCountの値を使用して更新している。<BR>
 *				 ・本APIは初回取得～以降取得時の経過時間を算出する用途を前提としている<BR>
 *				 ・本APIを用いてスリープ前後の時間差分を計測することはできない<BR>
 * 				   (スリープ前～スリープ後で取得したタイマの時間差分は正しいものとならない)<BR>
 *				 ・ウェイクアップ/リセット起動～入力調停の間に時間取得した場合は、<BR>
 * 				   ウェイクアップ/リセット起動時のタイマ値が取得される<BR>
 * param[in]	なし
 * @return		タイマカウンタ
 * @attention	なし
 ****************************************************************************/
uint32 INFR_SysTimer_GetCount32(void)
{
	return (u4g_INFR_SysTimer_Counter);
}

/*************************************************************************//**
 * @fn			uint16 INFR_SysTimer_GetCount16_1ms()
 * @brief		タイマカウンタを取得(1msタイマ(2byte)用)
 * @details		タイマカウンタを取得する<BR>
 *               ・タイマカウンタは1msLSBで保持。<BR>
 *               ・タイマカウンタは1ms毎にDriverTaskの先頭で更新される。<BR>
 *				 ・更新時にXSS_getFreeRunTimerCountの値を使用して更新している。<BR>
 *				 ・本APIは初回取得～以降取得時の経過時間を算出する用途を前提としている<BR>
 *				 ・本APIを用いてスリープ前後の時間差分を計測することはできない<BR>
 * 				   (スリープ前～スリープ後で取得したタイマの時間差分は正しいものとならない)<BR>
 *				 ・ウェイクアップ/リセット起動～DriverTask初回起動の間に時間取得した場合は、<BR>
 * 				   ウェイクアップ/リセット起動時のタイマ値が取得される<BR>
 * param[in]	なし
 * @return		タイマカウンタ
 * @attention	なし
 ****************************************************************************/
uint16 INFR_SysTimer_GetCount16_1ms(void)
{
	return (u2g_INFR_SysTimer_Counter_1ms);
}

/*************************************************************************//**
 * @fn			uint32 INFR_SysTimer_GetCount32_1ms()
 * @brief		タイマカウンタを取得(1msタイマ(4byte)用)
 * @details		タイマカウンタを取得する<BR>
 *               ・タイマカウンタは1msLSBで保持。<BR>
 *               ・タイマカウンタは1ms毎にDriverTaskの先頭で更新される。<BR>
 *				 ・更新時にXSS_getFreeRunTimerCountの値を使用して更新している。<BR>
 *				 ・本APIは初回取得～以降取得時の経過時間を算出する用途を前提としている<BR>
 *				 ・本APIを用いてスリープ前後の時間差分を計測することはできない<BR>
 * 				   (スリープ前～スリープ後で取得したタイマの時間差分は正しいものとならない)<BR>
 *				 ・ウェイクアップ/リセット起動～DriverTask初回起動の間に時間取得した場合は、<BR>
 * 				   ウェイクアップ/リセット起動時のタイマ値が取得される<BR>
 * param[in]	なし
 * @return		タイマカウンタ
 * @attention	なし
 ****************************************************************************/
uint32 INFR_SysTimer_GetCount32_1ms(void)
{
	return (u4g_INFR_SysTimer_Counter_1ms);
}

#ifdef _DEBUG
uint16 INFR_SysTimer_SetCount16(uint16 value)
{
	u2g_INFR_SysTimer_Counter = value;
	return (u2g_INFR_SysTimer_Counter);
}

uint32 INFR_SysTimer_SetCount32(uint32 value)
{
	u4g_INFR_SysTimer_Counter = value;
	return (u4g_INFR_SysTimer_Counter);
}

uint16 INFR_SysTimer_SetCount16_1ms(uint16 value)
{
	u2g_INFR_SysTimer_Counter_1ms = value;
	return (u2g_INFR_SysTimer_Counter_1ms);
}

uint32 INFR_SysTimer_SetCount32_1ms(uint32 value)
{
	u4g_INFR_SysTimer_Counter_1ms = value;
	return (u4g_INFR_SysTimer_Counter_1ms);
}

#endif /* _DEBUG */

#define GW_INFR_STOP_SEC_CODE
#include "GW_INFR_Memmap.h"

