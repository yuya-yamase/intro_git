/*****************************************************************************
 *	Copyright DENSO Corporation. All rights reserved.
 ****************************************************************************/
/*****************************************************************************
 * @file		UTIL_Multiplication.c
 * @breif		Multiplication Operation
 * @attention	None
 * @note		None
 ****************************************************************************/

/*----------------------------------------------------------------------------
 *		Headers
 *--------------------------------------------------------------------------*/
#include "Std_Types.h"

#include "UTIL_Multiplication.h"
#include "UTIL_SLIB.h"

/*----------------------------------------------------------------------------
 *		Codes
 *--------------------------------------------------------------------------*/
#define GW_UTIL_START_SEC_CODE
#include "GW_UTIL_Memmap.h"

/**---------------------------------------------------------------------------
 * @brief	Multiplication (uint8*uint8)
 * @param	uint8	u1_Multiplicand	:	multiplicand
 * @param	uint8	u1_Multiplier	:	multiplier
 * @return	Result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
uint16 UTIL_MulU1(const uint8 u1_Multiplicand, const uint8 u1_Multiplier)
{
	return UTIL_Mul_U1(u1_Multiplicand, u1_Multiplier);
}

/**---------------------------------------------------------------------------
 * @brief	Multiplication (uint16*uint16)
 * @param	uint16	u2_Multiplicand	:	multiplicand
 * @param	uint16	u2_Multiplier	:	multiplier
 * @return	Result of operation
 * @note	None
 *--------------------------------------------------------------------------*/
uint32 UTIL_MulU2(const uint16 u2_Multiplicand, const uint16 u2_Multiplier)
{
	return UTIL_Mul_U2(u2_Multiplicand, u2_Multiplier);
}

#define GW_UTIL_STOP_SEC_CODE
#include "GW_UTIL_Memmap.h"

