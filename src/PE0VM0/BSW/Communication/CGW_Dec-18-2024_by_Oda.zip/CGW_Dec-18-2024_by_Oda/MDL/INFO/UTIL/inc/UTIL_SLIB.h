/*****************************************************************************
 *	Copyright DENSO Corporation. All rights reserved.
 ****************************************************************************/
/*****************************************************************************
 * [File Name]		UTIL_SLIB.h
 * [Module]			SLIB header
 * [Function]		include SLIB headers
 * [Notes]			None
 ****************************************************************************/
#ifndef	UTIL_SLIB_H
#define	UTIL_SLIB_H

/*----------------------------------------------------------------------------
 *		Headers
 *--------------------------------------------------------------------------*/
#include "Std_Types.h"

/*----------------------------------------------------------------------------
 *		Prototypes
 *--------------------------------------------------------------------------*/
#define GW_UTIL_START_SEC_CODE
#include "GW_UTIL_Memmap.h"

sint8 UTIL_IncS1(const sint8 s1_Data);
sint16 UTIL_IncS2(const sint16 s2_Data);
sint32 UTIL_IncS4(const sint32 s4_Data);
uint8 UTIL_IncU1(const uint8 u1_Data);
uint16 UTIL_IncU2(const uint16 u2_Data);
uint32 UTIL_IncU4(const uint32 u4_Data);
sint8 UTIL_DecS1(const sint8 s1_Data);
sint16 UTIL_DecS2(const sint16 s2_Data);
sint32 UTIL_DecS4(const sint32 s4_Data);
uint8 UTIL_DecU1(const uint8 u1_Data);
uint16 UTIL_DecU2(const uint16 u2_Data);
uint32 UTIL_DecU4(const uint32 u4_Data);
sint8 UTIL_AddS1(const sint8 s1_Augend, const sint8 s1_Addend);
sint16 UTIL_AddS2(const sint16 s2_Augend, const sint16 s2_Addend);
sint32 UTIL_AddS4(const sint32 s4_Augend, const sint32 s4_Addend);
uint8 UTIL_AddU1(const uint8 u1_Augend, const uint8 u1_Addend);
uint16 UTIL_AddU2(const uint16 u2_Augend, const uint16 u2_Addend);
uint32 UTIL_AddU4(const uint32 u4_Augend, const uint32 u4_Addend);
sint8 UTIL_SubS1(const sint8 s1_Minuend, const sint8 s1_Subtrahend);
sint16 UTIL_SubS2(const sint16 s2_Minuend, const sint16 s2_Subtrahend);
sint32 UTIL_SubS4(const sint32 s4_Minuend, const sint32 s4_Subtrahend);
uint8 UTIL_SubU1(const uint8 u1_Minuend, const uint8 u1_Subtrahend);
uint16 UTIL_SubU2(const uint16 u2_Minuend, const uint16 u2_Subtrahend);
uint32 UTIL_SubU4(const uint32 u4_Minuend, const uint32 u4_Subtrahend);
uint8 UTIL_SubAbsU1(const uint8 u1_Minuend, const uint8 u1_Subtrahend);
uint16 UTIL_SubAbsU2(const uint16 u2_Minuend, const uint16 u2_Subtrahend);
uint32 UTIL_SubAbsU4(const uint32 u4_Minuend, const uint32 u4_Subtrahend);
uint8 UTIL_AddClipU1(const uint8 u1_UpperLimit, const uint8 u1_Augend, const uint8 u1_Addend);
uint16 UTIL_AddClipU2(const uint16 u2_UpperLimit, const uint16 u2_Augend, const uint16 u2_Addend);
uint32 UTIL_AddClipU4(const uint32 u4_UpperLimit, const uint32 u4_Augend, const uint32 u4_Addend);
uint8 UTIL_SubClipU1(const uint8 u1_LowerLimit, const uint8 u1_Minuend, const uint8 u1_Subtrahend);
uint16 UTIL_SubClipU2(const uint16 u2_LowerLimit, const uint16 u2_Minuend, const uint16 u2_Subtrahend);
uint32 UTIL_SubClipU4(const uint32 u4_LowerLimit, const uint32 u4_Minuend, const uint32 u4_Subtrahend);
void UTIL_DivU1(const uint8 u1_Dividend, const uint8 u1_Divisor, uint8* const pt_Quotient, uint8* const pt_Remaindr);
void UTIL_DivU2(const uint16 u2_Dividend, const uint16 u2_Divisor, uint16* const pt_Quotient, uint16* const pt_Remaindr);
void UTIL_DivU4(const uint32 u4_Dividend, const uint32 u4_Divisor, uint32* const pt_Quotient, uint32* const pt_Remaindr);
uint16 UTIL_MulU1(const uint8 u1_Multiplicand, const uint8 u1_Multiplier);
uint32 UTIL_MulU2(const uint16 u2_Multiplicand, const uint16 u2_Multiplier);
uint8 UTIL_ShiftLeftU1(const uint8 u1_Data, const uint8 u1_Shift);
uint16 UTIL_ShiftLeftU2(const uint16 u2_Data, const uint8 u1_Shift);
uint32 UTIL_ShiftLeftU4(const uint32 u4_Data, const uint8 u1_Shift);
uint8 UTIL_ShiftRightU1(const uint8 u1_Data, const uint8 u1_Shift);
uint16 UTIL_ShiftRightU2(const uint16 u2_Data, const uint8 u1_Shift);
uint32 UTIL_ShiftRightU4(const uint32 u4_Data, const uint8 u1_Shift);
static inline void	 UTIL_Memcpy(void *const dstPtr, const void *const srcPtr, const uint16 size) __attribute__((always_inline));
static inline void	 UTIL_Memset(void *const dstPtr, const uint8 data, const uint16 size) __attribute__((always_inline));
static inline sint16 UTIL_Memcmp(const void *const dataPtr1, const void *const dataPtr2, const uint16 size) __attribute__((always_inline));

/**
 * @brief		メモリコピー関数（インライン）
 * @param[out]	dstPtr[]	コピー先領域の先頭アドレス
 * @param[in]	srcPtr[]	コピー元領域の先頭アドレス
 * @param[in]	size	コピーするサイズ(1～65535の範囲で指定可能)
 * @return		なし
 * @attention	コピー元とコピー先の領域が被らないケースのみ保証<BR>
 *				コピー元、コピー先共に確保された領域を指定すること<BR>
 * 				（領域外アクセスの管理はAPI使用側の責務）
 **/
static inline void UTIL_Memcpy(void* const dstPtr, const void* const srcPtr, const uint16 size)
{
	uint8 *const	   pDst = (uint8 *)dstPtr;
	const uint8 *const pSrc = (const uint8 *)srcPtr;
	uint32 index;

	for (index = 0UL; index < (uint32)size; index++) {
		pDst[index] = pSrc[index];
	}
	return;
}

/**
 * @brief		メモリセット関数（インライン）
 * @param[out]	dstPtr[]	セットする領域の先頭アドレス
 * @param[in]	data	セットするデータ(1byte)
 * @param[in]	size	セットするサイズ(1～65535の範囲で指定可能)
 * @return		なし
 * @attention	セットする領域には確保された領域を指定すること<BR>
 * 				（領域外アクセスの管理はAPI使用側の責務）
 **/
static inline void UTIL_Memset(void* const dstPtr, const uint8 data, const uint16 size)
{
	uint8 *const pDst = (uint8 *)dstPtr;
	uint32 index;

	for (index = 0UL; index < (uint32)size; index++) {
		pDst[index] = data;
	}
	return;
}

/**
 * @brief		メモリ比較関数（インライン）
 * @param[in]	dataPtr1	比較対象データ1
 * @param[in]	dataPtr2	比較対象データ2
 * @param[in]	size	比較バイト数(1～65535の範囲で指定可能)
 * @return		比較結果
 * @retval		負の値：不一致（比較対象データ1が小さい）
 * @retval		0：一致
 * @retval		正の値：不一致（比較対象データ1が大きい）
 * @attention	セットする領域には確保された領域を指定すること<BR>
 * 				（領域外アクセスの管理はAPI使用側の責務）
 **/
static inline sint16 UTIL_Memcmp(const void* const dataPtr1, const void* const dataPtr2, const uint16 size)
{
	const uint8 *const pData1 = (const uint8 *)dataPtr1;
	const uint8 *const pData2 = (const uint8 *)dataPtr2;
	uint32			   index  = 0UL;
	sint32			   result = 0L;
	
	for (index = 0UL; index < (uint32)size; index++) {
		result = (sint32)pData1[index] - (sint32)pData2[index];
		if (result != 0L) {
			break;
		}
	}
	return ((sint16)result);
}

#define GW_UTIL_STOP_SEC_CODE
#include "GW_UTIL_Memmap.h"

#endif	/* UTIL_SLIB_H */
