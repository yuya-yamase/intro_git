/****************************************************************************/
/*	Copyright DENSO Corporation. All rights reserved.                       */
/****************************************************************************/
/*************************************************************************//**
 * @file	INFR_SysTimer.h
 * @brief	共通システムタイマ
 * @details	XSS_FreeRunTimer_getCountを使用しMainTaskの周期に影響されないタイマ<BR>
 *			5msLSBのタイマカウンタを提供する。
 * @note	なし
 ****************************************************************************/
#ifndef INFR_SYSTIMER_H
#define INFR_SYSTIMER_H

/*--------------------------------------------------------------------------*/
/*        ファイルインクルード                                              */
/*--------------------------------------------------------------------------*/
#include "Std_Types.h"

/*--------------------------------------------------------------------------*/
/*        プロトタイプ宣言                                                  */
/*--------------------------------------------------------------------------*/
#define GW_INFR_START_SEC_CODE
#include "GW_INFR_Memmap.h"

void INFR_SysTimer_Update(void);
void INFR_SysTimer_Update_1ms(void);
void INFR_SysTimer_Init(void);
uint16 INFR_SysTimer_GetCount16(void);
uint32 INFR_SysTimer_GetCount32(void);
uint16 INFR_SysTimer_GetCount16_1ms(void);
uint32 INFR_SysTimer_GetCount32_1ms(void);
#ifdef _DEBUG
uint16 INFR_SysTimer_SetCount16(uint16 value);
uint32 INFR_SysTimer_SetCount32(uint32 value);
uint16 INFR_SysTimer_SetCount16_1ms(uint16 value);
uint32 INFR_SysTimer_SetCount32_1ms(uint32 value);

#endif /* _DEBUG */


#define GW_INFR_STOP_SEC_CODE
#include "GW_INFR_Memmap.h"

#endif /* INFR_SYSTIMER_H */
 
