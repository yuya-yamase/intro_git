gcc -O2 -g -o gpi2c_ma_test.exe                       \
              gpi2c_ma_test.c                         \
              GpI2C/config/gpi2c_ma_cfg.c             \
              GpI2C/scc/gpi2c_ma.c                    \
           -I.                                        \
           -I./EcuLib/Common/scc                      \
           -I./GpI2C/config                           \
           -I./GpI2C/scc

