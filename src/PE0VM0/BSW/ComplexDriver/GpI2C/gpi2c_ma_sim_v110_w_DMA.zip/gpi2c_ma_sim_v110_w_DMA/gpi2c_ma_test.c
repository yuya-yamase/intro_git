/* 1.1.0 */
/*===================================================================================================================================*/
/*  Copyright DENSO Corporation                                                                                                      */
/*===================================================================================================================================*/
/*  General Purpose I2C Communication / Master                                                                                       */
/*                                                                                                                                   */
/*===================================================================================================================================*/

/*-----------------------------------------------------------------------------------------------------------------------------------*/
/*  Version                                                                                                                          */
/*-----------------------------------------------------------------------------------------------------------------------------------*/
#define GP_I2C_MA_TEST_C_MAJOR                   (1)
#define GP_I2C_MA_TEST_C_MINOR                   (1)
#define GP_I2C_MA_TEST_C_PATCH                   (0)

/*-----------------------------------------------------------------------------------------------------------------------------------*/
/*  Include Files                                                                                                                    */
/*-----------------------------------------------------------------------------------------------------------------------------------*/
#include "gpi2c_ma_cfg_private.h"
#include "gpi2c_ma_test.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*-----------------------------------------------------------------------------------------------------------------------------------*/
/*  Version Check                                                                                                                    */
/*-----------------------------------------------------------------------------------------------------------------------------------*/
#if ((GP_I2C_MA_TEST_C_MAJOR != GP_I2C_MA_TEST_H_MAJOR) || \
     (GP_I2C_MA_TEST_C_MINOR != GP_I2C_MA_TEST_H_MINOR) || \
     (GP_I2C_MA_TEST_C_PATCH != GP_I2C_MA_TEST_H_PATCH))
#error "gpi2c_ma_test.c and gpi2c_ma_test.h : source and header files are inconsistent!"
#endif

#if ((GP_I2C_MA_TEST_C_MAJOR != GP_I2C_MA_CFG_H_MAJOR) || \
     (GP_I2C_MA_TEST_C_MINOR != GP_I2C_MA_CFG_H_MINOR) || \
     (GP_I2C_MA_TEST_C_PATCH != GP_I2C_MA_CFG_H_PATCH))
#error "gpi2c_ma_test.c and gpi2c_ma_cfg_private.h : source and header files are inconsistent!"
#endif

/*-----------------------------------------------------------------------------------------------------------------------------------*/
/*  Literal Definitions                                                                                                              */
/*-----------------------------------------------------------------------------------------------------------------------------------*/
#define GP_I2C_MA_TEST_IF_ACT                    (0x01U)
#define GP_I2C_MA_TEST_IF_RUN                    (0x02U)
#define GP_I2C_MA_TEST_IF_SEQ_EI                 (0x04U)
#define GP_I2C_MA_TEST_IF_REA_EI                 (0x08U)
#define GP_I2C_MA_TEST_IF_WRI_EI                 (0x10U)
#define GP_I2C_MA_TEST_IF_MAX                    (0x1fU)
#define GP_I2C_MA_TEST_IF_IRQ_DI                 (0x03U)

#define GP_I2C_MA_TEST_RWC_MAX                   (8U)
#define GP_I2C_MA_TEST_RWC_NWORD                 (4U)

#define GP_I2C_MA_TEST_FRT_10MS                  (100000U)
#define GP_I2C_MA_TEST_FRT_20US                  (200U)

/*-----------------------------------------------------------------------------------------------------------------------------------*/
/*  Macro Definitions                                                                                                                */
/*-----------------------------------------------------------------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------------------------------------------------------------*/
/*  Type Definitions                                                                                                                 */
/*-----------------------------------------------------------------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------------------------------------------------------------*/
/*  Variable Definitions                                                                                                             */
/*-----------------------------------------------------------------------------------------------------------------------------------*/
static U4         u4_sp_gpi2c_ma_test_trx[GP_I2C_MA_TEST_RWC_NWORD];
static U4         u4_sp_gpi2c_ma_test_req[GP_I2C_MA_TEST_RWC_NWORD];

static U4         u4_s_gpi2c_ma_test_irqbit;
static U4         u4_s_gpi2c_ma_test_frt;
static U4         u4_s_gpi2c_ma_test_main;

static U2         u2_s_gpi2c_ma_test_irq_err;

static U1         u1_s_gpi2c_ma_test_ifct;
static U1         u1_s_gpi2c_ma_test_rwcnt;
static U1         u1_s_gpi2c_ma_test_rea;

/*-----------------------------------------------------------------------------------------------------------------------------------*/
/*  Static Function Prototypes                                                                                                       */
/*-----------------------------------------------------------------------------------------------------------------------------------*/
static void    vd_s_GpI2cMaTestInit(void);

static void    vd_s_GpI2cMaTestMain_0(void);
static void    vd_s_GpI2cMaTestMain_1(void);
static void    vd_s_GpI2cMaTestMain_2(void);
static void    vd_s_GpI2cMaTestMain_3(void);
static void    vd_s_GpI2cMaTestMain_4(void);

static void    vd_s_GpI2cMaTestIRQErrInsert(void);

/*-----------------------------------------------------------------------------------------------------------------------------------*/
/*  Constant Definitions                                                                                                             */
/*-----------------------------------------------------------------------------------------------------------------------------------*/
static const U1 * const  u1p_sp_GP_I2C_MA_TEST_SEQ[] = {
    "STA", "WRI", "WEN", "REA", "RLA", "FIN", "REQ", "INA"
};

/*-----------------------------------------------------------------------------------------------------------------------------------*/
static const U4          u4_sp_GP_I2C_MA_TEST_WRI[] = {
    0x654321ca, 0xedcba987,  /*  0 : wri */
    0x032f01a0, 0x076f054f,  /*  2 : wri */
    0x7c6b5af2, 0xc0bfae8d   /*  4 : wri */
};

static const U4          u4_sp_GP_I2C_MA_TEST_REA[] = {
    0xa9cded51, 0x21436587,  /*  0 : rea */
    0xbbaa99cf, 0xffeeddcc,  /*  2 : rea */
    0xbadced55, 0x32547698   /*  4 : rea */
};

static const U4          u4_s_GP_I2C_TEST_MAIN = (U4)5U;

/*-----------------------------------------------------------------------------------------------------------------------------------*/
/*  Function Definitions                                                                                                             */
/*-----------------------------------------------------------------------------------------------------------------------------------*/
/*===================================================================================================================================*/
/*  int   main(unsigned int argc, char * argv[])                                                                                     */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
int   main(unsigned int argc, char * argv[])
{
    static const U4          u4_s_GP_I2C_TEST_FRT_MAX = (U4)50U * (U4)GP_I2C_MA_TEST_FRT_10MS;
    static void ( * const    fp_sp_GP_I2C_MA_TEST_MAIN[])(void) = {
        &vd_s_GpI2cMaTestMain_0,
        &vd_s_GpI2cMaTestMain_1,
        &vd_s_GpI2cMaTestMain_2,
        &vd_s_GpI2cMaTestMain_3,
        &vd_s_GpI2cMaTestMain_4
    };

    U4                       u4_t_frt;
    U4                       u4_t_main;

    vd_s_GpI2cMaTestInit();
    vd_g_GpI2cMaInit();

    u4_t_frt = (U4)0U;
    do{

        u4_s_gpi2c_ma_test_frt  = u4_t_frt;
        u4_t_frt               += (U4)GP_I2C_MA_TEST_FRT_10MS;

        vd_g_GpI2cMaMainTask();

        u4_t_main = u4_s_gpi2c_ma_test_main % u4_s_GP_I2C_TEST_MAIN;
        (*fp_sp_GP_I2C_MA_TEST_MAIN[u4_t_main])();
        if(u4_s_gpi2c_ma_test_main < (U4)U4_MAX){
            u4_s_gpi2c_ma_test_main++;
        }

        while((u1_s_gpi2c_ma_test_ifct > (U1)GP_I2C_MA_TEST_IF_SEQ_EI) &&
              (u4_s_gpi2c_ma_test_frt  < u4_t_frt                    )){

            if(argc >= 2){
                vd_s_GpI2cMaTestIRQErrInsert();
            }
            vd_g_GpI2cMaIRQTRx((U1)GP_I2C_MA_CH_0);

            u4_s_gpi2c_ma_test_frt += (U4)GP_I2C_MA_TEST_FRT_20US;
        }
    }
    while(u4_s_gpi2c_ma_test_frt < u4_s_GP_I2C_TEST_FRT_MAX);

    return 0;
}
/*===================================================================================================================================*/
/*  U2      u2_g_GpI2cMaIfFrt(void)                                                                                                  */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
U2      u2_g_GpI2cMaIfFrt(void)
{
    return(u2_GP_I2C_MA_FRT(u4_s_gpi2c_ma_test_frt));
}
/*===================================================================================================================================*/
/*  void    vd_g_GpI2cMaIfEnaCh(const ST_GP_I2C_MA_CH * st_ap_CH, const U1 u1_a_PIN_ACT)                                             */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
void    vd_g_GpI2cMaIfEnaCh(const ST_GP_I2C_MA_CH * st_ap_CH, const U1 u1_a_PIN_ACT)
{
    u1_s_gpi2c_ma_test_ifct = (U1)GP_I2C_MA_TEST_IF_ACT;
}
/*===================================================================================================================================*/
/*  void    vd_g_GpI2cMaIfDisCh(const ST_GP_I2C_MA_CH * st_ap_CH)                                                                    */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
void    vd_g_GpI2cMaIfDisCh(const ST_GP_I2C_MA_CH * st_ap_CH)
{
    u1_s_gpi2c_ma_test_ifct = (U1)0U;
}
/*===================================================================================================================================*/
/*  void    vd_g_GpI2cMaIfStaTRx(const ST_GP_I2C_MA_CH * st_ap_CH)                                                                   */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
void    vd_g_GpI2cMaIfStaTRx(const ST_GP_I2C_MA_CH * st_ap_CH)
{
    U4                       u4_t_lpcnt;

    u1_s_gpi2c_ma_test_ifct  |= (U1)GP_I2C_MA_TEST_IF_RUN;

    u1_s_gpi2c_ma_test_rwcnt  = (U1)0U;
    for(u4_t_lpcnt = (U4)0U; u4_t_lpcnt < (U4)GP_I2C_MA_TEST_RWC_NWORD; u4_t_lpcnt++){
        u4_sp_gpi2c_ma_test_trx[u4_t_lpcnt] = (U4)0U;
    }
}
/*===================================================================================================================================*/
/*  void    vd_g_GpI2cMaIfWriTx(const ST_GP_I2C_MA_CH * st_ap_CH, const U1 * u1_ap_BYTE_TX)                                          */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
void    vd_g_GpI2cMaIfWriTx(const ST_GP_I2C_MA_CH * st_ap_CH, const U1 * u1_ap_BYTE_TX)
{
    U1 *                     u1_tp_log_tx;

    u1_tp_log_tx = (U1 *)&u4_sp_gpi2c_ma_test_trx[0U];
    if(u1_s_gpi2c_ma_test_rwcnt >= (U1)U1_MAX){
        /* do nothing */
    }
    else if(u1_s_gpi2c_ma_test_rwcnt >= (U1)GP_I2C_MA_TEST_RWC_MAX){
        u1_s_gpi2c_ma_test_rwcnt++;
    }
    else if(st_gp_gpi2c_ma_ctrl[0].u2_seq == GP_I2C_MA_SEQ_REA){
        u1_tp_log_tx[u1_s_gpi2c_ma_test_rwcnt] = (*u1_ap_BYTE_TX);
    }
    else{
        u1_tp_log_tx[u1_s_gpi2c_ma_test_rwcnt] = (*u1_ap_BYTE_TX);
        u1_s_gpi2c_ma_test_rwcnt++;
    }

    vd_g_GpI2cMaTestSeqPrint("vd_g_GpI2cMaIRQTRx->vd_g_GpI2cMaIfWriTx");
    printf("-----------------------------------------------------------------------------------\n");
    printf("            u1_test_rwcnt  = %ld\n",       u1_s_gpi2c_ma_test_rwcnt  );
}
/*===================================================================================================================================*/
/*  void    vd_g_GpI2cMaIfReaRx(const ST_GP_I2C_MA_CH * st_ap_CH, U1 * u1_ap_byte_rx)                                                */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
void    vd_g_GpI2cMaIfReaRx(const ST_GP_I2C_MA_CH * st_ap_CH, U1 * u1_ap_byte_rx)
{
    const U1 *               u1_tp_PDU_RX;
    U1 *                     u1_tp_log_tx;

    U4                       u4_t_lpcnt;
    
    U1                       u1_t_rea;
    U1                       u1_t_rwc;
    U1                       u1_t_run;

    u1_tp_log_tx = (U1 *)&u4_sp_gpi2c_ma_test_trx[0];

    if(u1_s_gpi2c_ma_test_rwcnt >= (U1)U1_MAX){
        /* do nothing */
    }
    else if(u1_s_gpi2c_ma_test_rwcnt >= (U1)GP_I2C_MA_TEST_RWC_MAX){
        u1_s_gpi2c_ma_test_rwcnt++;
    }
    else if(u1_ap_byte_rx != vdp_PTR_NA){

        u1_t_rea = u1_s_gpi2c_ma_test_rea;
        if(u1_t_rea >= 2U){
            u1_t_rea = (U1)0U;
        }

        u1_t_rwc               = u1_s_gpi2c_ma_test_rwcnt;
        u1_tp_PDU_RX           = (U1 *)&u4_sp_GP_I2C_MA_TEST_REA[u1_t_rea << 1];
        (*u1_ap_byte_rx)       = u1_tp_PDU_RX[u1_t_rwc];

        u1_tp_log_tx[u1_t_rwc] = u1_tp_PDU_RX[u1_t_rwc];

        u1_s_gpi2c_ma_test_rwcnt++;
    }
    else{

        u1_s_gpi2c_ma_test_rwcnt++;
    }

    u1_t_run = u1_s_gpi2c_ma_test_ifct & (U1)GP_I2C_MA_TEST_IF_RUN;
    if(u1_t_run != (U1)0U){

        vd_g_GpI2cMaTestSeqPrint("vd_g_GpI2cMaIRQTRx->vd_g_GpI2cMaIfReaRx");
        printf("-----------------------------------------------------------------------------------\n");
        printf("            u1_test_rwcnt  = %ld\n",       u1_s_gpi2c_ma_test_rwcnt  );
    }
    else{

        vd_g_GpI2cMaTestSeqPrint("vd_g_GpI2cMaIRQTRx->vd_g_GpI2cMaIfFinTRx");
        printf("-----------------------------------------------------------------------------------\n");
        printf("            u1_test_rwcnt  = %ld\n",       u1_s_gpi2c_ma_test_rwcnt  );
        for(u4_t_lpcnt = (U4)0U; u4_t_lpcnt < (U4)GP_I2C_MA_TEST_RWC_MAX; u4_t_lpcnt++){
            printf("             u1p_log_tx[%ld] = 0x%02x\n",  u4_t_lpcnt, u1_tp_log_tx[u4_t_lpcnt]);
        }
    }
}
/*===================================================================================================================================*/
/*  void    vd_g_GpI2cMaIfFinTRx(const ST_GP_I2C_MA_CH * st_ap_CH)                                                                   */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
void    vd_g_GpI2cMaIfFinTRx(const ST_GP_I2C_MA_CH * st_ap_CH)
{
    u1_s_gpi2c_ma_test_ifct &= ((U1)U1_MAX ^ (U1)GP_I2C_MA_TEST_IF_RUN);
}
/*===================================================================================================================================*/
/*  void    vd_g_GpI2cMaIfIRQ_SeqEI(const ST_GP_I2C_MA_CH * st_ap_CH)                                                                */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
void    vd_g_GpI2cMaIfIRQ_SeqEI(const ST_GP_I2C_MA_CH * st_ap_CH)
{
    u1_s_gpi2c_ma_test_ifct = (u1_s_gpi2c_ma_test_ifct & (U1)GP_I2C_MA_TEST_IF_IRQ_DI) | (U1)GP_I2C_MA_TEST_IF_SEQ_EI;
}
/*===================================================================================================================================*/
/*  void    vd_g_GpI2cMaIfIRQ_ReaEI(const ST_GP_I2C_MA_CH * st_ap_CH)                                                                */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
void    vd_g_GpI2cMaIfIRQ_ReaEI(const ST_GP_I2C_MA_CH * st_ap_CH)
{
    u1_s_gpi2c_ma_test_ifct  = u1_s_gpi2c_ma_test_ifct & (U1)GP_I2C_MA_TEST_IF_IRQ_DI;
    u1_s_gpi2c_ma_test_ifct |= ((U1)GP_I2C_MA_TEST_IF_REA_EI | (U1)GP_I2C_MA_TEST_IF_SEQ_EI);
}
/*===================================================================================================================================*/
/*  void    vd_g_GpI2cMaIfIRQ_WriEI(const ST_GP_I2C_MA_CH * st_ap_CH)                                                                */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
void    vd_g_GpI2cMaIfIRQ_WriEI(const ST_GP_I2C_MA_CH * st_ap_CH)
{
    u1_s_gpi2c_ma_test_ifct  = u1_s_gpi2c_ma_test_ifct & (U1)GP_I2C_MA_TEST_IF_IRQ_DI;
    u1_s_gpi2c_ma_test_ifct |= ((U1)GP_I2C_MA_TEST_IF_WRI_EI | (U1)GP_I2C_MA_TEST_IF_SEQ_EI);
}
/*===================================================================================================================================*/
/*  void    vd_g_GpI2cMaIfIRQ_DI(const ST_GP_I2C_MA_CH * st_ap_CH)                                                                   */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
void    vd_g_GpI2cMaIfIRQ_DI(const ST_GP_I2C_MA_CH * st_ap_CH)
{
    u1_s_gpi2c_ma_test_ifct &= (U1)GP_I2C_MA_TEST_IF_IRQ_DI;
}
/*===================================================================================================================================*/
/*  U4      u4_g_GpI2cMaIfIRQst(const ST_GP_I2C_MA_CH * st_ap_CH, const U2 u2_a_SEQ)                                                 */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
U4      u4_g_GpI2cMaIfIRQst(const ST_GP_I2C_MA_CH * st_ap_CH, const U2 u2_a_SEQ)
{
    static const U4          u4_sp_GP_I2C_MA_IRQ_MASK[] = {
        (U4)0x00e0ef00U,        /* GP_I2C_MA_SEQ_STA (0U) */
        (U4)0x00e0ff00U,        /* GP_I2C_MA_SEQ_WRI (1U) */
        (U4)0x00e0ff00U,        /* GP_I2C_MA_SEQ_WEN (2U) */
        (U4)0x00e02f00U,        /* GP_I2C_MA_SEQ_REA (3U) */
        (U4)0x00e00800U         /* GP_I2C_MA_SEQ_FIN (4U) */
    };
    static const U4          u4_sp_GP_I2C_MA_IRQ_CRIT[] = {
        (U4)0x00e08400U,        /* GP_I2C_MA_SEQ_STA (0U) */
        (U4)0x00e08000U,        /* GP_I2C_MA_SEQ_WRI (1U) */
        (U4)0x00e0c000U,        /* GP_I2C_MA_SEQ_WEN (2U) */
        (U4)0x00c02000U,        /* GP_I2C_MA_SEQ_REA (3U) */
        (U4)0x00000800U         /* GP_I2C_MA_SEQ_FIN (4U) */
    };

    U4                       u4_t_irq;
    U4                       u4_t_eas;

    u4_t_eas = (U4)0U;
    if(u4_s_gpi2c_ma_test_irqbit != (U4)0U){

        u4_t_irq = u4_s_gpi2c_ma_test_irqbit & u4_sp_GP_I2C_MA_IRQ_MASK[u2_a_SEQ];
        if(u4_t_irq != u4_sp_GP_I2C_MA_IRQ_CRIT[u2_a_SEQ]){
            u4_t_eas = (U4)GP_I2C_MA_ERR_IRQ_UNK | (U4)GP_I2C_MA_EAS_SEQ_ABT;
        }
        u4_s_gpi2c_ma_test_irqbit = (U4)0U;
    }

    return(u4_t_eas);
}
/*===================================================================================================================================*/
#if (GP_I2C_MA_RWC_DMA_WRI >= 3U)
/*===================================================================================================================================*/
/*  void    vd_g_GpI2cMaIfDmaTxAct(const ST_GP_I2C_MA_CH * st_ap_CH, const U1 * u1p_a_PDU_TX, const U2 u2_a_NBYTE)                   */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
void    vd_g_GpI2cMaIfDmaTxAct(const ST_GP_I2C_MA_CH * st_ap_CH, const U1 * u1p_a_PDU_TX, const U2 u2_a_NBYTE)
{
}
#endif /* #if (GP_I2C_MA_RWC_DMA_WRI >= 3U) */
/*===================================================================================================================================*/
#if (GP_I2C_MA_RWC_DMA_REA >= 4U)
/*===================================================================================================================================*/
/*  void    vd_g_GpI2cMaIfDmaRxAct(const ST_GP_I2C_MA_CH * st_ap_CH, U1 * u1p_a_pdu_rx, const U2 u2_a_NBYTE)                         */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
void    vd_g_GpI2cMaIfDmaRxAct(const ST_GP_I2C_MA_CH * st_ap_CH, U1 * u1p_a_pdu_rx, const U2 u2_a_NBYTE)
{
}
/*===================================================================================================================================*/
/*  U4      u4_g_GpI2cMaIfDmaRxchk(const ST_GP_I2C_MA_CH * st_ap_CH)                                                                 */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
U4      u4_g_GpI2cMaIfDmaRxchk(const ST_GP_I2C_MA_CH * st_ap_CH)
{
    return((U4)0U);
}
#endif /* #if (GP_I2C_MA_RWC_DMA_REA >= 4U) */
/*===================================================================================================================================*/
#if ((GP_I2C_MA_RWC_DMA_WRI >= 3U) || (GP_I2C_MA_RWC_DMA_REA >= 4U))
/*===================================================================================================================================*/
/*  void    vd_g_GpI2cMaTestSeqPrint(const U1 * u1_ap_CHKPT)                                                                         */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
void    vd_g_GpI2cMaIfDmaDeAct(const ST_GP_I2C_MA_CH * st_ap_CH)
{
}
#endif /* #if ((GP_I2C_MA_RWC_DMA_WRI >= 3U) || (GP_I2C_MA_RWC_DMA_REA >= 4U)) */
/*===================================================================================================================================*/
/*  void    vd_g_GpI2cMaTestSeqPrint(const U1 * u1_ap_CHKPT)                                                                         */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
void    vd_g_GpI2cMaTestSeqPrint(const U1 * u1_ap_CHKPT)
{
    static const U1 * const  u1p_sp_GP_I2C_MA_TEST_IFCT[] = {
        "---/---/---/---/---",
        "---/---/---/---/ACT",
        "---/---/---/RUN/---",
        "---/---/---/RUN/ACT",

        "---/---/SEQ/---/---",
        "---/---/SEQ/---/ACT",
        "---/---/SEQ/RUN/---",
        "---/---/SEQ/RUN/ACT",

        "---/RXI/---/---/---",
        "---/RXI/---/---/ACT",
        "---/RXI/---/RUN/---",
        "---/RXI/---/RUN/ACT",

        "---/RXI/SEQ/---/---",
        "---/RXI/SEQ/---/ACT",
        "---/RXI/SEQ/RUN/---",
        "---/RXI/SEQ/RUN/ACT",

        "TXI/---/---/---/---",
        "TXI/---/---/---/ACT",
        "TXI/---/---/RUN/---",
        "TXI/---/---/RUN/ACT",

        "TXI/---/SEQ/---/---",
        "TXI/---/SEQ/---/ACT",
        "TXI/---/SEQ/RUN/---",
        "TXI/---/SEQ/RUN/ACT",

        "TXI/RXI/---/---/---",
        "TXI/RXI/---/---/ACT",
        "TXI/RXI/---/RUN/---",
        "TXI/RXI/---/RUN/ACT",

        "TXI/RXI/SEQ/---/---",
        "TXI/RXI/SEQ/---/ACT",
        "TXI/RXI/SEQ/RUN/---",
        "TXI/RXI/SEQ/RUN/ACT"
    };
    const U1 *               u1_tp_SEQ;
    const U1 *               u1_tp_IFCT;
    U4                       u4_t_lpcnt;
    U2                       u2_t_seq;
    U1                       u1_t_ifct;

    u2_t_seq = st_gp_gpi2c_ma_ctrl[0].u2_seq;
    if(u2_t_seq <= (U2)GP_I2C_MA_SEQ_REQ){
        u1_tp_SEQ = u1p_sp_GP_I2C_MA_TEST_SEQ[u2_t_seq];
    }
    else{
        u1_tp_SEQ = u1p_sp_GP_I2C_MA_TEST_SEQ[GP_I2C_MA_SEQ_REQ + 1];
    }

    u1_t_ifct  = u1_s_gpi2c_ma_test_ifct & (U1)GP_I2C_MA_TEST_IF_MAX;
    u1_tp_IFCT = u1p_sp_GP_I2C_MA_TEST_IFCT[u1_t_ifct];
    printf("-----------------------------------------------------------------------------------\n");
    printf("Check Point                : %s\n",                u1_ap_CHKPT                        );
    printf("-----------------------------------------------------------------------------------\n");
    printf("u4_s_gpi2c_ma_test_frt     = %ld(%ld)\n",     u4_s_gpi2c_ma_test_frt, u2_GP_I2C_MA_FRT(u4_s_gpi2c_ma_test_frt));
    printf("u1_s_gpi2c_ma_test_ifct    = %s(0x%02x)\n",   u1_tp_IFCT, u1_t_ifct                   );
    printf("-----------------------------------------------------------------------------------\n");
    printf("st_gp_GP_I2C_MA_CH.u2_nque = %ld\n",          st_gp_GP_I2C_MA_CH[0].u2_nque           );
    printf("-----------------------------------------------------------------------------------\n");
    printf("st_gp_gpi2c_ma_ctrl.u2_req = %ld\n",          st_gp_gpi2c_ma_ctrl[0].u2_req           );
    printf("                   .u2_run = %ld\n",          st_gp_gpi2c_ma_ctrl[0].u2_run           );
    printf("                   .u2_ack = %ld\n",          st_gp_gpi2c_ma_ctrl[0].u2_ack           );
    printf("                   .u2_frt = %ld\n",          st_gp_gpi2c_ma_ctrl[0].u2_frt           );
    printf("                   .u2_rwc = %ld\n",          st_gp_gpi2c_ma_ctrl[0].u2_rwc           );
    printf("                   .u2_seq = %s(0x%04x)\n",   u1_tp_SEQ, st_gp_gpi2c_ma_ctrl[0].u2_seq);
    printf("-----------------------------------------------------------------------------------\n");
    for(u4_t_lpcnt = (U4)0U; u4_t_lpcnt < (U4)GP_I2C_MA_NUM_SLA; u4_t_lpcnt++){
    printf("       u2_gp_rwc_by_sla[%ld] = %ld\n", u4_t_lpcnt, u2_gp_gpi2c_ma_rwc_by_sla[u4_t_lpcnt]     );
    printf("            .u2_rwc_max[%ld] = %ld\n", u4_t_lpcnt, st_gp_GP_I2C_MA_SLA[u4_t_lpcnt].u2_rwc_max);
    }
}
/*===================================================================================================================================*/
/*  void    vd_g_GpI2cMaTestTRxAck(const ST_GP_I2C_MA_REQ * st_ap_ACK)                                                               */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
void    vd_g_GpI2cMaTestTRxAck(const ST_GP_I2C_MA_REQ * st_ap_ACK)
{
    U1 *                     u1_tp_pdu;

    U4                       u4_t_lpcnt;
    U4                       u4_t_rwc;
    U4                       u4_t_sla;
    U4                       u4_t_pid;

    u1_tp_pdu = st_ap_ACK->u1p_pdu;
    u4_t_rwc  = st_ap_ACK->u4_cbf & (U4)GP_I2C_MA_CBF_BIT_RWC;
    u4_t_sla  = st_ap_ACK->u4_cbf >> (U4)GP_I2C_MA_CBF_LSB_SLA;
    u4_t_pid  = (st_ap_ACK->u4_cbf & (U4)GP_I2C_MA_CBF_BIT_PID) >> GP_I2C_MA_CBF_LSB_PID;

    vd_g_GpI2cMaTestSeqPrint("vd_g_GpI2cMaMainTask->vd_g_GpI2cMaTestTRxAck");

    printf("-----------------------------------------------------------------------------------\n");
    printf("     st_ap_ACK->u1p_pdu[0] = 0x%02x\n", u1_tp_pdu[0]                                  );

    for(u4_t_lpcnt = (U4)1U; u4_t_lpcnt < u4_t_rwc; u4_t_lpcnt++){
    printf("              ->u1p_pdu[%ld] = 0x%02x\n", u4_t_lpcnt, u1_tp_pdu[u4_t_lpcnt]           );
    }

    printf("              ->u4_cbf/rwc = %ld\n",     u4_t_rwc                                     );
    printf("              ->u4_cbf/err = 0x%08x\n",  st_ap_ACK->u4_cbf & (U4)GP_I2C_MA_CBF_BIT_ERR);
    printf("              ->u4_cbf/pid = %ld\n",     u4_t_pid                                     );
    printf("              ->u4_cbf/sla = %ld\n",     u4_t_sla                                     );
}
/*===================================================================================================================================*/
/*  static void    vd_s_GpI2cMaTestInit(void)                                                                                        */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
static void    vd_s_GpI2cMaTestInit(void)
{
    U4                       u4_t_lpcnt;

    for(u4_t_lpcnt = (U4)0U; u4_t_lpcnt < (U4)GP_I2C_MA_TEST_RWC_NWORD; u4_t_lpcnt++){
        u4_sp_gpi2c_ma_test_trx[u4_t_lpcnt] = (U4)0U;
        u4_sp_gpi2c_ma_test_req[u4_t_lpcnt] = (U4)0U;
    }
    u4_s_gpi2c_ma_test_irqbit  = (U4)0U;
    u4_s_gpi2c_ma_test_frt     = (U4)0U;

    u2_s_gpi2c_ma_test_irq_err = (U2)0U;

    u1_s_gpi2c_ma_test_ifct    = (U1)0U;
    u1_s_gpi2c_ma_test_rwcnt   = (U1)0U;

    u1_s_gpi2c_ma_test_rea     = (U1)0U;
    u4_s_gpi2c_ma_test_main    = (U2)0U;
}
/*===================================================================================================================================*/
/*  static void    vd_s_GpI2cMaTestMain_0(void)                                                                                      */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
static void    vd_s_GpI2cMaTestMain_0(void)
{
    ST_GP_I2C_MA_REQ         st_t_req;
    U4                       u4_t_sla;
    U4                       u4_t_lpcnt;
    U4                       u4_t_lpmax;
    U2                       u2_tp_rwc_rem[17];
    U1                       u1_tp_accpt[17];

    u4_t_sla         = (U4)GP_I2C_MA_SLA_0 << GP_I2C_MA_CBF_LSB_SLA;

    st_t_req.u1p_pdu = (U1 *)&u4_sp_GP_I2C_MA_TEST_WRI[0];
    st_t_req.u4_cbf  = u4_t_sla | (U4)2U;
    u2_tp_rwc_rem[0] = u2_g_GpI2cMaRwcRembySla((U1)GP_I2C_MA_SLA_0);
    u1_tp_accpt[0]   = u1_g_GpI2cMaReqTRx(&st_t_req);

    u4_t_sla         = ((U4)GP_I2C_MA_SLA_0 << GP_I2C_MA_CBF_LSB_SLA) | ((U4)5U << GP_I2C_MA_CBF_LSB_PID);

    st_t_req.u1p_pdu = (U1 *)&u4_sp_GP_I2C_MA_TEST_WRI[2];
    st_t_req.u4_cbf  = u4_t_sla | (U4)6U;
    u2_tp_rwc_rem[1] = u2_g_GpI2cMaRwcRembySla((U1)GP_I2C_MA_SLA_0);
    u1_tp_accpt[1]   = u1_g_GpI2cMaReqTRx(&st_t_req);

    u4_t_sla         = ((U4)GP_I2C_MA_SLA_0 << GP_I2C_MA_CBF_LSB_SLA) | ((U4)11U << GP_I2C_MA_CBF_LSB_PID);

    st_t_req.u1p_pdu = (U1 *)&u4_sp_GP_I2C_MA_TEST_WRI[4];
    st_t_req.u4_cbf  = u4_t_sla | (U4)4U;
    u2_tp_rwc_rem[2] = u2_g_GpI2cMaRwcRembySla((U1)GP_I2C_MA_SLA_0);
    u1_tp_accpt[2]   = u1_g_GpI2cMaReqTRx(&st_t_req);

    u4_t_lpmax       = (U4)3U;
    if(u4_s_gpi2c_ma_test_main == (U4)0U){

        st_t_req.u1p_pdu = (U1 *)&u4_sp_GP_I2C_MA_TEST_WRI[0];
        for(u4_t_lpcnt = (U4)3U; u4_t_lpcnt < (U4)17U; u4_t_lpcnt++){
            if(u4_t_lpcnt <= 8){
                st_t_req.u4_cbf           = u4_t_sla | u4_t_lpcnt;
            }
            u2_tp_rwc_rem[u4_t_lpcnt] = u2_g_GpI2cMaRwcRembySla((U1)GP_I2C_MA_SLA_0);
            u1_tp_accpt[u4_t_lpcnt]   = u1_g_GpI2cMaReqTRx(&st_t_req); 
        }
        u4_t_lpmax = u4_t_lpcnt;
    }
    vd_g_GpI2cMaTestSeqPrint("vd_s_GpI2cMaTestMain_0");

    printf("-----------------------------------------------------------------------------------\n");
    printf("       st_t_req_u4_cbf/sla = GP_I2C_MA_SLA_0\n"                                       );
    for(u4_t_lpcnt = (U4)0U; u4_t_lpcnt < u4_t_lpmax; u4_t_lpcnt++){
    printf("          u2_tp_rwc_rem[%ld] = %ld\n", u4_t_lpcnt, u2_tp_rwc_rem[u4_t_lpcnt]          );
    printf("            u1_tp_accpt[%ld] = 0x%02x\n", u4_t_lpcnt, u1_tp_accpt[u4_t_lpcnt]         );
    }
}
/*===================================================================================================================================*/
/*  static void    vd_s_GpI2cMaTestMain_1(void)                                                                                      */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
static void    vd_s_GpI2cMaTestMain_1(void)
{
    ST_GP_I2C_MA_REQ         st_t_req;
    U4                       u4_t_sla;
    U4                       u4_t_lpcnt;
    U2                       u2_tp_rwc_rem[3];
    U1                       u1_tp_accpt[3];

    u4_sp_gpi2c_ma_test_req[0] = u4_sp_GP_I2C_MA_TEST_REA[0] & (U4)0x000000ff;
    u4_sp_gpi2c_ma_test_req[1] = (U4)0U;

    u4_t_sla         = ((U4)GP_I2C_MA_SLA_1 << GP_I2C_MA_CBF_LSB_SLA) | ((U4)128U << GP_I2C_MA_CBF_LSB_PID);
        
    st_t_req.u1p_pdu = (U1 *)&u4_sp_gpi2c_ma_test_req[0];
    st_t_req.u4_cbf  = u4_t_sla | (U4)GP_I2C_MA_TEST_RWC_MAX;
    u2_tp_rwc_rem[0] = u2_g_GpI2cMaRwcRembySla((U1)GP_I2C_MA_SLA_1);
    u1_tp_accpt[0]   = u1_g_GpI2cMaReqTRx(&st_t_req); 

    u4_sp_gpi2c_ma_test_req[2] = u4_sp_GP_I2C_MA_TEST_REA[2] & (U4)0x000000ff;
    u4_sp_gpi2c_ma_test_req[3] = (U4)0U;

    u4_t_sla         = ((U4)GP_I2C_MA_SLA_1 << GP_I2C_MA_CBF_LSB_SLA) | ((U4)256U << GP_I2C_MA_CBF_LSB_PID);

    st_t_req.u1p_pdu = (U1 *)&u4_sp_gpi2c_ma_test_req[2];
    st_t_req.u4_cbf  = u4_t_sla | (U4)6U;
    u2_tp_rwc_rem[1]    = u2_g_GpI2cMaRwcRembySla((U1)GP_I2C_MA_SLA_1);
    u1_tp_accpt[1]   = u1_g_GpI2cMaReqTRx(&st_t_req);

    vd_g_GpI2cMaTestSeqPrint("vd_s_GpI2cMaTestMain_1");

    printf("-----------------------------------------------------------------------------------\n");
    printf("       st_t_req_u4_cbf/sla = GP_I2C_MA_SLA_1\n"                                       );
    for(u4_t_lpcnt = (U4)0U; u4_t_lpcnt < (U4)2U; u4_t_lpcnt++){
    printf("          u2_tp_rwc_rem[%ld] = %ld\n", u4_t_lpcnt, u2_tp_rwc_rem[u4_t_lpcnt]          );
    printf("            u1_tp_accpt[%ld] = 0x%02x\n", u4_t_lpcnt, u1_tp_accpt[u4_t_lpcnt]         );
    }
}
/*===================================================================================================================================*/
/*  static void    vd_s_GpI2cMaTestMain_2(void)                                                                                      */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
static void    vd_s_GpI2cMaTestMain_2(void)
{
    ST_GP_I2C_MA_REQ         st_t_req;
    U4                       u4_t_sla;
    U4                       u4_t_lpcnt;
    U2                       u2_tp_rwc_rem[3];
    U1                       u1_tp_accpt[3];

    u4_sp_gpi2c_ma_test_req[0] = u4_sp_GP_I2C_MA_TEST_REA[4] & (U4)0x000000ff;
    u4_sp_gpi2c_ma_test_req[1] = (U4)0U;

    u4_t_sla         = ((U4)GP_I2C_MA_SLA_1 << GP_I2C_MA_CBF_LSB_SLA) | ((U4)512U << GP_I2C_MA_CBF_LSB_PID);

    st_t_req.u1p_pdu = (U1 *)&u4_sp_gpi2c_ma_test_req[0];
    st_t_req.u4_cbf  = u4_t_sla | (U4)7U;
    u2_tp_rwc_rem[0] = u2_g_GpI2cMaRwcRembySla((U1)GP_I2C_MA_SLA_1);
    u1_tp_accpt[0]   = u1_g_GpI2cMaReqTRx(&st_t_req);

    vd_g_GpI2cMaTestSeqPrint("vd_s_GpI2cMaTestMain_1");

    printf("-----------------------------------------------------------------------------------\n");
    printf("       st_t_req_u4_cbf/sla = GP_I2C_MA_SLA_1\n"                                       );
    for(u4_t_lpcnt = (U4)0U; u4_t_lpcnt < (U4)1U; u4_t_lpcnt++){
    printf("          u2_tp_rwc_rem[%ld] = %ld\n",    u4_t_lpcnt, u2_tp_rwc_rem[u4_t_lpcnt]       );
    printf("            u1_tp_accpt[%ld] = 0x%02x\n", u4_t_lpcnt, u1_tp_accpt[u4_t_lpcnt]         );
    }
}
/*===================================================================================================================================*/
/*  static void    vd_s_GpI2cMaTestMain_3(void)                                                                                      */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
static void    vd_s_GpI2cMaTestMain_3(void)
{
}
/*===================================================================================================================================*/
/*  static void    vd_s_GpI2cMaTestMain_4(void)                                                                                      */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
static void    vd_s_GpI2cMaTestMain_4(void)
{
}
/*===================================================================================================================================*/
/*  static void    vd_s_GpI2cMaTestIRQErrInsert(void)                                                                                */
/* --------------------------------------------------------------------------------------------------------------------------------- */
/*  Arguments:      -                                                                                                                */
/*  Return:         -                                                                                                                */
/*===================================================================================================================================*/
static void    vd_s_GpI2cMaTestIRQErrInsert(void)
{
    static const U1 * const  u1p_sp_GP_I2C_MA_TEST_ERR[] = {
        "IRQ_UNK", "SEQ_UNK", "IRQ_UNK/SEQ_UNK","RW_TOUT", "RWC_UNK", "REQ_UNK", "REQ_UNK", "REQ_UNK"
    };

    U2                       u2_t_err;
    U2                       u2_t_seq;

    u2_t_err = u2_s_gpi2c_ma_test_irq_err / (U2)GP_I2C_MA_SEQ_REQ;
    u2_t_seq = u2_s_gpi2c_ma_test_irq_err % (U2)GP_I2C_MA_SEQ_REQ;
    if((u2_t_err                      <= (U2)7U  ) &&
       (st_gp_gpi2c_ma_ctrl[0].u2_seq == u2_t_seq)){

        u2_s_gpi2c_ma_test_irq_err++;

        switch(u2_t_err){
            case 0U:
                u4_s_gpi2c_ma_test_irqbit     = (U4)U4_MAX;
                break;
            case 1U:
                st_gp_gpi2c_ma_ctrl[0].u2_seq = (U2)GP_I2C_MA_SEQ_REQ;
                break;
            case 2U:
                st_gp_gpi2c_ma_ctrl[0].u2_seq = (U2)GP_I2C_MA_SEQ_REQ;
                u4_s_gpi2c_ma_test_irqbit     = (U4)U4_MAX;
                break;
            case 3U:
                u1_s_gpi2c_ma_test_ifct       = (U1)0U;
                break;
            case 4U:
                st_gp_gpi2c_ma_ctrl[0].u2_rwc = (U2)9U;
                break;
            case 5U:
                st_gp_gpi2c_ma_ctrl[0].u2_run = (U2)16U;
                break;
            case 6U:
                st_gp_gpi2c_ma_ctrl[0].u2_req = (U2)16U;
                break;
            case 7U:
                st_gp_gpi2c_ma_ctrl[0].u2_ack = (U2)16U;
                break;
            case 8U:
                st_gp_gpi2c_ma_ctrl[0].u2_req = (U2)8U;
                st_gp_gpi2c_ma_ctrl[0].u2_ack = (U2)8U;
                break;
            default:
                break;
        }

        vd_g_GpI2cMaTestSeqPrint("vd_s_GpI2cMaTestIRQErrInsert");
        printf("-----------------------------------------------------------------------------------\n");
        printf("                  u2_t_err = %s(%ld)\n",      u1p_sp_GP_I2C_MA_TEST_ERR[u2_t_err], u2_t_err);
        printf("                  u2_t_seq = %s(0x%04x)\n",   u1p_sp_GP_I2C_MA_TEST_SEQ[u2_t_seq], u2_t_seq);
    }
}
/*===================================================================================================================================*/
/*                                                                                                                                   */
/*  Change History                                                                                                                   */
/*                                                                                                                                   */
/*===================================================================================================================================*/
/*                                                                                                                                   */
/*  Version  Date        Author   Change Description                                                                                 */
/* --------- ----------  -------  -------------------------------------------------------------------------------------------------- */
/*  1.1.0    10/10/2024  TN       New.                                                                                               */
/*                                                                                                                                   */
/*  * TN   = Takashi Nagai, Denso                                                                                                    */
/*                                                                                                                                   */
/*===================================================================================================================================*/
