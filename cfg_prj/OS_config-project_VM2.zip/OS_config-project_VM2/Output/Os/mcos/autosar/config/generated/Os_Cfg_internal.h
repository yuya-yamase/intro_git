/****************************************************************************
 * Protected                                                                *
 * Copyright AUBASS CO., LTD.                                               *
 ****************************************************************************

    Copyright (C) 2022 eSOL Co.,Ltd. Tokyo, Japan

    This software is protected by the law and the agreement concerning
    a Japanese country copyright method, an international agreement,
    and other intellectual property right and may be used and copied
    only in accordance with the terms of such license and with the inclusion
    of the above copyright notice.

    This software or any other copies thereof may not be provided
    or otherwise made available to any other person.  No title to
    and ownership of the software is hereby transferred.

    The information in this software is subject to change without
    notice and should not be construed as a commitment by eSOL Co.,Ltd.
*/
/****************************************************************************
 [ Os_Cfg_internal.h ] - OS module's configuration data file
****************************************************************************/

#ifndef OS_CFG_INTERNAL_H
#define OS_CFG_INTERNAL_H

/*
 * Function Prototypes
 */
#define OS_START_SEC_CODE_GLOBAL
#include "Os_MemMap.h"
extern TASK(eMCOS_TASK_High);
extern TASK(eMCOS_TASK_Idle);
extern TASK(eMCOS_TASK_Medium);
#define OS_STOP_SEC_CODE_GLOBAL
#include "Os_MemMap.h"


#define OS_START_SEC_CODE_GLOBAL
#include "Os_MemMap.h"
extern ISR(eMCOS_ISR_INTOSTM1TINT);
extern ISR(eMCOS_ISR_INTP38);
extern ISR(eMCOS_ISR_INTOSTM8TINT);
extern ISR(eMCOS_ISR_INTRIIC0EE);
extern ISR(eMCOS_ISR_INTRIIC0RI);
extern ISR(eMCOS_ISR_INTRIIC0TI);
extern ISR(eMCOS_ISR_INTRIIC0TEI);
extern ISR(eMCOS_ISR_INTRIIC1EE);
extern ISR(eMCOS_ISR_INTRIIC1RI);
extern ISR(eMCOS_ISR_INTRIIC1TI);
extern ISR(eMCOS_ISR_INTRIIC1TEI);
#define OS_STOP_SEC_CODE_GLOBAL
#include "Os_MemMap.h"



/*
 * Category 2 ISR control blocks
 */


#define OS_START_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"

extern ar_isrcb_t ar_isrcb_eMCOS_ISR_INTOSTM1TINT;

#define OS_STOP_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"


#define OS_START_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"

extern ar_isrcb_t ar_isrcb_eMCOS_ISR_INTP38;

#define OS_STOP_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"


#define OS_START_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"

extern ar_isrcb_t ar_isrcb_eMCOS_ISR_INTOSTM8TINT;

#define OS_STOP_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"


#define OS_START_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"

extern ar_isrcb_t ar_isrcb_eMCOS_ISR_INTRIIC0EE;

#define OS_STOP_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"


#define OS_START_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"

extern ar_isrcb_t ar_isrcb_eMCOS_ISR_INTRIIC0RI;

#define OS_STOP_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"


#define OS_START_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"

extern ar_isrcb_t ar_isrcb_eMCOS_ISR_INTRIIC0TI;

#define OS_STOP_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"


#define OS_START_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"

extern ar_isrcb_t ar_isrcb_eMCOS_ISR_INTRIIC0TEI;

#define OS_STOP_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"


#define OS_START_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"

extern ar_isrcb_t ar_isrcb_eMCOS_ISR_INTRIIC1EE;

#define OS_STOP_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"


#define OS_START_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"

extern ar_isrcb_t ar_isrcb_eMCOS_ISR_INTRIIC1RI;

#define OS_STOP_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"


#define OS_START_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"

extern ar_isrcb_t ar_isrcb_eMCOS_ISR_INTRIIC1TI;

#define OS_STOP_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"


#define OS_START_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"

extern ar_isrcb_t ar_isrcb_eMCOS_ISR_INTRIIC1TEI;

#define OS_STOP_SEC_VAR_LOCAL0_NO_INIT_32
#include "Os_MemMap.h"




#endif /* OS_CFG_INTERNAL_H */
/****************************************************************************/
/* AUBIST Configurator Version                                              */
/*  Framework          :v2-0-2                                              */
/*  BSW plug-in        :v2-0-0                                              */
/****************************************************************************/
